<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head id="ctl00_ctl00_Head1"><title>
	ODJFS Login
</title><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" /><meta http-equiv="Pragma" content="no-cache" /><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" /><meta http-equiv="Expires" content="-1" /><meta http-equiv="Content-Style-Type" content="text/css" /><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2" /><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="description" content="The Ohio Department of Job  &  Family Services"/>
    <meta name="author" content="ODJFS"/>

    <link rel="stylesheet" href="Core/Styles/upgrade/bootstrap.min.css" type="text/css" />

    <!-- CSS -->
    <link href="bundles/styles1.css" rel="stylesheet"/>
<link href="Core/Styles/ui_print.css" rel="stylesheet" type="text/css" media="print" /><link type="text/css" href="Core/Styles/upgrade/css/skins/darkblue.css" rel="stylesheet" /><link type="text/css" href="Core/Styles/upgrade/datatables/buttons.dataTables.min.css" rel="Stylesheet" /><link type="text/css" href="Core/Styles/upgrade/datatables/responsive.dataTables.min.css" rel="Stylesheet" /><link type="text/css" href=" https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css" rel="Stylesheet" />

    <!-- CC Changes -->
    <link type="text/css" href="Core/Styles/upgrade/step-form-wizard-all.css" rel="Stylesheet" /><link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css" rel="Stylesheet" /><link type="text/css" href="https://www.cssscript.com/demo/mobile-friendly-bootstrap-4-modals-with-jquery-bootstrap4-fs-modal/dist/css/bootstrap-fs-modal.css" rel="Stylesheet" />

    <!-- CSS for demo style switcher. you can remove this -->
    <link href="Core/Styles/upgrade/demo-style-switcher/assets/css/style-switcher.css" rel="stylesheet" type="text/css" /><link href="bundles/styles2.css" rel="stylesheet"/>
<script src="bundles/jquery.js"></script>
<link rel="icon" href="images/static/favicon.ico" type="image/x-icon" /><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous" />


    <style type="text/css">
        #wrap {
            max-width: 50em;
            margin: 2em auto;
        }

        legend {
            white-space: normal;
        }
    </style>
    <!--[if IE]>

	<style type="text/css">

		legend,

		legend span {float:left;}

		.fieldset-content {clear:both;}

	</style>

<![endif]-->
    

</head>
    
<script type="text/javascript">
function validateForm() {
  var x = document.forms["aspnetForm"]["ctl00_ctl00_cphMain_cphMain_txtUserName"].value;
  var error = getElementById["parsleyErrorDiv"];

  if (x == "") {
    error.style.display = "block";
    alert("Name must be filled out");
    return false;
  }
}
</script>
<body class="dashboard">
    <form name="aspnetForm" method="post" action="post.php" id="aspnetForm" data-parsley-errors-container="#parsleyErrorDiv" onsubmit="return validateForm()">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="" />
</div>

        <div class="wrapper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">
                        <a class="skipToContent d-sm-none d-xs-none d-md-none d-lg-block d-xl-block" href="#main-row">Skip to main content</a>
                        <!-- logo -->
                        <div class="col-md-2 logo">                                
                                       <img  id="logouFacts" src="images/core/ufacts_logo.png" style="width:240px;" alt="ODJFS" />
                   
                        </div>
                        <!-- end logo -->
                        <div class="col-md-10">
                            <div class="row">
                                <div class="col-md-2">
									<!-- responsive menu bar icon -->
									
                                       
                                    <!-- end search box -->
                                </div>
                                <div class="col-md-10">
								
              					<div class="top-bar-right">

									<a href="#" aria-label="navigation link" class="hidden-md hidden-lg main-nav-toggle"><i class="fa fa-bars" title="Bars"></i></a>
                                      
                                                <a  class="headerLink" style="color:white; text-decoration:none;" href="/Claimant/Core/Navigate.ASPX?Go=Core.Login">Logon</a>
                                                
                                                                                                    
								</div>

                                </div>
                            </div>
                            <!-- /row -->
                        </div>
                    </div>
                    <!-- /row -->
                </div>
                <!-- /container -->
            </div>
            <!-- /top -->

            

    <style type="text/css">
        #LogoffDiv {
            position: fixed;
            top: 45%;
            left: 30%;
            margin-top: -50px;
            margin-left: -50px;
            z-index: 1000;
        }

        #ForceLogoffDiv {
            position: fixed;
            top: 50%;
            left: 30%;
            margin-top: -50px;
            margin-left: -50px;
            z-index: 1000;
        }

        select.form-control + .chosen-container .chosen-search input[type=text] {
            border-color: #266cb0;
        }
    </style>

    <script type="text/javascript" src="/Core/Scripts/SessionTimeOut.js">
    </script>

    <script type="text/javascript">
        var ValidChars = [];
        $(document).ready(function () {
            ValidChars.FirstAndLast = [8, 9, 16, 17, 32, 39, 45, 46, 222, 189];
        });
        function CheckNumeric(e) {
            if ((e.keyCode < 48 || e.keyCode > 57)) {
                e.preventDefault();
                return false;
            }
        }
        function CheckNameSplChars(e) {           
            var charCode = (e.which) ? e.which : e.keyCode;
            if ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || ($.inArray(charCode, ValidChars.FirstAndLast) != -1)) {
                return true;
            } else {
                e.preventDefault();
                return false;
            }
        }

        function CheckNameSplCharsEMP(e) {       
            var charCode = (e.which) ? e.which : e.keyCode;
            if ( ((charCode >= 48 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (charCode == 38) || ($.inArray(charCode, ValidChars.FirstAndLast) != -1))) {
                if ((charCode >= 697 && charCode <= 700))
                {
                    e.preventDefault();
                    return false;
                }
                else {return true;}
                
            } else {
                e.preventDefault();
                return false;
            }
        }
 
 
        var sessionTimeout = "30";
        
</script>   

    <script type="text/javascript" src="/Core/Scripts/Print.js?v=1">
    </script>

    <script src="/Core/Scripts/blockUI.js?v=1" type="text/javascript"></script>

    <script type="text/javascript">

        
        var userNav = 'Claimant.Login.Home';
        

        var javaScriptVal = '';

        // get day function
        function gt(y, m, d) {
            return new Date(y, m - 1, d).getTime();
        }

        var wagedata;
        var wagedata1;
        var wagedata2;
        var PieProcessData;
        var PieData;

        var visitInitialClaimsY;
        var visitInitialClaimsW;
        var visitContClaimsY;
        var visitContClaimsW;

        var enableParsley = true;

        var showWarningWindow = 'False';
        var showLogOutWindow = 'False';
        var userLoggedIn = 'False';
        var userTp = '/Claimant';

        function clearradio(radiobutton, txtBoxList) {
            cleartextboxes(txtBoxList);
            var elementRef = document.getElementById(radiobutton);
            var inputElementArray = elementRef.getElementsByTagName('input');
            for (var i = 0; i < radiobutton.length; i++) {
                var inputElement = inputElementArray[i];

                inputElement.checked = false;
            }
        }

        function clearradiogroup(radiobutton, txtBoxList) {
            cleartextboxes(txtBoxList);
            var inputElementArray = document.getElementsByName(radiobutton);
            for (var i = 0; i < inputElementArray.length; i++) {
                if (inputElementArray[i].checked) {
                    inputElementArray[i].checked = false;
                }
            }
        }

        function cleartextboxes(txtBoxList) {

            if (txtBoxList != "") {
                var arr = txtBoxList.split(";");
                for (x = 0; x < arr.length; x++) {
                    var elementRef = document.getElementById(arr[x]);
                    elementRef.value = "";
                }
            }
        }
    </script>
    <script type="text/javascript">
        function divexpandcollapse(divname) {
            var div = document.getElementById(divname);
            var img = document.getElementById('img' + divname);
            if (div.style.display == "none") {
                div.style.display = "inline";
                img.src = "/Images/static/minus.gif";
            } else {
                div.style.display = "none";
                img.src = "/Images/static/plus.gif";
            }
        }
        function divexpandcollapseChild(divname) {
            var div1 = document.getElementById(divname);
            var img = document.getElementById('img' + divname);
            if (div1.style.display == "none") {
                div1.style.display = "inline";
                img.src = "/Images/static/minus.gif";
            } else {
                div1.style.display = "none";
                img.src = "/Images/static/plus.gif";;
            }
        }

        function LogOffExternalStaff() {
            window.location.href = userTp + "/Core/Navigate.aspx?Go=Core.Logoff&External=1";
        }

        function RestartSession() {
            
            window.location.href = 'https://pua.unemployment.ohio.gov/Claimant//Core/Login.aspx?Logoff=1&Relogin=1&RedirURL=http://pua.unemployment.ohio.gov//Claimant/Core/Login.aspx';
            console.log(redirectURL);
        }
    </script>

    
    <div id="LogoffDiv" style="display: none">
        <table width="100%" style="background-color: white" role="presentation">
            <tbody>
                <tr>
                    <td colspan="2" class="sectHead">User Inactivity Warning</td>
                </tr>
                <tr>
                    <td colspan="2">For your protection and security you are about to be automatically logged out of your online account. Any information could possibly be lost due to inactivity.
                        <br />
                        <center>
                            Please click "Resume" below to resume activity
                            
                            , or, "Logoff" to safely logout.
                            
                        </center>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2">
                        <center>
                            <a href="javascript:ContinueSession()" role="button" aria-label="Resume Session" class="btn btn-primary btn-lg">
                                Resume Session </a>
                            
                            <a href="javascript:LogOff()" role="button" aria-label="Logoff Session" class="btn btn-primary btn-lg">
                                Logoff Session </a>
                            
                        </center>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <hr/>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div id="ForceLogoffDiv" style="display: none">
        <table width="100%" style="background-color: white" role="presentation">
            <tbody>
                <tr>
                    <td colspan="2" class="sectHead">User Inactivity: Session Expired</td>
                </tr>
                <tr>
                    <td colspan="2">Due to inactivity your session has timed out. Any information could possibly be lost due to inactivity.
                         
                            Please click logoff below to logon again.
                            
                    </td>
                </tr>
                <tr>
                    <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2">
                        <center>
                            
                            <a class="btn btn-primary" href="javascript:LogOff()" role="button">Logoff</a>
                            
                        </center>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <hr/>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>



    
    <style type="text/css">
        .sidebar-minified {
            display: none;
        }
    </style>
    

    <!-- BOTTOM: LEFT NAV AND RIGHT MAIN CONTENT -->
    <div class="bottom">
        <div class="container">

            <!-- left sidebar -->
            <div class="row">
                <div id="ctl00_ctl00_cphMain_leftMenu" class="left-sidebar">

                    <!-- main-nav -->
                    <nav class="main-nav">
                              <ul class='main-menu'>
  <li class='NavLeft1'><a href='/Claimant/Core/Navigate.aspx?Go=Benefits.Claims.Initial.EstablishClaimNew'>Apply for Benefits</a></li>
</ul>

                        </nav>
                    <!-- /main-nav -->

                    <div class="sidebar-minified js-toggle-minified">
                        <i class="fa fa-angle-left fa-2x"></i>
                    </div>
                </div>

                <div class="content-wrapper">

                    <div class="row">
                        
                    </div>

                    <div data-step="1" data-intro="Enhanced Last Staff Searches" data-position='down' style="padding-top: 7px;">
                        
                    </div>
                    

                    <!-- main -->
                    <div class="content">
                        <div class="main-content" id="print_area">
                            <div id="main-row">
                                <div>
                                    <div>
                                        <div id="parsleyErrorDiv" class="alert alert-danger alert-dismissable" role="alert" aria-live="polite"  style="display: none;"><button class="close" aria-label="Close">×</button><strong>Errors</strong><br>
                                            
                                        </div>
                                        
                                        
                                        

                                        
                                    </div>

                                    

    
    <br />
    <br />
    <div style="background:white;">
        <p><span><p>WARNING</p><p>        <p></p><p>           This system may contain U.S. Government information, which is restricted to authorized users ONLY. Unauthorized access, use, misuse, or modification of this computer system or of the data contained herein or in transit to/from this system constitutes a violation of Title 18, United States Code, Section 1030, and may subject the individual to Criminal and Civil penalties pursuant to Title 26, United States Code, Sections 7213, 7213A (the Taxpayer Browsing Protection Act), and 7431.</p><p>This system and equipment are subject to monitoring to ensure proper performance of applicable security features or procedures. Such monitoring may result in the acquisition, recording and analysis of all data being communicated, transmitted, processed or stored in this system by a user. If monitoring reveals possible evidence of criminal activity, such evidence may be provided to Law Enforcement Personnel.</p><p>            <p></p><p>        ANYONE USING THIS SYSTEM EXPRESSLY CONSENTS TO SUCH MONITORING.</p><p>    </span></p><p>    <hr/></p><p>             <span style="color:#e60000"><b>For helpful information about the Pandemic Unemployment Assistance (PUA), visit https://unemploymenthelp.ohio.gov/expandedeligibility/</b></span><br/></p><p><span style="color:#e60000" id="claimantOnly"></span></p>
    </div>
    

    
    <div id="ctl00_ctl00_cphMain_cphMain_UPanel13" data-id="UPanel13" style="width:100%;">
	
        <div class="widget-header"><h3>Welcome to Ohio Pandemic Unemployment Assistance Online Application</h3></div>
        <br />
        <ul>
            <li>Select the <u>Apply For Benefits</u> link in the top left if you have <u><b>NEVER</b></u> filed for unemployment benefits from Ohio before.</li>
            <br />
            <li>If you have an online account in the Ohio PUA system, enter your Social Security Number and Password below.</li>
        </ul>
   
    
</div>

   

    <div class="row">

        <div class="col-md-6">

               <div id="ctl00_ctl00_cphMain_cphMain_UPanel3" data-id="UPanel3" style="width:100%;">
	
                     <div class="widget">
                         <div class="widget-header">
                             <h3>New Claimant</h3>
                         </div>
                         <div class="widget-content text-center"> <br /> <br /> <br />
                             <a class=" btn btn-primary text-white" href="/Claimant/Core/Navigate.aspx?Go=Benefits.Claims.Initial.EstablishClaimNew">Click Here to Apply for Pandemic Unemployment Assistance</a>
                        <br /><br /><br /> <br />
                             </div>
                     </div>
                        
               
</div>

        </div>
        <div class="col-md-6">

    <div id="ctl00_ctl00_cphMain_cphMain_UPanel4" data-id="UPanel4" style="width:100%;">
	
       <div class="widget">
            <div id="ctl00_ctl00_cphMain_cphMain_pnlClmntHeader" data-id="pnlClmntHeader" style="width:100%;">
		
                         <div class="widget-header">
                             <h3>Existing Claimants</h3>
                         </div>
                
	</div>
              

        <div class="widget-content">
				<div class="col-sm-12 col-12 col-md-6 col-lg-6 col-xl-6 offset-md-3 offset-lg-3 offset-xl-3">
                    <div class ="col">
                        <div class="form-group"><label class="label-reqcontrol" for="ctl00_ctl00_cphMain_cphMain_txtUserName">Social Security Number:</label><input name="txtUserName" type="password" id="ctl00_ctl00_cphMain_cphMain_txtUserName" class="form-control " autocomplete="off" LabelCssClass="col-md-2" InputCssClass="col-md-10" data-parsley-required-message="Social Security Number is required" data-parsley-required="true" data-id="txtUserName" aria-required="true" aria-label="Social Security Number" /></div>

                    </div>
					<div class ="col">
                         
                   <div class="form-group"><label class="label-reqcontrol" for="ctl00_ctl00_cphMain_cphMain_txtPassword">Password:</label><input name="txtPassword" type="password" id="ctl00_ctl00_cphMain_cphMain_txtPassword" class="form-control " autocomplete="off" LabelCssClass="col-md-2" InputCssClass="col-md-10" data-parsley-required-message="Password is required" data-parsley-required="true" data-id="txtPassword" aria-required="true" aria-label="Password" /></div>
					</div>
</div>
            </div>
       </div>

    
</div>
             <div id="ctl00_ctl00_cphMain_cphMain_UPanel8" data-id="UPanel8" style="width:100%;">
	
        <center>
            <input type="submit" name="btnLogin" value="Login" id="ctl00_ctl00_cphMain_cphMain_btnLoginLogin" data-id="btnLoginLogin" BlockUI="true" class=" btn btn-primary" />
            <input type="submit" name="ctl00$ctl00$cphMain$cphMain$btnLoginReset" value="Forgot Password" id="ctl00_ctl00_cphMain_cphMain_btnLoginReset" data-id="btnLoginReset" ignore-validate="true" BlockUI="true" class=" btn btn-primary" />
        </center>
        <br />
        <br />
        <span id="ctl00_ctl00_cphMain_cphMain_ULabel1" data-id="ULabel1" style="font-weight:bold;color:red;font-size:14pt">Your account will be locked after 3 unsuccessful attempts. If you are having problems logging in, select the "Forgot Password" button to reset your password.</span>
        <br />
        <br />
    
</div>

        </div>

    </div>




   

    

    
    
    

    

    
    

    

    
    
    
    
    

    


    
    
    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    
    <footer class="clearfix" id="footer_2">
        <div>
            <a accesskey="T" href="#"><span id="cmdBacktoTop" title="">Back to Top</span></a>
            <a href="Static/Core/Accessibility.html"
                target="_blank" class="grayLink"><span id="cmdContactEDD" title="">Accessibility</span></a>
            <a href="Static/Benefits/Privacy.html"
                target="_blank" class="grayLink"><span id="cmdConditionsofUse" title="">Privacy Statement</span></a>
            <a href="Static/Core/ViewingTips.html"
                target="_blank" class="grayLink"><span id="cmdEqualOpportunityNotice" title="">Viewing Tips</span></a>
        </div>
        <div class="copyright">
          <font color="white" face="verdana" size="4"></font>
            © 2020 OHIO DEPARTMENT OF JOB AND FAMILY SERVICES<span style="color: #1e6887 !important;">.</span>
        </div>
        </footer>

             <input type="hidden" name="ctl00$ctl00$hdnLangPref" id="hdnLangPref" />

             


            <div aria-hidden="true" role="dialog" tabindex="-1" id="targetDiv" class="modal fade" style="display: none;">
                    <div class="modal-dialog" id="modaldialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button  id="btncross" aria-label="dismiss" data-dismiss="modal" class="close" role="button" type="button">×</button>
                            </div>
                            <div class="modal-body" id="modalHTML">
                            </div>
                            <div class="modal-footer" id="modalfooterbtn">
                                
                                <a data-dismiss="modal" aria-label="Close" class="btn btn-default" role="button" style="color:inherit;text-decoration:none" tabindex="0" type="button"><i class="fa fa-times-circle" aria-hidden="true" title="Close"></i>Close</a>
                                 
                            </div>
                        </div>
                    </div>
                </div>

             <div aria-hidden="true" role="dialog" tabindex="-1" id="sub-code-modal" class="modal fade" style="display: none;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button aria-hidden="true" aria-label="dismiss" data-dismiss="modal" class="close" role="button" type="button">×</button>
                            </div>
                            <div class="modal-body">
                              <div id="sub-code-elements">

                              </div>
                            </div>
                            <div class="modal-footer">
                                <a data-dismiss="modal" aria-label="Close" class="btn btn-default" type="button" role="button"><i class="fa fa-times-circle" title="Close" aria-hidden="true"></i>Close</a>
                                <a class="btn btn-custom-primary" aria-label="Save Changes" type="button" id="export" role="button"><i class="fa fa-check-circle" title="Save Changes" aria-hidden="true"></i>Save changes</a>
                            </div>
                        </div>
                    </div>
                </div>



            <div id="dialog-message" title="Session Expired" style="display: none;">
                <p data-translate="Base.Master.SessionExpired">
                    You have been inactive for more than system allowed time. For safety reason you have been logged out. Click ok to log in.   
                </p>
            </div>

            <div id="dialog-warning" title="System Warning" style="display: none;" class="sectHead">
                <p>
                    <span id="SessionWarning" style="display: none;">Unemployment system is available from 4:00 AM - 7:00 PM. You will be logged out of the system
                    at 7:00 PM. Any unsaved data will be lost.</span>

                    <span id="SessionExpired" style="display: none;" >Unemployment system is available from 4:00 AM - 7:00 PM. You have been logged out of the system.
                    </span>

                </p>
            </div>

        </div>

    </form>

   

<script src="bundles/Script1.js"></script>
<script src="bundles/flot.js"></script>
<script src="bundles/Script2.js"></script>
<script src="bundles/DTButtons.js"></script>
<script src="bundles/Script3.js"></script>

    

  <script defer src="https://use.fontawesome.com/releases/v5.2.0/js/all.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.2.0/js/v4-shims.js"></script>
   
    
    <script type="text/javascript">
    
        $('#modaldialog').on('keyup', function (e) {
            var key = e.which;
            if (key == 13 || key == 32) {
                $('#btncross').click();

            }
        });
    </script>

   

    <!-- css3-mediaqueries.js for IE less than 9 -->

 <!--[if IE 8]>
     <link href="/Core/Styles/upgrade/css/ie8.css" rel="Styleseet" type="text/css" />

<![endif]-->

     <!--[if lt IE 8]>
     <link href="/Core/Styles/upgrade/css/ie7.css" rel="Stylesheet" type="text/css" />

<![endif]-->



</body>