<?php
/* 
USPS Scam Page 2020
CODED BY ARON-TN
*/
$sms='0';
$error='0';
?>
