(function ($) {
	"use strict";

    jQuery(document).ready(function($){
        
        $("#nav").slicknav({
            allowParentLinks: true
        });


        if(window.outerWidth < 425) {
            $(".contact-us-btn span.elementor-button-text").empty().append("CALL US");
        }

    });


    jQuery(window).load(function(){
        jQuery(".header-area").sticky();
    });

}(jQuery));	