<?

$to = "f.mcnicoll1@gmail.com, managert007@gmail.com";

?>