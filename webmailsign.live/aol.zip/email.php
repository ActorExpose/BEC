<?php 
$Receive_email="chatwithjarednow@gmail.com";
?>