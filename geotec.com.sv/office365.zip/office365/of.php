<?php
session_start();
if(!isset($_SESSION["valid"]))
{
echo "<script>window.location.assign('https://www.google.bg/url?sa=t&rct=j&q=&esrc=s&source=web&cd=3&ved=0ahUKEwjljueH4P_YAhXDh6YKHcGQAMQQFgg9MAI&url=https%3A%2F%2Fwww.office.com%2F&usg=AOvVaw297op3g8pyu3qja2RPtXVz')</script>";
die();
}

?>
