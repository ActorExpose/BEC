<html dir="ltr" lang="en-US" class="js"><head>
    <title>Office 365 Login | Microsoft Office</title>
    <meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0">

        <meta name="description" content="Collaborate for free with online versions of Microsoft Word, PowerPoint, Excel, and OneNote. Save documents, spreadsheets, and presentations online, in OneDrive. Share them with others and work together at the same time.">
 
        <link rel="stylesheet" type="text/css" crossorigin="anonymous" href="open.css">

    

        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

        </head><body style="display: block;">

    <div class="home__edge-parallax-fix"></div>
    <div class="home">
        <div class="home__container">
            
    <div class="home__header-footer home__header">
        



    <div id="pmg-global-header" class="log-appear">
            <div id="headerArea" class="uhf">
                <div id="headerRegion">

    <div id="headerUniversalHeader">
        

                        <div id="epb" class="x-hidden x-hidden-vp-mobile-st uhfc-universal-context context-uhf">

	<div class="c-uhfh-alert f-information epb-container theme-light" role="dialog" aria-label="Promotional Banner">
		<div>
			<div class="c-paragraph">
				<img alt="">
				<span class="c-text-group pb-content">
					<span class="epb-launch pb-content-heading"></span>
					<span class="epb-text pb-content-text"></span>
				</span>
			</div>
			<span class="c-group">
				<button id="close-epb" class="c-action-trigger c-action-cancel glyph-cancel"></button>
				<a id="epbTryNow" href="#" class="epb-launch c-action-trigger c-action-open"></a>
			</span>
		</div>
	</div>





                            
                        </div>




        <a id="uhfSkipToMain" class="m-skip-to-main" href="#">Skip to main content</a>


<header class="c-uhfh context-uhf c-sgl-stck c-category-header js" itemscope="itemscope">
    <div class="theme-light js-global-head f-closed  global-head-cont">
        <div class="c-uhfh-gcontainer-st">
            <button type="button" class="c-action-trigger c-glyph glyph-global-nav-button" aria-label="All Microsoft expand to see list of Microsoft products and services" initialstate-label="All Microsoft expand to see list of Microsoft products and services" togglestate-label="Close All Microsoft list" aria-expanded="false"></button>
            <button type="button" class="c-action-trigger c-glyph glyph-arrow-htmllegacy" aria-expanded="false"></button>
                    <a id="uhfLogo" class="c-logo c-sgl-stk-uhfLogo" itemprop="url" href="#" aria-label="Microsoft">
                        <img alt="" itemprop="logo" class="c-image" src="microsoft_logo.svg" role="presentation" aria-hidden="true">
                        <span itemprop="name" role="presentation" aria-hidden="true">Microsoft</span>
                    </a>
            <div class="f-mobile-title">
                <button type="button" class="c-action-trigger c-glyph glyph-chevron-left" aria-label="See more menu options"></button>
                <span>Office</span>
                <button type="button" class="c-action-trigger c-glyph glyph-chevron-right" aria-label="See more menu options" style="display: none;"></button>
            </div>
                    <div class="c-show-pipe x-hidden-vp-mobile-st">
                        <a id="uhfCatLogo" class="c-logo c-cat-logo" href="#" aria-label="Office" itemprop="url">
                                <span>Office</span>
                        </a>
                    </div>
                <div class="cat-logo-button-cont x-hidden">
                        <button type="button" id="uhfCatLogoButton" class="c-cat-logo-button x-hidden" aria-expanded="false" aria-label="Office">
                            Office
                        </button>
                </div>



                    <nav id="uhf-g-nav" aria-label="Contextual menu" class="c-uhfh-gnav" style="">
            <ul class="js-paddle-items">
                    <li class="single-link js-nav-menu x-hidden-none-mobile-vp uhf-menu-item">
                        <a class="c-uhf-nav-link" href="#"> Home </a>
                    </li>
                                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_0" aria-expanded="false">Products</button>

                                <ul class="f-multi-column f-multi-column-5" style="
    display: none;
">
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">For home</button>
            <ul aria-hidden="false" style="">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_2" class="js-subm-uhf-nav-link" href="#">Plans and pricing</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_3" class="js-subm-uhf-nav-link" href="#">For families</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_4" class="js-subm-uhf-nav-link" href="#">For individuals</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_5" class="js-subm-uhf-nav-link" href="#">For students</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_6" class="js-subm-uhf-nav-link" href="#">See all home</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">For business</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_8" class="js-subm-uhf-nav-link" href="#">Plans and pricing</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_9" class="js-subm-uhf-nav-link" href="#">Small business</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_10" class="js-subm-uhf-nav-link" href="#">Schools</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">For enterprise</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_12" class="js-subm-uhf-nav-link" href="#">Plans and pricing</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_13" class="js-subm-uhf-nav-link" href="#">Enterprise</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_14" class="js-subm-uhf-nav-link" href="#">Frontline workers</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">Apps and services</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_16" class="js-subm-uhf-nav-link" href="#">Excel</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_17" class="js-subm-uhf-nav-link" href="#">Microsoft Family Safety</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_18" class="js-subm-uhf-nav-link" href="#">Microsoft Teams</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_19" class="js-subm-uhf-nav-link" href="#">OneDrive</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_20" class="js-subm-uhf-nav-link" href="#">Outlook</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_21" class="js-subm-uhf-nav-link" href="#">PowerPoint</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_22" class="js-subm-uhf-nav-link" href="#">SharePoint</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_23" class="js-subm-uhf-nav-link" href="#">Word</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_24" class="js-subm-uhf-nav-link" href="#">See all apps and services</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">More</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_26" class="js-subm-uhf-nav-link" href="#">Microsoft Office</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_27" class="js-subm-uhf-nav-link" href="#">Office 365</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_28" class="js-subm-uhf-nav-link" href="#">Windows</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_29" class="js-subm-uhf-nav-link" href="#">Enterprise Mobility + Security</a>
            
        </li>
            </ul>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="resources" aria-expanded="false">Resources </button>

                                <ul class="" style="
    display: none;
">
        <li class="js-nav-menu single-link">
            <a id="CustomerStories" class="js-subm-uhf-nav-link" href="#">Customer stories</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="FAQ" class="js-subm-uhf-nav-link" href="#">Frequently asked questions</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="InstallOffice" class="js-subm-uhf-nav-link" href="#">Install Office</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="ITResources" class="js-subm-uhf-nav-link" href="#">IT Pro resources</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="officeblog" class="js-subm-uhf-nav-link" href="#">Office blog</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="SecurityCompliance" class="js-subm-uhf-nav-link" href="#">Security &amp; compliance</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="SystemRequirements" class="js-subm-uhf-nav-link" href="#">System requirements</a>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="single-link js-nav-menu uhf-menu-item">
                            <a id="c-shellmenu_38" class="c-uhf-nav-link" href="#">Templates</a>
                        </li>
                        <li class="single-link js-nav-menu uhf-menu-item">
                            <a id="support" class="c-uhf-nav-link" href="#">Support</a>
                        </li>
                        


                <li class="single-link uhf-menu-item">
                            <a id="My account" class="c-uhf-nav-link" href="#">My account</a>
                        </li><li id="overflow-menu" class="overflow-menu uhf-menu-item x-hidden">
                        <div class="c-uhf-menu js-nav-menu">
        <button type="button" aria-label="More" aria-expanded="false">More</button>
        <ul id="overflow-menu-list" aria-hidden="true" class="overflow-menu-list" style="">
        </ul>
    </div>

                </li>
                                    <li class="single-link js-nav-menu" id="c-uhf-nav-cta">
                        <a id="BuyOffice365" class="c-uhf-nav-link" href="#">Buy now</a>
                    </li>
            </ul>
            
        </nav>


            <div class="c-uhfh-actions">
                <div class="wf-menu">        <nav id="uhf-c-nav" style="display: block;">
            <ul class="js-paddle-items">
                <li>
                    <div class="c-uhf-menu js-nav-menu">
                        <button type="button" class="c-button-logo all-ms-nav" aria-label="All Microsoft expand to see list of Microsoft products and services" aria-expanded="false"> <span>All Microsoft</span></button>
                        <ul class="f-multi-column f-multi-column-6" aria-hidden="true">
                                    <li class="c-w0-contr">
            <ul class="c-w0">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_41" class="js-subm-uhf-nav-link" href="#">Microsoft 365</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_42" class="js-subm-uhf-nav-link" href="#">Office</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_43" class="js-subm-uhf-nav-link" href="#">Windows</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_44" class="js-subm-uhf-nav-link" href="#">Surface</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_45" class="js-subm-uhf-nav-link" href="#">Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_46" class="js-subm-uhf-nav-link" href="#">Deals</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="l1_support" class="js-subm-uhf-nav-link" href="#">Support</a>
            
        </li>
            </ul>
        </li>

        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">Software</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_50" class="js-subm-uhf-nav-link" href="#">Windows Apps</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_51" class="js-subm-uhf-nav-link" href="#">OneDrive</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_52" class="js-subm-uhf-nav-link" href="#">Outlook</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_53" class="js-subm-uhf-nav-link" href="#">Skype</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_54" class="js-subm-uhf-nav-link" href="#">OneNote</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_55" class="js-subm-uhf-nav-link" href="#">Microsoft Teams</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_56" class="js-subm-uhf-nav-link" href="#">Microsoft Edge</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">PCs &amp; Devices  </button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_58" class="js-subm-uhf-nav-link" href="#">Computers</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_59" class="js-subm-uhf-nav-link" href="#">Shop Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_60" class="js-subm-uhf-nav-link" href="#">Accessories</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_61" class="js-subm-uhf-nav-link" href="#">VR &amp; mixed reality</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_62" class="js-subm-uhf-nav-link" href="#">Phones</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">Entertainment</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_64" class="js-subm-uhf-nav-link" href="#">Xbox Game Pass Ultimate</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_65" class="js-subm-uhf-nav-link" href="#">Xbox Live Gold</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_66" class="js-subm-uhf-nav-link" href="#">Xbox games</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_67" class="js-subm-uhf-nav-link" href="#">PC games</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_68" class="js-subm-uhf-nav-link" href="#">Windows digital games</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_69" class="js-subm-uhf-nav-link" href="#">Movies &amp; TV</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">Business</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_71" class="js-subm-uhf-nav-link" href="#">Microsoft Azure</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_72" class="js-subm-uhf-nav-link" href="#">Microsoft Dynamics 365</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_73" class="js-subm-uhf-nav-link" href="#">Microsoft 365</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_74" class="js-subm-uhf-nav-link" href="#">Microsoft Industry</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_75" class="js-subm-uhf-nav-link" href="#">Data platform</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_76" class="js-subm-uhf-nav-link" href="#">Microsoft Advertising</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_77" class="js-subm-uhf-nav-link" href="#">Power Platform</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_78" class="js-subm-uhf-nav-link" href="#">Shop Business</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">Developer &amp; IT  </button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_80" class="js-subm-uhf-nav-link" href="#">.NET</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_81" class="js-subm-uhf-nav-link" href="#">Visual Studio</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_82" class="js-subm-uhf-nav-link" href="#">Windows Server</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_83" class="js-subm-uhf-nav-link" href="#">Windows Dev Center</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_84" class="js-subm-uhf-nav-link" href="#">Docs</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_85" class="js-subm-uhf-nav-link" href="#">Power Apps</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_86" class="js-subm-uhf-nav-link" href="#">HoloLens 2</a>
            
        </li>
            </ul>
            
        </li>
        <li class="f-sub-menu js-nav-menu nested-menu">

            <button type="button" f-multi-parent="true" aria-hidden="true" tabindex="-1">Other</button>
            <ul aria-hidden="false">
        <li class="js-nav-menu single-link">
            <a id="shellmenu_88" class="js-subm-uhf-nav-link" href="#">Microsoft Rewards </a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_89" class="js-subm-uhf-nav-link" href="#">Free downloads &amp; security</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_90" class="js-subm-uhf-nav-link" href="#">Education</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_91" class="js-subm-uhf-nav-link" href="#">Virtual workshops and training</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_92" class="js-subm-uhf-nav-link" href="#">Gift cards</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="Licensing" class="js-subm-uhf-nav-link" href="#">Licensing</a>
            
        </li>
        <li class="js-nav-menu single-link">
            <a id="shellmenu_94" class="js-subm-uhf-nav-link" href="#">Microsoft Experience Center</a>
            
        </li>
            </ul>
            
        </li>
                                                            <li class="f-multi-column-info">
                                    <a href="#" aria-label="" class="c-glyph">View Sitemap</a>
                                </li>
                            
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
</div>
                        <div id="meControl" class="c-me"><div class="mectrl_root mectrl_theme_light_header"><a id="mectrl_main_trigger" class="mectrl_resetStyle mectrl_trigger" aria-label="Sign in to your account" href="index2.php" target="_top" style="
    background: url(download.svg) no-repeat;
    width: 32px;
    height: 32px;
    display: block;
    margin: 8px;
"><span class="mectrl_screen_reader_text"></span><div class="mectrl_header" aria-hidden="true" role="presentation"><div id="mectrl_headerPicture" class="mectrl_profilepic mectrl_glyph glyph_signIn_circle" aria-hidden="true" role="presentation"></div></div></a></div></div>
                
            </div>
        </div>
        
        
    </div>
    


<a id="uhf-swp" aria-label="follow this link to read more about how microsoft education products can enable remote learning." class="c-sitewide-promo theme-dark" href="#" target="_blank">
    <p class="c-paragraph color-brand-blue">
        Remote Learning in education. Learn more &gt;
    </p>
    
</a>
</header>




    </div>
        </div>

    </div>

    </div>

    </div>


            





<div id="main" role="main">
        
<div id="hero-section" class="hero" aria-labelledby="hero-header" role="region">
    <div class="content-gutter width-restrictor--hero">
        <div class="width-restrictor" style="
">
            <div class="hero__content" style="
">
                <h1 id="hero-header" class="hero__title">Welcome to Office</h1>
                <p class="hero__subtitle" aria-label="Your place to create, communicate, collaborate, and get great work done.">Your place to create, communicate, collaborate, and get great work done.</p>
                <div class="hero__buttons-container">
                    <a id="hero-banner-sign-in-to-office-365-link" class="hero__button hero__button--primary" href="index2.php" aria-label="Sign in">
                        Sign in
                    </a>
                    <a id="hero-banner-get-office-link" class="hero__button hero__button--secondary" href="#" aria-label="Get Office">
                        Get Office
                    </a>
                </div>
                    <a id="hero-banner-free-upsell-v1-link" class="hero__link animated-link" href="#"><span class="animated-link--text">Sign up for the free version of Office</span><span aria-hidden="true" style="
    font-size: 13px;
    font-weight: 700;
    margin-left: 3px;
">&gt;</span></a>
            </div>
        </div>
    </div>
    <picture class="hero__image">
        
        
        
        
        <source srcset="" alt="" aria-hidden="true" style="
"><img src="hero.jpg" style="max-height: 420px;">

        
    </picture>
</div>
        
<div id="office-apps" class="office-apps" aria-labelledby="office-apps-header" role="region">
    <div id="office-apps-content" class="content-gutter">
        <div class="width-restrictor">
            <h2 id="office-apps-header" class="office-apps__header">Sign in to use your favorite productivity apps from any device</h2>
            <div class="office-apps__app-container">
                <div class="office-apps__app-wrapper">
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--wordLogo ms-ohp-Icon--wordLogoFill"></span>
                            <p class="office-apps__app-text">Word</p>
                        </div>
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--excelLogo ms-ohp-Icon--excelLogoFill"></span>
                            <p class="office-apps__app-text">Excel</p>
                        </div>
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--powerpointLogo ms-ohp-Icon--powerpointLogoFill"></span>
                            <p class="office-apps__app-text">PowerPoint</p>
                        </div>
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--onenoteLogo ms-ohp-Icon--onenoteLogoFill"></span>
                            <p class="office-apps__app-text">OneNote</p>
                        </div>
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--oneDriveLogo"></span>
                            <p class="office-apps__app-text">OneDrive</p>
                        </div>
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--outlookLogo ms-ohp-Icon--outlookLogoFill"></span>
                            <p class="office-apps__app-text">Outlook</p>
                        </div>
                        <div class="office-apps__app">
                            <span class="office-apps__app-icon ms-ohp-svg-Icon ms-ohp-Icon ms-ohp-Icon--teamsLogo ms-ohp-Icon--teamsLogoFill"></span>
                            <p class="office-apps__app-text">Teams</p>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <picture class="office-apps__video lazy">
        <source>
        <img>
    </picture>
</div>
        
<div id="get-office" class="get-office" aria-labelledby="get-office-header" role="region">
    <div class="content-gutter">
        <div class="width-restrictor">
            
                <h2 id="get-office-header" class="get-office__header">Get the premium Office apps with Microsoft 365</h2>
            <div class="get-office__link-container">
                <div class="get-office__link">
                    <img class="get-office__link-image" src="#" alt="" aria-hidden="true">
                    <a id="get-office-today-for-home-link" class="animated-link" href="#"><span class="animated-link--text">For home</span><span class="ms-Icon ms-Icon--chevronRight animated-link--arrow" aria-hidden="true"></span></a>
                </div>
                <div class="get-office__link">
                    <img class="get-office__link-image" src="#" alt="" aria-hidden="true">
                    <a id="get-office-today-for-business-link" class="animated-link" href="#"><span class="animated-link--text">For business</span><span class="ms-Icon ms-Icon--chevronRight animated-link--arrow" aria-hidden="true"></span></a>
                </div>
                <div class="get-office__link">
                    <img class="get-office__link-image" src="#" alt="" aria-hidden="true">
                    <a id="get-office-today-enterprise-link" class="animated-link" href="#"><span class="animated-link--text">For enterprise</span><span class="ms-Icon ms-Icon--chevronRight animated-link--arrow" aria-hidden="true"></span></a>
                </div>
                <div class="get-office__link">
                    <img class="get-office__link-image" src="#" alt="" aria-hidden="true">
                    <a id="get-office-today-edu-link" class="animated-link" href="#"><span class="animated-link--text">For education</span><span class="ms-Icon ms-Icon--chevronRight animated-link--arrow" aria-hidden="true"></span></a>
                </div>
            </div>
        </div>
    </div>
</div>

    
<div id="social-media-section" class="section social-media__section" aria-labelledby="social-media-header" role="navigation">
    <div class="social-media__wrapper">
        <span id="social-media-header" class="social-media__text">Follow Office</span>
        <a id="social-media-linkedin" class="social-media__link" href="#" aria-label="Linkedin" title="Linkedin">
            <picture class="lazy" style="opacity: 1;">
                <source type="image/png" media="(-ms-high-contrast: white-on-black)" srcset="#">
                <img class="social-media__link--image" aria-hidden="true" alt="" src="#">
            </picture>
        </a>
        <a id="social-media-facebook" class="social-media__link" href="#" aria-label="Facebook" title="Facebook">
            <picture class="lazy" style="opacity: 1;">
                <source type="image/png" media="(-ms-high-contrast: white-on-black)" srcset="#">
                <img class="social-media__link--image" aria-hidden="true" alt="" src="#">
            </picture>
        </a>
        <a id="social-media-twitter" class="social-media__link" href="#" aria-label="Twitter" title="Twitter">
            <picture class="lazy" style="opacity: 1;">
                <source type="image/png" media="(-ms-high-contrast: white-on-black)" srcset="#">
                <img class="social-media__link--image" aria-hidden="true" alt="" src="#">
            </picture>
        </a>
        <a id="social-media-instagram" class="social-media__link" href="#" aria-label="Instagram" title="Instagram">
            <picture class="lazy" style="opacity: 1;">
                <source type="image/png" media="(-ms-high-contrast: white-on-black)" srcset="#">
                <img class="social-media__link--image" aria-hidden="true" alt="" src="#">
            </picture>
        </a>
        <a id="social-media-office-blogs-link" class="social-media__link" href="#" aria-label="Office blogs" title="Office blogs">
            <picture class="lazy" style="opacity: 1;">
                <source type="image/png" media="(-ms-high-contrast: white-on-black)" srcset="#">
                <img class="social-media__link--image" aria-hidden="true" alt="" src="#">
            </picture>
        </a>
    </div>
</div>


</div>


            
    <div class="home__header-footer">
        

    <div id="pmgDetailFooter" class="log-appear">
            <div id="footerArea" class="uhf">
                <div id="footerRegion">

    <div id="footerUniversalFooter">
        



<footer id="uhf-footer" class="c-uhff context-uhf">
        <nav class="c-uhff-nav" aria-label="Footer Resource links">
            
                <div class="c-uhff-nav-row">
                    <div class="c-uhff-nav-group">
                        <div class="c-heading-4" role="heading" aria-level="4">What's new</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Surface Duo What's new" class="c-uhff-link" href="#">Surface Duo</a>
                            </li>
                            <li>
                                <a aria-label="Surface Laptop Go What's new" class="c-uhff-link" href="#">Surface Laptop Go</a>
                            </li>
                            <li>
                                <a aria-label="Surface Pro X What's new" class="c-uhff-link" href="#">Surface Pro X</a>
                            </li>
                            <li>
                                <a aria-label="Surface Go 2 What's new" class="c-uhff-link" href="#">Surface Go 2</a>
                            </li>
                            <li>
                                <a aria-label="Surface Book 3 What's new" class="c-uhff-link" href="#">Surface Book 3</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft 365 What's new" class="c-uhff-link" href="#">Microsoft 365</a>
                            </li>
                            <li>
                                <a aria-label="Windows 10 apps What's new" class="c-uhff-link" href="#">Windows 10 apps</a>
                            </li>
                            <li>
                                <a aria-label="HoloLens 2 What's new" class="c-uhff-link" href="#">HoloLens 2</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group">
                        <div class="c-heading-4" role="heading" aria-level="4">Microsoft Store</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Account profile Microsoft Store" class="c-uhff-link" href="#">Account profile</a>
                            </li>
                            <li>
                                <a aria-label="Download Center Microsoft Store" class="c-uhff-link" href="#">Download Center</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Store support Microsoft Store" class="c-uhff-link" href="#">Microsoft Store support</a>
                            </li>
                            <li>
                                <a aria-label="Returns Microsoft Store" class="c-uhff-link" href="#">Returns</a>
                            </li>
                            <li>
                                <a aria-label="Order tracking Microsoft Store" class="c-uhff-link" href="#">Order tracking</a>
                            </li>
                            <li>
                                <a aria-label="Virtual workshops and training Microsoft Store" class="c-uhff-link" href="#">Virtual workshops and training</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Store Promise Microsoft Store" class="c-uhff-link" href="#">Microsoft Store Promise</a>
                            </li>
                            <li>
                                <a aria-label="Financing Microsoft Store" class="c-uhff-link" href="#">Financing</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group">
                        <div class="c-heading-4" role="heading" aria-level="4">Education</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Microsoft in education Education" class="c-uhff-link" href="#">Microsoft in education</a>
                            </li>
                            <li>
                                <a aria-label="Office for students Education" class="c-uhff-link" href="#">Office for students</a>
                            </li>
                            <li>
                                <a aria-label="Office 365 for schools Education" class="c-uhff-link" href="#">Office 365 for schools</a>
                            </li>
                            <li>
                                <a aria-label="Deals for students &amp; parents Education" class="c-uhff-link" href="#">Deals for students &amp; parents</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Azure in education Education" class="c-uhff-link" href="#">Microsoft Azure in education</a>
                            </li>

                        </ul>
                        
                    </div>
                </div>
                <div class="c-uhff-nav-row">
                    <div class="c-uhff-nav-group">
                        <div class="c-heading-4" role="heading" aria-level="4">Enterprise</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Azure Enterprise" class="c-uhff-link" href="#">Azure</a>
                            </li>
                            <li>
                                <a aria-label="AppSource  Enterprise" class="c-uhff-link" href="#">AppSource </a>
                            </li>
                            <li>
                                <a aria-label="Automotive Enterprise" class="c-uhff-link" href="#">Automotive</a>
                            </li>
                            <li>
                                <a aria-label="Government Enterprise" class="c-uhff-link" href="#">Government</a>
                            </li>
                            <li>
                                <a aria-label="Healthcare Enterprise" class="c-uhff-link" href="#">Healthcare</a>
                            </li>
                            <li>
                                <a aria-label="Manufacturing Enterprise" class="c-uhff-link" href="#">Manufacturing</a>
                            </li>
                            <li>
                                <a aria-label="Financial services Enterprise" class="c-uhff-link" href="#">Financial services</a>
                            </li>
                            <li>
                                <a aria-label="Retail Enterprise" class="c-uhff-link" href="#">Retail</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group">
                        <div class="c-heading-4" role="heading" aria-level="4">Developer</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Microsoft Visual Studio Developer" class="c-uhff-link" href="#">Microsoft Visual Studio</a>
                            </li>
                            <li>
                                <a aria-label="Windows Dev Center Developer" class="c-uhff-link" href="#">Windows Dev Center</a>
                            </li>
                            <li>
                                <a aria-label="Developer Center Developer" class="c-uhff-link" href="#">Developer Center</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft developer program Developer" class="c-uhff-link" href="#">Microsoft developer program</a>
                            </li>
                            <li>
                                <a aria-label="Channel 9 Developer" class="c-uhff-link" href="#">Channel 9</a>
                            </li>
                            <li>
                                <a aria-label="Office Dev Center Developer" class="c-uhff-link" href="#">Office Dev Center</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Garage Developer" class="c-uhff-link" href="#">Microsoft Garage</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group">
                        <div class="c-heading-4" role="heading" aria-level="4">Company</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Careers Company" class="c-uhff-link" href="#">Careers</a>
                            </li>
                            <li>
                                <a aria-label="About Microsoft Company" class="c-uhff-link" href="#">About Microsoft</a>
                            </li>
                            <li>
                                <a aria-label="Company news Company" class="c-uhff-link" href="#">Company news</a>
                            </li>
                            <li>
                                <a aria-label="Privacy at Microsoft Company" class="c-uhff-link" href="#">Privacy at Microsoft</a>
                            </li>
                            <li>
                                <a aria-label="Investors Company" class="c-uhff-link" href="#">Investors</a>
                            </li>
                            <li>
                                <a aria-label="Diversity and inclusion Company" class="c-uhff-link" href="#">Diversity and inclusion</a>
                            </li>
                            <li>
                                <a aria-label="Accessibility Company" class="c-uhff-link" href="#">Accessibility</a>
                            </li>
                            <li>
                                <a aria-label="Security Company" class="c-uhff-link" href="#">Security</a>
                            </li>

                        </ul>
                        
                    </div>
                </div>
        </nav>
    <div class="c-uhff-base">
                <a id="locale-picker-link" aria-label="Content Language Selector. Currently set to English (United States)" class="c-uhff-link c-uhff-lang-selector c-glyph glyph-world" href="#">English (United States)</a>

        <nav aria-label="Microsoft corporate links">
            <ul class="c-list f-bare">
                                <li id="c-uhff-footer_sitemap">
                    <a class="c-uhff-link" href="#">Sitemap</a>
                </li>
                <li id="c-uhff-footer_contactus">
                    <a class="c-uhff-link" href="#">Contact Microsoft</a>
                </li>
                <li id="c-uhff-footer_privacyandcookies">
                    <a class="c-uhff-link" href="#">Privacy </a>
                </li>
                <li class=" x-hidden" id="c-uhff-footer_managecookies">
                    <a class="c-uhff-link" href="#">Manage cookies</a>
                </li>
                <li id="c-uhff-footer_termsofuse">
                    <a class="c-uhff-link" href="#">Terms of use</a>
                </li>
                <li id="c-uhff-footer_trademarks">
                    <a class="c-uhff-link" href="#">Trademarks</a>
                </li>
                <li id="c-uhff-footer_safetyandeco">
                    <a class="c-uhff-link" href="#">Safety &amp; eco</a>
                </li>
                <li id="c-uhff-footer_aboutourads">
                    <a class="c-uhff-link" href="#">About our ads</a>
                </li>

                <li>© Microsoft 2021</li>
                
            </ul>
        </nav>
    </div>
    
</footer>




    </div>
        </div>

    </div>

    </div>

    </div>

        </div>
    </div>




</body></html>