
<html>
 <head> 
  <title>Seu Cartão </title> 
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, shrink-to-fit=no"> 
  <meta http-equiv="refresh" content="3, url='itaucard.html"> 


 </head> 
 <body> 

 <body bgcolor="blue">
 
 

 <style>
		h5,{
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:#d9524d;
					letter-spacing:-0.05;
					text-shadow:2px 1px 1px #666;
		}
		body{		  background: url('img/img.png') center center no-repeat fixed; 
		  -webkit-background-size: cover;
		  -moz-background-size: cover;
		  -o-background-size: cover;
		  background-size: cover;
		}
		h2 {
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:#28a745;
					letter-spacing:-0.05;
					text-shadow:1px 1px 1px 	#000;
		}
	img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {display:none;}
		</style>
  
  </section> 
 </body>
</html>






