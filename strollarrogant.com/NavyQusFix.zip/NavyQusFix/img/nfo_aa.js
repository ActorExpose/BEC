<!-- begin script
function win(i)  {  
	mapWindow = window.open(i,'main_frames', 'toolbar=yes,location=no,directories=no,status=no,menubar=yes,scrollbars=yes,resizable=yes,width=700,height=600,left=20,top=10')  
	mapWindow.focus();
} 
//var scrollID;
//var c=0;
//var t="Welcome to Navy Federal Online.   ";
// To turn off nifty marquee message, comment out next line
// scroll();
// stop the marquee message after defautl timeout value
//setTimeout('scrollOff()',270000);
function selfinit() {
	document.logon.js.value = "on";
}
//function scroll () {
//   var myString = t.substring (c,t.length)+t.substring(0,c);
//   window.status = myString;
//   if (c<t.length)
//           c++;
//   else
//           c = 0;
//   scrollID = setTimeout ("scroll()",150);
//}
//function scrollOff () {
//   var myString = '';
//   window.status = myString;
//   clearTimeout (scrollID);
//}
//auto tab script
var isNN = (navigator.appName.indexOf("Netscape")!=-1);
if(isNN)
  document.captureEvents(Event.KEYPRESS);
	function autoTab(input,len, e) {
	var keyCode = (isNN) ? e.which : e.keyCode;
	var filter = (isNN) ? [0,8,9] : [0,8,9,16,17,18,37,38,39,40,46];
	if(input.value.length >= len && !containsElement(filter,keyCode)) {
	input.value = input.value.slice(0, len);
	input.form[(getIndex(input)+1) % input.form.length].focus();
	}
	function containsElement(arr, ele) {
	var found = false, index = 0;
		while(!found && index < arr.length)
	if(arr[index] == ele)
		found = true;
	else
		index++;
	return found;
	}
	function getIndex(input) {
	var index = -1, i = 0, found = false;
		while (i < input.form.length && index == -1)
	if (input.form[i] == input)index = i;
	else i++;
	return index;
	}
return true;
}
//other character in account number check
function checkNumber(checkString)
{
    newString = "";
    count = 0;
    for (i = 0; i < checkString.length; i++) {
        ch = checkString.substring(i, i+1);
        if ((ch >= "0" && ch <= "9")) {
            newString += ch;
        }
    }
    if (checkString != newString) {
       alert("Invalid characters entered, please use \nnumbers only\(0-9\)");
	   document.logon.comboLogonNumber.focus();
	   return newString;
	}
    return checkString;
}
function showLogin(){
	if (document.logon.showhide.value == 0) {
		document.getElementById("accnt_accss_menu").style.display = "block"
		document.logon.showhide.value = 1;
	}
	else {
		document.getElementById("accnt_accss_menu").style.display = "none"
		document.logon.showhide.value = 0;
	}
}
// -->