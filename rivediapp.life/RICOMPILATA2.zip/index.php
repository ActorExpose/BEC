<?php
include_once 'user_agent.php';
session_start();
$ua = new UserAgent();
if($ua->is_mobile()){
    		echo "<script type='text/javascript'>window.top.location='accesso.php';</script>"; exit;
}
else
	{
		session_unset();
		session_destroy();
		header("Location: https://www.google.it");
		die();
	}
?>