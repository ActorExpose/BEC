
/* Example */
// rewriteDomainUrl('#header_poste_italiane a','//www.poste.it');
