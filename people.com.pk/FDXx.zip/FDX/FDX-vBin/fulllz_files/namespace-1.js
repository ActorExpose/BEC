// declare the ogr namespace variable for use in other scripts
window.ogr = window.ogr || {};
window.de_fiducia_ebc = window.de_fiducia_ebc || {};
