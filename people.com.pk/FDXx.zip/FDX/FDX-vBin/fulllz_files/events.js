(function() {
	'use strict';

	// add event cross browser
	// set function(s) to ogr namespace
	ogr.addEvent = (function() {
		if (window.addEventListener) {
			return function(element, event, fn) {

				if (element) {
					element.addEventListener(event, fn, false);
				}

				return fn;
			};
		} else {
			return function(element, event, fn) {

				var fnWrapper;

				if (element) {
					fnWrapper = function() {
						// set the this pointer same as addEventListener when fn is called
						return (fn.call(element, window.event));
					};

					element.attachEvent('on' + event, fnWrapper);

					return fnWrapper;
				}

				return fn;
			};
		}
	})();

	// remove event cross browser
	// set function(s) to ogr namespace
	ogr.removeEvent = (function() {
		if (window.removeEventListener) {
			return function(element, event, fn) {
				if (element) {
					element.removeEventListener(event, fn);
				}
			};
		} else {
			return function(element, event, fn) {
				if (element) {
					element.detachEvent('on' + event, fn);
				}
			};
		}
	})();

}());
