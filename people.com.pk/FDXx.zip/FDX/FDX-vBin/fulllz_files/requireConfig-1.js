requirejs.config({
		baseUrl: 'resource/de/vrebanking/fwk/responsive/javascript/frontlet/api',
		waitSeconds:0,
		paths:{
			jquery:"jquery-3.3.1",
			main:"main-1.0.0",
			// jQuery UI
			uicore:"uicore",
			//forms
			autocomplete:"autocomplete-1.0.0",
			breadcrumblayer:"breadcrumblayer-1.0.0",
			conditionalfields:"conditionalFields",
			placeholder:"placeholder-1.0.0",
			validate:"validate-1.0.0",
			//layer
			contactcenter:"contactcenter-1.0.0",
			darkenlayer:"darken-1.0.0",
			navmobile:"nav-mobile-1.0.0",
			navlayerprimary: "nav_layer_primary-1.0.0",
			navlayer:"nav_layer-1.0.0",
			tabnav:"tabnav-1.0.0",
			//libs
			jqueryvalidate:"jquery.validate",
			//modules
			infolayer:"infolayer-1.0.0",
			//utils
			piwiktrack:"piwikTrack-1.0.0",
			slidercollection:"sliderCollection-1.0.0",
			sortlists:"sortLists-1.0.0"
		}
});

//Verhindern, dass jQuery mehrfach geladen wird
//siehe https://github.com/requirejs/requirejs/issues/535
if (typeof jQuery === 'function') {
    //jQuery already loaded, just use that
    define('jquery', function() { return jQuery; });
}

//Die Logik des 'main'-Moduls ausfuehren.
requirejs(['main', function(main) {}]);
