"use strict";

var connections = [];

self.onconnect = function (e) {
    var port = e.ports[0];
    port.start();

    port.onmessage = function (e) {
        connections.forEach(function (connection) {
            if (connection !== port) {
                connection.postMessage(e.data);
            }
        });
    };

    connections.push(port);
};