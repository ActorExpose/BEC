de_fiducia_ebc.callBacks = function()
  {
	function keepAlive(data) 
    {
    	  if (data.uuid !== null && data.origin !== null && data.origin !== "de_fiduciagad:ebc" && data.timestamp !== null)
    	  {
    		  if (data.version === "1.0")
    		  {
    			//  this.keepAliveEB(data.origin, data.uuid, data.hlsid, data.message);
    			  this.keepAliveEB();
    		  }
    		  else if (data.version === null)
    		  {  
    			 this.keepAliveEB();
    		  }
    		  else
    		  {
    			  //NOTHING
    			  return;
    		  }
    	  }
    };
    // This is the part that separates the private and public stuff.  Anything
    // in this object becomes public.  Anything NOT in this object becomes
    // private.
    var ebcPublic =
    {
    		keepAlive: keepAlive
    };
    return ebcPublic;
  }();