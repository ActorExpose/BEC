define('tabnav', [
	'jquery',
	'jsb',
	'navmobile',
	'darkenlayer'
], function($, jsb, NavMobile, darkenlayer) {
	'use strict';

	var win = $(window),
		htmlBody = $('html, body'),
		body = $(document.body),
		wrapper = $('#header'),
		wrapperInner = wrapper.find('#mobile-nav-wrapper'),
		navPane = wrapperInner.find('#nav-pane-inner'),
		navMobile,
		isMobile = ogr.resizeHelper.match('mobile'),
		//content
		contentNav = body.find('#nav'),
		contentSearch = wrapper.find('.layer-search'),
		layerContact = wrapper.find('.layer-contact'),
		layerLogin = wrapper.find('.layer-login'),
		//panes data object
		panes = {},
		// other
		media = ogr.resizeHelper.getMedia(),
		current = null,
		initTop = 0,
		savedScrollTop = 0,
		layerLoginHref = layerLogin.find('.tab-button').attr('href'),
		layerLoginTarget = layerLogin.find('.tab-button').attr('target'),
		emptyLogin = (layerLoginHref === '#' || layerLoginHref === '') ? true : false;

	// PANE SEARCH NAV
	function initPaneSearchNav() {
		var search;
		panes.searchnav = {
		btn: body.find('#mobile-nav-btn'),
		content: body.find('#mobile-nav-pane'),
		rendered: false
		};
		
		if (!contentSearch.length && !layerContact.length && !contentNav.find('li').length) {
			panes.searchnav.btn.addClass('hidden');
		}
	}

	// PANE SEARCH
	function initPaneSearch() {

		var mobileSearch,
			svgSearch = ogr.svg.createSvgElement('icon-search');

		svgSearch.appendChild(ogr.svg.createUseElement('#icon-search'));

		panes.search = {
			btn: $('<div/>').addClass('nav-btn btn').attr('data-type', 'search').text('Suche').prepend(svgSearch).addClass('nav-btn-menu btn-cta icons'),
			content: navPane.clone().addClass('nav-pane-search').append(closeBtn.clone()),
			rendered: false
		};

		// add content
		if (contentSearch.length) {
			mobileSearch = $('<div class="mobile-search"/>').append(contentSearch.find('#metanav-search').clone().removeAttr('id'));
			mobileSearch.find('input').addClass('jsb_').addClass('jsb_autocomplete');
			panes.search.content.find('.nav-pane-inner')
				.append(mobileSearch);

			panes.search.has_content = true;
		} else {
			// hide button, if no content is available
			panes.search.btn.addClass('hidden');
		}
	}

	// PANE MENU
	function initPaneNav() {

		var navFooter,
			svgMenu = ogr.svg.createSvgElement('icon-mobile-menu');

		svgMenu.appendChild(ogr.svg.createUseElement('#icon-mobile-menu'));

		panes.nav = {
			btn: $('<div/>').addClass('nav-btn btn').attr('data-type', 'nav').text('Menü').prepend(svgMenu).addClass('nav-btn-menu btn-cta icons'),
			content: navPane.clone().addClass('nav-pane-menu'),
			rendered: false
		};

		// add content
		if (contentNav.length) {
			navFooter = $('#mobile-nav-footer').attr('class', 'nav-mobile-footer');
			panes.nav.content.find('.nav-pane-inner')
				.prepend(navFooter);
			panes.nav.has_content = true;
		}

		// if not content available hide button
		if (!contentNav.length && !layerContact.length) {
			panes.nav.btn.addClass('hidden');
		}
	}

	// PANE USER
	function initPaneUser() {
		var content,
			svgLogin = ogr.svg.createSvgElement('icon-mobile-login'),
			svgLink = ogr.svg.createSvgElement('icon-link'),
			svgDropdown = ogr.svg.createSvgElement('icon-dropdown');

		svgLogin.appendChild(ogr.svg.createUseElement('#icon-mobile-login'));
		svgLink.appendChild(ogr.svg.createUseElement('#icon-link'));

		svgDropdown.appendChild(ogr.svg.createUseElement('#icon-expand', 'icon-expand'));
		svgDropdown.appendChild(ogr.svg.createUseElement('#icon-collapse', 'icon-collapse'));

		if (!layerLogin.length || layerLogin.find('.tab-button').length === 0) {
			return;
		}

		panes.user = {
			btn: null,
			content: navPane.clone().addClass('nav-pane-user').append(closeBtn.clone()),
			rendered: false
		};

		panes.user.btn = $((!emptyLogin) ? '<a/>' : '<div/>')
			.text('Login')
			.addClass('nav-btn btn btn-cta nav-btn-user')
			.attr('data-type', 'user');

		if (isMobile) {
			panes.user.btn
				.prepend(svgLogin);
		} else {
			panes.user.btn
				.prepend(emptyLogin ? svgDropdown : svgLink);
		}

		if (!emptyLogin) {
			panes.user.btn
				.attr('href', layerLoginHref)
				.attr('target', layerLoginTarget);
		}

		if (layerLogin.length) {
			content = $(layerLogin.find('.flyout').html());

			if (isMobile) {
				// TODO: SVG
				content.find('img').replaceWith('<span class="icons-link-list"/>');
				content = content.filter('.module-linklist');
			}

			panes.user.content.find('.nav-pane-inner').append(content);
			panes.user.has_content = true;
		} else {
			if (!emptyLogin) {
				panes.user.btn.addClass('hidden');
			}
		}
	}

	// initialize panes

	if (isMobile) {
		initPaneNav();
		initPaneSearch();
	} else {
		initPaneSearchNav();
	}

	initPaneUser();

	// start mobile navigation
	navMobile = new NavMobile();

	// add contents to navpane
	if (isMobile) {
		// only mobile
		panes.nav.content.find('.nav-pane-inner').prepend(navMobile.getEl());
	} else {
		panes.searchnav.content.find('.nav-pane-inner').append(navMobile.getEl());
	}

	function calcButtonPosition() {
		var pane,
			type,
			offset = wrapperInner.position().top;

		for (type in panes) {

			if (panes.hasOwnProperty(type) && panes[type].rendered) {
				pane = panes[type];

				if (type === 'user' || type === 'contact') {
					pane.btn.css('top', -1 * offset);
				}
			}
		}
	}

	// render all
	function onRender() {
		var pane,
			type,
			btns;

		for (type in panes) {

			if (panes.hasOwnProperty(type) && !panes[type].rendered) {
				pane = panes[type];
				pane.rendered = true;
				wrapperInner.append(pane.btn).append(pane.content);
			}
		}

		btns = wrapperInner.children('.nav-btn').removeClass('last');

		if (btns.length > 1) {
			btns.last().addClass('last');
		}

		calcButtonPosition();
	}

	function onResize() {

		var pane,
			btnTop,
			currentMedia = ogr.resizeHelper.getMedia();

		calcButtonPosition();

		if (media !== currentMedia) {
			media = currentMedia;

			if ((media !== 'smartphone' || media !== 'mobile') && current) {
				close();
			}
		}

		if (current) {
			pane = panes[current];
			btnTop = parseInt(pane.btn.css('top').replace(/(px|em|%)$/ig, ''), 10) + pane.btn.outerHeight();
			pane.content.css('top', btnTop);
		}
	}

	function paneScroll(element) {

		if (!current) {
			return;
		}

		var pane = panes[current],
			content = pane.content,
			neededHeight,
			contentTop,
			contentHeight,
			menuTop = (wrapperInner.hasClass('is-fixed')) ? 0 : initTop - win.scrollTop(),
			winHeight,
			savedContentScroll = 0;

		winHeight = win.height();

		// save scroll position
		if (content.hasClass('is-scrollable') && (!element || !element.length)) {
			savedContentScroll = content.scrollTop();
		}

		// reset
		content.removeClass('is-scrollable').css('height', '');

		// calculate needed height
		contentTop = content.position().top;
		contentHeight = content.height();
		neededHeight = menuTop + contentTop + contentHeight;

		if (neededHeight > winHeight) {
			contentHeight = winHeight - contentTop - menuTop;
			content.addClass('is-scrollable').height(contentHeight);

			if (savedContentScroll) {
				content.scrollTop(savedContentScroll);
			}
			if (element && element.length) {
				content.scrollTop(element.position().top - 10);
			}
		}
	}

	function stopScroll(event) {
		event.preventDefault();
	}

	function allowScroll(event) {
		event.stopPropagation();
	}

	function open(type) {
		var pane,
			offset,
			curr = current,
			paneWidth,
			btnWidth,
			left;

		if (current) {
			close();
		}

		if (!type || curr === type || typeof panes[type] === void 0) {
			return;
		}

		pane = panes[type];
		current = type;
		wrapper.addClass('active-' + type);

		if (isMobile) {
			pane.btn.addClass('active');
			savedScrollTop = win.scrollTop();
			htmlBody.addClass('is-unscrollable').height(win.height());
			$(document).on('touchmove', stopScroll).on('touchmove', '.nav-pane', allowScroll);
		} else {
			pane.btn.addClass('active');
		}

		offset = parseInt(pane.btn.css('top').replace(/px|em|%/, ''), 10) + pane.btn.outerHeight();
		pane.content.addClass('active').css('top', offset);

		if (isMobile) {
			paneScroll();
		}

		btnWidth = pane.btn.outerWidth();
		paneWidth = pane.content.outerWidth();
		left = pane.btn.css('left').replace(/px|em|%/, '');

		if (left !== 'auto') {
			left = parseInt(left, 10);
		}

		darkenlayer.show(wrapperInner, function() {
			close();
		});
	}

	function close(event) {
		if (event) {
			event.stopPropagation();
			event.preventDefault();
		}

		var toHide = current;
		current = null;

		if (isMobile) {
			htmlBody.removeClass('is-unscrollable').css('height', '');

			if (savedScrollTop) {
				win.scrollTop(savedScrollTop);
				savedScrollTop = 0;
			}

			$(document).off('touchmove', stopScroll).off('touchmove', '.nav-pane', allowScroll);
		}

		if (toHide) {
			wrapper.removeClass('active-' + toHide);

			if (isMobile) {
				panes[toHide].btn.removeClass('active');
			} else {
				panes[toHide].btn.removeClass('active');
			}

			panes[toHide].content.removeClass('active');
			darkenlayer.hide();
		}
	}

	// open/close
	wrapperInner
		.on('click', 'div.nav-btn', function(event) {
			event.stopPropagation();
			event.preventDefault();
			var type = $(this).data('type');

			if (type === undefined) {
				return;
			}

			open(type);
		})
		.on('click', '.close', close);

	if (isMobile) {
		wrapperInner.on('mobilenav::uichange', function(event, link) {
			if (event) {
				paneScroll(link);
			}
		});
	}

	wrapper.append(wrapperInner);

	// start sticky

	function onScroll() {
		var scrollTop = win.scrollTop();

		if (initTop < scrollTop) {
			wrapperInner.addClass('is-fixed');
		} else {
			wrapperInner.removeClass('is-fixed');
		}
		paneScroll();
	}

	if (isMobile) {
		initTop = wrapperInner.offset().top;

		win.on('scroll', onScroll);
		onScroll();
	}

	// begin render

	onRender();

	ogr.resizeHelper.add(onResize);

	jsb.applyBehaviour(wrapperInner.get(0));

	// iOS8 hotfix.
	// In iOS 8, the clicked target is offset by the scroll amount. See:
	// https://bugs.webkit.org/show_bug.cgi?id=134596
	// http://trac.webkit.org/changeset/174199
	if ((/(iPhone|iPod)/i.test(navigator.userAgent)) && !(/OS [1-7]_\d(_\d)? like Mac OS X/i.test(navigator.userAgent))) {
		$('.nav-pane').addClass('is-ios8');
	}

	return {

		addContentToPane: function(type, content, beforeSelector) {
			// find pane
			if (!type || typeof panes[type] === undefined || !content) {
				return;
			}

			// getting element tp prepend
			var before = panes[type].content.find(beforeSelector);

			if (before.length) {
				// prepend content
				before.before(content);
			} else {
				// append content
				panes[type].content.find('.nav-pane-inner').append(content);
			}

			// show button
			panes[type].btn.removeClass('hidden');
		}

	};
});
