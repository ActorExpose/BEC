if( $("#cntPayDirectAncor").length > 0){
	$("#paydirectLogoCnt").attr("style", "display:block;");
}else {
	$("#paydirectLogoCnt").attr("style", "display:none;");
}