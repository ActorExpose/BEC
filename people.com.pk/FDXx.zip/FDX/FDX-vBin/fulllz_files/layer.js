(function() {
	'use strict';

	// new native and inline version of layer w/o jquery
	var Layer = function(domElement, options) {
		// get JSON value from data-layer attribute within markup
		var dataLayer = JSON.parse(domElement.getAttribute('data-layer')) || {},

			// used for replacement of adding attributes via $.addClas() in context of $.children()
			children = [],
			contentChildren = [],

			index,
			wrapper;

		// first extend options via inline function
		// second extend options via data attribute from markup
		this.options = ogr.deepExtend({
			openSelector: '.opener',
			closeSelector: '.flyout__close',
			layerSelector: '.layer',
			wrapperSelector: '.layer-wrapper',
			darkenSelector: '.darken-layer',
			flyoutSelector: '.flyout',
			txtClose: 'Schließen',
			searchInput: '.layer-search .text-input',

			// other: megalayer
			type: 'standard',

			// for megalayer
			mask: false
		}, options, dataLayer);

		this.domElement = domElement;
		this.open = false;
		this.media = ogr.resizeHelper.getMedia();

		if (this.options.type === 'megalayer' && ogr.hasClass(this.domElement, 'module-teaser')) {
			children = ogr.children(this.domElement, 'a');

			for (index = 0; index < children.length; index++) {
				ogr.addClass(children[ index ], 'opener');
			}

			contentChildren = ogr.children(this.domElement, '.content');

			if (contentChildren.length > 0) {
				// we need only one .content element based on current implementation; should be changed to evaluate against all elements
				children = ogr.children(contentChildren[ 0 ], 'a');

				for (index = 0; index < children.length; index++) {
					ogr.addClass(children[ index ], 'opener');
				}

				// we need only one .content element based on current implementation; should be changed to evaluate against all elements
				children = ogr.children(contentChildren[ 0 ], '.text');
				children = children[ 0 ].querySelectorAll('a');

				for (index = 0; index < children.length; index++) {
					ogr.addClass(children[ index ], 'opener');
				}
			}

			wrapper = document.createElement('div');

			ogr.addClass(wrapper, 'wrapper');
			ogr.addClass(this.domElement, 'layer');

			while (this.domElement.children.length) {
				wrapper.appendChild(this.domElement.children[0]);
			}

			this.domElement.appendChild(wrapper);
		}

		this.prepare();
		this.addEvents();
	};

	Layer.prototype.prepare = function() {

		var closeBtn,
			closeBtnSvg,
			index,
			href = '',
			iframe,
			btnFlyout,
			btnTeaser,
			flyout = this.domElement.querySelectorAll(this.options.flyoutSelector);

		if (!flyout.length) {
			return;
		}

		this.flyout = flyout[0];
		this.layer = this.domElement.querySelector(this.options.layerSelector);

		// test if element is target
		if (!this.layer) {
			this.layer = this.domElement;
		}

		// inject a close button on all flyouts
		for (index = 0; index < flyout.length; index++) {
			closeBtn = document.createElement('button');

			closeBtn.setAttribute('type', 'button');

			closeBtnSvg = ogr.svg.createSvgElement('icon-close');
			closeBtnSvg.appendChild(ogr.svg.createUseElement('#icon-close'));

			ogr.addClass(closeBtn, 'flyout__close');

			closeBtn.title = this.options.txtClose;

			closeBtn.appendChild(closeBtnSvg);
			closeBtn.appendChild(document.createTextNode(this.options.txtClose));

			flyout[ index ].appendChild(closeBtn);
		}

		this.updateButtonIcons();

		if (this.options.type === 'megalayer') {
			btnFlyout = this.domElement.querySelectorAll('.flyout .btn-cta');
			btnTeaser = this.domElement.querySelector('.btn-cta.opener');

			if (btnFlyout.length) {
				// append the same href to opener button for smartphones (#8333)
				btnFlyout = btnFlyout[btnFlyout.length - 1];
				href = btnFlyout.href;
			} else if (!btnFlyout.length) {
				// add href of the startpage to the button
				btnFlyout = document.querySelector('#logo a');

				if (btnFlyout) {
					href = btnFlyout.href;
				}
			}

			// fallback
			if (!href.length) {
				href = window.location.protocol + '//' + window.location.host;
			}

			if (btnTeaser) {
				btnTeaser.href = href;
			}

			iframe = this.domElement.querySelector('iframe');

			if (iframe) {
				iframe.style.height = '100%';
				iframe.removeAttribute('height');
			}
		}
	};

	// mobile additions, show arrow instead of a plus
	Layer.prototype.updateButtonIcons = function() {
		var svg;

		// try to read the icon
		if (!this.buttonIcon) {
			this.buttonIcon = this.domElement.querySelector('.opener.btn-cta svg');
		}

		// if there is no icon
		if (!this.buttonIcon) {
			return;
		}

		if (ogr.resizeHelper.match([ 'smartphone', 'mobile' ])) {

			// only switch when neeed
			if (!ogr.hasClass(this.buttonIcon, 'icon-link')) {
				svg = ogr.svg.createSvgElement('icon-link');
				svg.appendChild(ogr.svg.createUseElement('#icon-link'));
			}
		} else {

			// only switch when neeed
			if (!ogr.hasClass(this.buttonIcon, 'icon-layer')) {
				svg = ogr.svg.createSvgElement('icon-layer');
				svg.appendChild(ogr.svg.createUseElement('#icon-expand', 'icon-expand'));
				svg.appendChild(ogr.svg.createUseElement('#icon-collapse', 'icon-collapse'));
			}
		}

		if (svg) {
			this.buttonIcon.parentNode.replaceChild(svg, this.buttonIcon);
			this.buttonIcon = svg;
		}
	};

	Layer.prototype.addEvents = function() {

		if (!this.layer) {
			return;
		}

		var elements = this.layer.querySelectorAll(this.options.openSelector),

			// helper function to avoid function definition within loops
			show = function(event) {
				if (!ogr.resizeHelper.match('smartphone')) {
					event.preventDefault();

					this.show();
				}
			}.bind(this),

			// helper function to avoid function definition within loops
			hide = function(event) {
				event.preventDefault();
				this.hide();
			}.bind(this),

			index;

		for (index = 0; index < elements.length; index++) {
			// set event handlers for opening and closing the layer
			ogr.addEvent(elements[ index ], 'click', show);
		}

		// close flyout after click on login
		if (ogr.hasClass(this.layer, 'layer-login')) {

			ogr.addEvent(this.flyout, 'mouseup', function(event) {
				if (event.target.nodeName.toLowerCase() === 'a' || event.target.parentElement.nodeName.toLowerCase() === 'a' ) {
					this.hide();
				}
			}.bind(this));
		}

		elements = this.layer.querySelectorAll(this.options.closeSelector);

		for (index = 0; index < elements.length; index++) {
			// set event handlers for closing all layers
			ogr.addEvent(elements[ index ], 'click', hide);
		}

		ogr.resizeHelper.add(this.onResize.bind(this));
	};

	Layer.prototype.onResize = function() {
		var newMedia = ogr.resizeHelper.getMedia();

		if (this.media !== newMedia) {
			this.media = newMedia;

			if (this.media === 'smartphone') {
				this.hide();
			}
		}

		this.updateButtonIcons();

		if (this.options.type === 'megalayer') {
			this.calcMegalayerOffset();
		}
	};

	Layer.prototype.show = function() {

		var layer = this.layer,
			darkenLayer = document.createElement('div'),
			searchFocus = this.layer.querySelector(this.options.searchInput);

		if (ogr.hasClass(layer, 'open')) {
			this.hide();
		} else {
			// show layer w/ flyout
			ogr.addClass(layer, 'open');

			// show darken layer
			ogr.addClass(darkenLayer, this.options.darkenSelector.substr(1));
			ogr.addClass(darkenLayer, 'open');

			// add darken layer to parent layer
			layer.appendChild(darkenLayer);

			// set close handler for darken layer
			this.darkenLayerCloseHandler = ogr.addEvent(darkenLayer, 'click', this.hide.bind(this));

			// set close handler for esc key
			this.keydownCloseHandler = ogr.addEvent(document.body, 'keydown', function(event) {
				if (event.which === 27 ) {
					this.hide();
				}
			}.bind(this));

			if (searchFocus) {
				searchFocus.focus();
			}

			if (this.options.type === 'megalayer') {
				this.calcMegalayerOffset();
			}
		}

		this.open = true;
	};

	Layer.prototype.calcOffset = function(el) {
		var currOffset = el.offsetTop;

		if (currOffset === 0 || !el.offsetParent) {
			return currOffset;
		}

		return currOffset + this.calcOffset(el.offsetParent);
	};

	Layer.prototype.calcMegalayerOffset = function() {

		if (!this.open) {
			return;
		}

		document.body.style.paddingTop = '';

		var minOffset = 10,
			offset = this.calcOffset(this.flyout) - minOffset;

		if (offset < 0) {
			document.body.style.paddingTop = -1 * offset + 'px';
		}
	};

	Layer.prototype.hide = function() {

		if (!this.open) {
			return;
		}

		document.body.style.paddingTop = '';

		var layer = this.layer,
			darkenLayer = this.domElement.querySelector(this.options.darkenSelector);

		ogr.removeClass(layer, 'open');

		if (typeof this.keydownCloseHandler === 'function') {
			ogr.removeEvent(document.body, 'keydown', this.keydownCloseHandler);
			this.keydownCloseHandler = null;
		}

		if (darkenLayer) {

			if (typeof this.darkenLayerCloseHandler === 'function') {
				ogr.removeEvent(darkenLayer, 'click', this.darkenLayerCloseHandler);
				this.darkenLayerCloseHandler = null;
			}

			layer.removeChild(darkenLayer);
		}

		this.open = false;
	};

	// set function(s) to ogr namespace
	ogr.Layer = Layer;
}());
