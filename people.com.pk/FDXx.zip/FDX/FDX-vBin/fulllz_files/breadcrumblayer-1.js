define('breadcrumblayer', [
	'jquery'
], function($) {
	'use strict';

	var BreadcrumbLayer = function(dom_element) {
		var that = this,
			wrapper = $('.ym-wrapper').first(),
			close_handler = function() {
				wrapper.off('click', close_handler);
				that.close();
			},
			open_handler = function(event) {
				// event.stopPropagation crashes e-Banking-Tools
	
				event.stopPropagation();
				wrapper.on('click', close_handler);
				that.open();
				window.setTimeout(function() {
					wrapper.on('click', close_handler);
				}, 100);
			};
	
		dom_element = $(dom_element);
	
		this.flyout = dom_element.find('.breadcrumb-layer');
		this.anchors = this.flyout.find('a');
	
		// set a tabindex attribute on the strong element preceding the bc layer
		// when clicking or focusing (using tab key) onto it, open
		// breadcrumb layer and set focus on first anchor in the flyout
		dom_element.find('strong').first().attr('tabindex', 0).on({
			'click': open_handler,
			'keyup': function(e) {
				if (e.which === 9 ) {
					open_handler(e);
					that.anchors.first().focus();
				}
			}
		}).
		// clone the text label and inject it into bc layer to preserve it's visual position
		clone().attr('tabindex', null).prependTo(this.flyout).addClass('breadcrumb-tab').
		append($('<span class="icons-nav-item"/>')).
		// change icon style
		find('.icons-slide-down').removeClass('icons-slide-down').addClass('icons-slide-up').
		// and set the event handler to close the flyout
		on('click', close_handler);
	
		// close opened bc-layer when reverse-tabbing from first anchor
		this.anchors.first().on('keydown', function(e) {
			if (e.which === 9 && e.shiftKey === true ) {
				close_handler();
				e.preventDefault();
				// and set the focus on the previous breadcrumb element
				that.flyout.parent().prev().find('a').focus();
			}
		});
	
		// close opened breadcrumb layer when tabbing away from last anchor
		this.anchors.last().on('keydown', function(e) {
			if (e.which === 9 && e.shiftKey === false ) {
				close_handler();
			}
		});
//		jsb.registerHandler("breadcrumblayer", BreadcrumbLayer);
	};
	
	BreadcrumbLayer.prototype.open = function() {
		this.flyout.addClass('open');
	};
	
	BreadcrumbLayer.prototype.close = function() {
		this.flyout.removeClass('open');
	};
	
	
	return BreadcrumbLayer;
});