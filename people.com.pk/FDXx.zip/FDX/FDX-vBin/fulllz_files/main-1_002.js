// begin main app
require(
    [
        "jquery",
    	'jsb',
    	'tabnav'
    ],
    function (jQuery,  jsb, history, prefill) {
    	'use strict';
        (function ($) {
            var version = $().jquery;
            $('#version').text(version);
        })(jQuery);
        require([ 'placeholder' ], function(placeholder) {
    		placeholder($('body'));
    	});
    	// hides imagemaps mobile
    	function imageMapResponsive() {
    		var imgmaps = $('img[usemap]');

    		if (imgmaps.length) {

    			require([ 'rwdImageMaps' ], function() {
    				imgmaps.rwdImageMaps();
    			});

    		}
    	}
    	// start
    	imageMapResponsive();
    	// call jsb
    	jsb.applyBehaviour(window.document);
    }
);

 