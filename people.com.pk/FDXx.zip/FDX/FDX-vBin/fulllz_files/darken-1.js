define('darkenlayer', [
	'jquery'
], function($) {
	'use strict';

	/*
	 * general element providing a modal/lightbox-style layer separating
	 * the currenty active layer (and active ui elements) from the remaining
	 * elements of the page
	 */

	var darkenlayer = (function() {
		var model = $('<div class="darken-layer open"></div>');

		return {
			show: function(parentNode, parentCallback) {
				parentNode = $(parentNode);

				model.on('click', function(event) {
					event.stopPropagation();

					if (parentCallback && $.type(parentCallback) === 'function') {
						parentCallback();
					}

					darkenlayer.hide();
					setTimeout(function() {
						darkenlayer.switchTest(event);
					}, 450);
				});

				parentNode.append(model);
			},

			hide: function() {
				model.parent().removeClass('active');
				model.off('click').detach();
			},

			switchTest: function(event) {

				event.stopPropagation();

				var clickedElement = $(document.elementFromPoint(event.pageX, event.pageY)).not(model);

				if (clickedElement.length && clickedElement.prop('tagName').toLowerCase() === 'a' && clickedElement.parents('.nav-secondary__inner').length) {
					// manipulation of main navigation desktop if darken layer is active and link clicked
					clickedElement.get(0).click();
				} else if (clickedElement.length && (clickedElement.hasClass('nav-btn') || clickedElement.parents('.nav-btn').length)) {
					// manipulation of navigation-button mobile if darken layer is active and layer-link clicked
					clickedElement.get(0).click();
				}
			}
		};
	}());

	return darkenlayer;
});
