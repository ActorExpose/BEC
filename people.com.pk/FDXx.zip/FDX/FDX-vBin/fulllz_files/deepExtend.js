/* global ogr:true */

(function() {
	'use strict';

	function deepExtend(out) {
		var obj,
			i = 1,
			forEachObj = function(key) {
				if (obj.hasOwnProperty(key)) {
					if (typeof obj[ key ] === 'object') {
						out[ key ] = deepExtend(out[ key ], obj[ key ]);
					} else {
						out[ key ] = obj[ key ];
					}
				}
			};

		out = out || {};

		for (; i < arguments.length; ++i) {
			obj = arguments[ i ];

			if (!obj) {
				continue;
			}

			Object.keys(obj).forEach(forEachObj);
		}

		return out;
	} // deepExtend()

	// set function(s) to ogr namespace
	ogr.deepExtend = deepExtend;
}());
