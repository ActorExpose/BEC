(function() {
	'use strict';

	// namespace
	window.ogr = window.ogr || {};
	window.ogr.svg = window.ogr.svg || {};

	/**
	 * Creates an svg-element with the neccessary namespaces.
	 * @param string className css classname for the svg tag
	 * @return HTMLNode
	 */
	ogr.svg.createSvgElement = function(className) {
		var xmlns = 'http://www.w3.org/2000/svg',
			svg = document.createElementNS(xmlns, 'svg');

		className = className || '';

		if (className.length) {
			svg.setAttributeNS(null, 'class', className);
		}

		return svg;
	};

	/**
	 * Creates an use-element with the neccessary namespaces.
	 * @param string xlink reference-id of the icon
	 * @param string className css-classname for the svg tag
	 * @return HTMLNode
	 */
	ogr.svg.createUseElement = function(xlink, className) {
		var xmlns = 'http://www.w3.org/2000/svg',
			svgns = 'http://www.w3.org/1999/xlink',
			node = document.createElementNS(xmlns, 'use');

		className = className || '';

		if (className.length) {
			node.setAttributeNS(null, 'class', className);
		}

		node.setAttributeNS(svgns, 'xlink:href', xlink);

		return node;
	};

}());
