define('navmobile', [
	'jquery'
], function($) {
	'use strict';

	var NavMobile = function() {
		this.media = ogr.resizeHelper.getMedia();
		this.mobileNav = $('#mobile-nav');
		this.nav = $('#nav-mobile');
		this.addEvents();
	};

	NavMobile.prototype.addEvents = function() {
		var that = this;
		ogr.resizeHelper.add(function() {
			that.onResize();
		});
		this.nav.on('click', 'a', function(event) {
			event.preventDefault();
			var link = $(this),
				ul;
			if (link.data('open')) {
				window.location.href = this.href;
			} else {
				ul = link.next('ul');
				that.closeOtherMobile(link);
				if (ul.length) {
					ul.show();
					link.data('open', true);
				} else {
					if (link.parent().data('nav')) {
						$.ajax(link.parent().data('nav')).done(function(data) {
							if ($.trim(data).length === 0) {
								window.location.href = link.attr('href');
							} else {
								link.data('open', true);
								data = $(data).filter('ul').attr('class', '');
								data.find('ul').attr('class', '').hide();
								data.find('.module').parent('li').remove();
								link.parent('li').append($(data).filter('ul').attr('class', ''));
								link.next('ul').show();
								that.mobileNav.trigger('mobilenav::uichange', [ link ]);
							}
						}).fail(function() {
							window.location.href = link.attr('href');
						});
					} else if (link.hasClass('first-level') && link.data('has-menu') === false) {
						$.ajax(link.attr('href')).done(function(data) {
							data = $(data).find('#nav-layer');
							// goto link if no sub elements
							if (data.find('li').length < 1) {
								window.location.href = link.attr('href');
							} else {
								link.data('open', true);
								data.attr('class', '').attr('id', '');
								data.find('.active').removeClass('active');
								data.find('.nav-level-2').remove();
								data.find('.module').parent('li').remove();
								link.parent('li').append(data);
								link.next('ul').show();
								that.mobileNav.trigger('mobilenav::uichange', [ link ]);
							}
						}).fail(function() {
							window.location.href = link.attr('href');
						});
					} else {
						window.location.href = link.attr('href');
					}
				}
			}
		});
	};

	NavMobile.prototype.onResize = function() {
		var newMedia = ogr.resizeHelper.getMedia();

		if (this.media !== newMedia && (newMedia !== 'smartphone' || newMedia !== 'mobile')) {
			this.media = newMedia;

			// reset
			this.nav.removeAttr('style').find('ul').removeAttr('style').hide();
			this.nav.find('a').data('open', false);
		}
	};

	NavMobile.prototype.closeOtherMobile = function(currentLink) {
		var links = currentLink.parents('ul').first().children('li').children('a'),
			linksLength = links.length,
			link,
			i;

		for (i = 0; i < linksLength; i++) {
			link = links.eq(i);

			if (link === currentLink) {
				continue;
			}

			link.data('open', false).next('ul').hide().find('ul').hide();
			link.next('ul').find('a').data('open', false);
		}
		this.mobileNav.trigger('mobilenav::uichange');
	};

	NavMobile.prototype.getEl = function() {
		return this.mobileNav;
	};

	return NavMobile;
});
