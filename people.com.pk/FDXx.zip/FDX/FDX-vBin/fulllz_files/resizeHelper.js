(function() {
	'use strict';

	// inline version of resize helper w/o using jquery
	var ResizeHelper = function() {
		this.resizes = [];
		this.media = 'desktop';
		this.device = 'desktop';

		var resizeHelper,
			mediaQueryHelper,
			self = this;

		// read media-query state
		mediaQueryHelper = function() {
			var newMedia,
				newDevice;

			// try reading css values
			try {
				newMedia = window.getComputedStyle(document.body, ':after').getPropertyValue('content');
				newDevice = window.getComputedStyle(document.body, ':before').getPropertyValue('content');
				// replace characters that browsers are rendering into the strings
				newMedia = newMedia.replace(/"|'/gi, '');
				newDevice = newDevice.replace(/"|'/gi, '');
			} catch (e) {
				newMedia = 'desktop';
				newDevice = 'desktop';
			}

			// fallback or set new values
			self.media = (newMedia.length) ? newMedia : 'desktop';
			self.device = (newDevice.length) ? newDevice : 'desktop';
		};

		resizeHelper = function() {
			var i,
				count = self.resizes.length;

			for (i = 0; i < count; ++i) {
				setTimeout(self.resizes[i], 0);
			}
		};

		mediaQueryHelper();
		this.resizes.push(mediaQueryHelper);

		ogr.addEvent(window, 'resize', resizeHelper);
	};

	ResizeHelper.prototype.add = function(f) {
		if (typeof f === 'function') {
			this.resizes.push(f);

			return this.resizes.length - 1;
		}

		return -1;
	};

	ResizeHelper.prototype._noop = function() {};

	ResizeHelper.prototype.remove = function(f) {
		var i,
			l = this.resizes.length;

		for (i = 0; i < l; ++i) {
			if (this.resizes[i] === f) {
				this.resizes[i] = this._noop;
				break;
			}
		}
	};

	ResizeHelper.prototype.getDevice = function() {
		return this.device;
	};

	ResizeHelper.prototype.getMedia = function() {
		return this.media;
	};

	ResizeHelper.prototype.match = function(values) {
		var type = Object.prototype.toString.call(values).replace(/^\[object (.+)\]$/, '$1').toLowerCase(),
			count = values.length,
			found = false,
			i;

		if (type === 'string') {
			found = (this.media === values);
		}

		if (type === 'array') {
			for (i = 0; i < count; ++i) {
				if (this.media === values[i]) {
					found = true;
					break;
				}
			}
		}

		return found;
	};

	// set function(s) to ogr namespace
	ogr.resizeHelper = new ResizeHelper();
}());
