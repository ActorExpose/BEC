<?php
error_reporting(0);

$seckey='ola1oo';  // Here is the admin-access key

$servername = "localhost";  // Host
$username = "hssevtcx_first";  // User
$password = 'Azim9090'; // Password
$dbname = "hssevtcx_first"; // dbname




$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$connp = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

?>